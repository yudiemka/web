<?php
class M_pencarian extends CI_Model{	

	public function __construct(){
		$this->load->database();
	}

	function cek_id_brg($id_brg) {
		$this->db->where('id_brg',$id_brg);
		$q=$this->db->get('minta_tmp');
		return $q;
	}

	function tampil_data_cari($key) {
		$this->db->like('instansi',$key);
		$q=$this->db->get('tbl_sbbk');
		return $q->result();
	}

	function tampil_data_cari_bmhp($key) {
		$this->db->like('nm_brg',$key);
		$q=$this->db->get('stok_logistik');
		return $q->result();
	}

	function pilih_data($nosbbk) {
		$this->db->where('no_sbbk',$nosbbk);
		$q=$this->db->get('tbl_brg_keluar');
		return $q;
	}

	function pilih_data_bhmp_keluar($kdbrg) {
		$this->db->where('id_brg',$kdbrg);
		$q=$this->db->get('tbl_brg_keluar');
		return $q;
	}

	function update_minta_tmp($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	function add_minta_tmp($data,$table){
		$this->db->insert($table,$data);
	}

	function add($table,$data){
		$this->db->insert($table,$data);
	}	

	function cek_minta_tmp($kd_brg,$no_sbbk) {
		$this->db->where('no_sbbk',$no_sbbk);
		$this->db->where('kd_brg',$kd_brg);
		$q=$this->db->get('stok_keluar_tmp');
		return $q;
	}

	function hapus_tmp($kdbrg){
		$hasil=$this->db->query("DELETE FROM stok_keluar_tmp WHERE kd_brg='$kdbrg' ");
        return $hasil;
	}

	function pilih_data_minta_tmp($no_sbbk) {
		$this->db->where('no_sbbk',$no_sbbk);
		$q=$this->db->get('stok_keluar_tmp');
		return $q->result();
	}

	function pilih_stok_keluar($no_sbbk) {
		$this->db->where('no_sbbk',$no_sbbk);
		$q=$this->db->get('tbl_brg_keluar');
		return $q->result();
	}

	function pilih_data_minta($no_disposisi,$id_brg) {
	    $this->db->where('no_disposisi',$no_disposisi);
	    $this->db->where('id_brg',$id_brg);
	    $q=$this->db->get('permintaan_tmp');
	    return $q->result();
	}

  	function cek_realisasi($no_disposisi,$id_brg) {
	    $this->db->where('no_disposisi',$no_disposisi);
	    $this->db->where('id_brg',$id_brg);
	    $q=$this->db->get('realisai_minta');
	    return $q;
	}

	function update($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function cekbrg($id_disposisi,$id_brg) {
		$this->db->where('id_disposisi',$id_disposisi);
		$this->db->where('id_brg',$id_brg);
		$q=$this->db->get('realisai_minta');
		return $q->result();
	}

	function cek_kasi($no_disposisi) {
		$this->db->where('no_disposisi',$no_disposisi);
		$q=$this->db->get('konfirmasi_kasi');
		return $q;
	}

	function cek_realisasi_brg($no_disposisi) {
		$this->db->where('no_disposisi',$no_disposisi);
		$q=$this->db->get('realisai_minta');
		return $q->result();
	}

}