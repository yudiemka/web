<?php
class M_menu extends CI_Model{	

	function showAll() {
		$this->db->order_by('title','ASC');
		$q=$this->db->get('menu');
		return $q->result();
	}
	function add($table,$data){
		$this->db->insert($table,$data);
	}

	function pilih_menu_all() {
		$this->db->order_by('id','ASC');
		$q=$this->db->get('menu');
		return $q->result();
	}	

	function tampil_data_menu() {
		$this->db->order_by('id_menu','ASC');
		$q=$this->db->get('menu');
		return $q->result();
	}

	function tampil_modul() {
		$this->db->order_by('id','ASC');
		$q=$this->db->get('coba_akses');
		return $q->result();
	}

	function tampil_data_submenu() {
		$this->db->order_by('id_menu','ASC');
		$q=$this->db->get('submenu');
		return $q->result();
	}

	function akses($status) {
		$this->db->where('status_menu',$status);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function cekmenu($idmenu) {
		$this->db->where('id_menu',$idmenu);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function pilih_submenu($idmenu) {
		$this->db->where('id_menu',$idmenu);
		$this->db->order_by('nama_submenu','ASC');
		$q=$this->db->get('submenu');
		return $q->result();
	}

	function pilih_menu_id($id) {
		$this->db->where('id_menu',$id);
		$q=$this->db->get('menu');
		return $q->result();
	}
	function edit($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function cek_nrk($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q;
	}

	function cek_panel($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q;
	}

	function cek_akses($id) {
		$this->db->where('nrk',$id);
		$q=$this->db->get('hak_akses');
		return $q;
	}


	function cek_nrk_akses($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q->result();
	}

	function datamenu_in($r) {
		$this->db->where_in('id_menu',$r);
		$this->db->order_by('id_menu','ASC');
		$q=$this->db->get('menu');
		return $q;
	}

	function menu_in($r) {
		$this->db->where_in('id_submenu',$r);
		$this->db->order_by('nama_submenu','ASC');
		$q=$this->db->get('submenu');
		return $q;
	}

	function submenu_in($r) {
		$this->db->where('tipe_submenu','1');
		$this->db->where_in('id_submenu',$r);
		$q=$this->db->get('submenu');
		return $q;
	}

	function pilih_menu_in($r) {
		$this->db->where_in('id_submenu',$r);
		$q=$this->db->get('submenu');
		return $q;
	}
	function menu_not_in($r) {
		$this->db->where_not_in('id_submenu',$r);
		$q=$this->db->get('submenu');
		return $q;
	}

	function pilih_akses($idmenu,$submenu,$nrk) {
		$this->db->where('id_menu',$idmenu);
		$this->db->where_in('id_submenu',$submenu);
		$this->db->order_by('id_menu','ASC');
		$q=$this->db->get('submenu');
		return $q->result();
	}

	function cek_modul($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q;
	}


	function update($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function hapus($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}

	function misc() {
		$q=$this->db->get('misc');
		return $q->result();
	}

	public function insert_data($data) {
        return $this->db->insert('hak_akses', $data);
    }
	


}