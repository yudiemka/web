<?php
class M_master extends CI_Model{	

	function showAll() {
		$this->db->order_by('title','ASC');
		$q=$this->db->get('menu');
		return $q->result();
	}
	function add($table,$data){
		$this->db->insert($table,$data);
	}

	function pilih_menu_all() {
		$this->db->order_by('id','ASC');
		$q=$this->db->get('menu');
		return $q->result();
	}	

	function tampil_data_jp() {
		$this->db->order_by('kode','ASC');
		$q=$this->db->get('jenis_pengeluaran');
		return $q->result();
	}

	function pengeluaran() {
		$this->db->order_by('kode','ASC');
		$q=$this->db->get('jenis_pengeluaran');
		return $q->result();
	}


	function tampil_data_submenu() {
		$this->db->order_by('id_menu','ASC');
		$q=$this->db->get('submenu');
		return $q->result();
	}

	function akses($status) {
		$this->db->where('status_menu',$status);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function cekmenu($idmenu) {
		$this->db->where('id_menu',$idmenu);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function pilih_submenu($idmenu) {
		$this->db->where('id_menu',$idmenu);
		$this->db->order_by('nama_submenu','ASC');
		$q=$this->db->get('submenu');
		return $q->result();
	}

	function pilih_menu_id($id) {
		$this->db->where('id_menu',$id);
		$q=$this->db->get('menu');
		return $q->result();
	}
	function edit($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function cek_nrk($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q;
	}

	function cek_nrk_akses($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q->result();
	}

	function menu_in($r) {
		$this->db->where_in('id',$r);
		$this->db->order_by('menu','ASC');
		$q=$this->db->get('menu');
		return $q;
	}

	function menu_not_in($r) {
		$this->db->where_not_in('id',$r);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function update($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function hapus($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}

	function misc() {
		$q=$this->db->get('misc');
		return $q->result();
	}
	


}