<?php
class M_user extends CI_Model{	

	function tampil() {
		$this->db->order_by('nama','ASC');
		$q=$this->db->get('user');
		return $q->result();
	}
	function tampil_data() {
		$this->db->order_by('','ASC');
		$q=$this->db->get('user');
		return $q->result();
	}
	function add($table,$data){
		$this->db->insert($table,$data);
	}	

	function pilih_data($nrk) {
		$this->db->where('no_reg_karyawan',$nrk);
		$q=$this->db->get('user');
		return $q->result();
	}
	function edit($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function tampil_hak_akses($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q->result();
	}

	function cek_nrk_akses($nrk) {
		$this->db->where('user_nrk',$nrk);
		$q=$this->db->get('tbl_hak_akses');
		return $q->result();
	}

	function cek_id($nrk){
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('pengguna');
		return $q;
	}

	function ceknrk($nrk){
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q;
	}

	function hapus($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}
}