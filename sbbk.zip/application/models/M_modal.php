<?php
class M_modal extends CI_Model{	

	function showAll() {
		$this->db->order_by('merk','ASC');
		$q=$this->db->get('menu');
		return $q->result();
	}
	function add($table,$data){
		$this->db->insert($table,$data);
	}

	function cek_tabel() {
		$cek=$this->db->get('modal');
		return $cek;
	}

	function tampil_data_modal() {
		$this->db->order_by('tanggal_cash','ASC');
		$q=$this->db->get('modal');
		return $q->result();
	}

	function projek($postData){
	    $response = array();
	    if(isset($postData['search']) ){
	     	// Select record
	       	$this->db->select('*');
	       	$this->db->where("nama_projek like '%".$postData['search']."%' ");
	       	$records = $this->db->get('projek')->result();
	       	foreach($records as $row ){
	          	$response[] = array(
	          		"nama_projek"=>$row->nama_projek,
	          		"id_projek"=>$row->id_projek,
	          		"jumlah_unit"=>$row->jumlah_unit,
	          		"lokasi"=>$row->lokasi_projek,
	          	);
	       	}
	    }	    
	    return $response;
	}

	function tampil_merk() {
		$this->db->order_by('nama','ASC');
		$q=$this->db->get('merk');
		return $q->result();
	}

	function pilih_merk($id) {
		$this->db->where('id',$id);
		$q=$this->db->get('merk');
		return $q->result();
	}

	function pilih_menu_id($id) {
		$this->db->where('id_menu',$id);
		$q=$this->db->get('menu');
		return $q->result();
	}
	function edit($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function cek_nrk($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q;
	}

	function cek_nrk_akses($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q->result();
	}

	function menu_in($r) {
		$this->db->where_in('id',$r);
		$this->db->order_by('menu','ASC');
		$q=$this->db->get('menu');
		return $q;
	}

	function menu_not_in($r) {
		$this->db->where_not_in('id',$r);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function update($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function hapus($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}

	function misc() {
		$q=$this->db->get('misc');
		return $q->result();
	}
	


}