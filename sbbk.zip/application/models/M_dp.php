<?php
class M_dp extends CI_Model{	

	function showAll() {
		$this->db->order_by('merk','ASC');
		$q=$this->db->get('menu');
		return $q->result();
	}
	function add($table,$data){
		$this->db->insert($table,$data);
	}

	function tampil_data() {
		$this->db->order_by('tanggal_dp','ASC');
		$q=$this->db->get('dp');
		return $q->result();
	}

	function cek_tabel() {
		$cek=$this->db->get('dp');
		return $cek;
	}

	function hapus_data_dp($iddp) {
		$this->db->where('id_dp',$iddp);
		return $this->db->delete('dp');
	}

	function cari_konsumen($postData){
	    $response = array();
	    if(isset($postData['search']) ){
	     	// Select record
	       	$this->db->select('*');
	       	$this->db->where("nama_konsumen like '%".$postData['search']."%' ");
	       	$records = $this->db->get('konsumen')->result();
	       	foreach($records as $row ){
	          	$response[] = array(
	          		"nama_konsumen"=>$row->nama_konsumen,
	          		"alamat_konsumen"=>$row->alamat_konsumen,
	          		"id_konsumen"=>$row->id_konsumen,
	          		"id_projek"=>$row->id_projek,
	          		"id_unit"=>$row->jumlah_unit,
	          	);
	       	}
	    }	    
	    return $response;
	}

	function tampil_merk() {
		$this->db->order_by('nama','ASC');
		$q=$this->db->get('merk');
		return $q->result();
	}

	function pilih_merk($id) {
		$this->db->where('id',$id);
		$q=$this->db->get('merk');
		return $q->result();
	}

	function pilih_menu_id($id) {
		$this->db->where('id_menu',$id);
		$q=$this->db->get('menu');
		return $q->result();
	}
	function edit($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function cek_nrk($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q;
	}

	function cek_nrk_akses($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q->result();
	}

	function menu_in($r) {
		$this->db->where_in('id',$r);
		$this->db->order_by('menu','ASC');
		$q=$this->db->get('menu');
		return $q;
	}

	function menu_not_in($r) {
		$this->db->where_not_in('id',$r);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function update($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function hapus($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}

	function misc() {
		$q=$this->db->get('misc');
		return $q->result();
	}
	


}