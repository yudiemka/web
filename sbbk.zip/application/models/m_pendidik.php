<?php
class M_pendidik extends CI_Model{	
	function showAll() {
		$this->db->order_by('nama','ASC');
		$q=$this->db->get('pengajar');
		return $q->result();
	}
	function showAktif() {
		$this->db->where('status_karyawan',"1");
		$this->db->order_by('nama','ASC');
		$q=$this->db->get('karyawan');
		return $q->result();
	}

	function add($table,$data){
		$this->db->insert($table,$data);
	}	

	function sel_noreg($noreg) {
		$this->db->where('noreg',$noreg);
		$q=$this->db->get('karyawan');
		return $q->result();
	}

	function getUsers($postData){
	    $response = array();
	    if(isset($postData['search']) ){
	     	// Select record
	       	$this->db->select('*');
	       	$this->db->where("nama like '%".$postData['search']."%' and status_karyawan='1' ");
	       	$records = $this->db->get('karyawan')->result();
	       	foreach($records as $row ){
	          	$response[] = array(
	          		"value"=>$row->noreg,
	          		"label"=>"(".$row->noreg.") ".$row->nama
	          	);
	       	}
	    }
	    return $response;
	}
	
}