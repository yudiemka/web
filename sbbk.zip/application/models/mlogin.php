<?php
class Mlogin extends CI_Model{	
	function cek_login($table,$where){		
		return $this->db->get_where($table,$where);
	}	

	function cek_idk($idk) {
		$this->db->where('username',$idk);
		$q=$this->db->get('user');
		return $q;
	}

	function data_user($user) {
		$this->db->where('username',$user);
		$q=$this->db->get('user');
		return $q->result();
	}
}