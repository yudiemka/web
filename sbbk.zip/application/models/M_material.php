<?php
class M_material extends CI_Model{	

	function showAll() {
		$this->db->order_by('title','ASC');
		$q=$this->db->get('menu');
		return $q->result();
	}
	function add($table,$data){
		$this->db->insert($table,$data);
	}

	function cekrow() {
		$cekrow=$this->db->get('faktur');
		return $cekrow;
	}

	function cek_tabel() {
		$cek=$this->db->get('keluar_projek');
		return $cek;
	}

	function pilih_data($id) {
		$this->db->where('no_faktur',$id);
		$this->db->where('status','1');
		$q=$this->db->get('tbl_material_smt');
		return $q->result();
	}

	function pilih_data_faktur($id) {
		$this->db->where('no_faktur',$id);
		$q=$this->db->get('faktur');
		return $q->result();
	}

	function form_hutang($id) {
	    $data['id']=$id;  
	     
	    $this->load->view('form_hutang',$data);
	  }

	function beli($table,$update,$data) {
		$this->db->where('rowid',$data);
		$this->db->update($table,$update);
	}


	function pilih_menu_all() {
		$this->db->order_by('id','ASC');
		$q=$this->db->get('menu');
		return $q->result();
	}
	function add_mat_tmp($data,$table){
		$this->db->insert($table,$data);
	}

	function tampil_tmp($cr) {
		$this->db->where('rowid',$cr);
		$this->db->where('status','0');
		$q=$this->db->get('tbl_material_smt');
		return $q->result();
	}	

	function gettotal(){
		$q="SELECT sum(subtotal) AS subtotal from tbl_material_smt where status='0' ";
		$result=$this->db->query($q);
		return $result->row()->subtotal;
	}

	function totalfaktur($id){
		$q="SELECT sum(subtotal) AS subtotal from tbl_material_smt where status='1' AND no_faktur='$id'  ";
		$result=$this->db->query($q);
		return $result->row()->subtotal;
	}

	function tampil_data_faktur() {
		$this->db->order_by('tanggal_faktur','ASC');
		$q=$this->db->get('faktur');
		return $q->result();
	}

	function tampil_data_submenu() {
		$this->db->order_by('id_menu','ASC');
		$q=$this->db->get('submenu');
		return $q->result();
	}

	function akses($status) {
		$this->db->where('status_menu',$status);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function pilih_submenu($idmenu) {
		$this->db->where('id_menu',$idmenu);
		$q=$this->db->get('submenu');
		return $q->result();
	}

	function pilih_menu_id($id) {
		$this->db->where('id_menu',$id);
		$q=$this->db->get('menu');
		return $q->result();
	}
	function edit($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function cek_nrk($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q;
	}

	function cek_nrk_akses($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q->result();
	}

	function menu_in($r) {
		$this->db->where_in('id',$r);
		$this->db->order_by('menu','ASC');
		$q=$this->db->get('menu');
		return $q;
	}

	function menu_not_in($r) {
		$this->db->where_not_in('id',$r);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function update($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function hapus($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}

	function misc() {
		$q=$this->db->get('misc');
		return $q->result();
	}
	


}