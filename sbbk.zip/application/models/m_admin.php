<?php
class M_admin extends CI_Model{	

	function showAll() {
		$q=$this->db->get('kelas');
		return $q->result();
	}
	function add($table,$data){
		$this->db->insert($table,$data);
	}
	function hapus($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}
	function showTa() {
		$this->db->order_by('id','ASC');
		$q=$this->db->get('tahun_ajar');
		return $q->result();
	}	
	function sel_tahun_ajar_aktif() {
		$this->db->where('status','1');
		$q=$this->db->get('tahun_ajar');
		return $q->result();
	}
	function pilih_ta($id){
		$this->db->where('id',$id);
		$q=$this->db->get('tahun_ajar');
		return $q->result();
	}

	function cek_akses_user($iduser) {
		$this->db->where('id_pengguna',$iduser);
		$q=$this->db->get('hak_akses');
		return $q->result();
	}

	function cek_nrk_status($nrk) {
		$this->db->where('noreg',$nrk);
		$q=$this->db->get('karyawan');
		return $q->result();
	}

}