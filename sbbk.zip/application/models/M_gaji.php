<?php
class M_gaji extends CI_Model{	

	function showAll() {
		$this->db->order_by('title','ASC');
		$q=$this->db->get('menu');
		return $q->result();
	}
	function add($table,$data){
		$this->db->insert($table,$data);
	}

	function pilih_menu_all() {
		$this->db->order_by('id','ASC');
		$q=$this->db->get('menu');
		return $q->result();
	}	

	function cek_tabel_gaji() {
		$cek=$this->db->get('gaji');
		return $cek;
	}

	function tampil_data() {
		$this->db->order_by('tanggal_gaji','ASC');
		$q=$this->db->get('gaji');
		return $q->result();
	}

	function tampil_data_submenu() {
		$this->db->order_by('id_menu','ASC');
		$q=$this->db->get('submenu');
		return $q->result();
	}

	function akses($status) {
		$this->db->where('status_menu',$status);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function cekmenu($idmenu) {
		$this->db->where('id_menu',$idmenu);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function pilih_submenu($idmenu) {
		$this->db->where('id_menu',$idmenu);
		$q=$this->db->get('submenu');
		return $q->result();
	}

	function projek($postData){
	    $response = array();
	    if(isset($postData['search']) ){
	     	// Select record
	       	$this->db->select('*');
	       	$this->db->where("nama_projek like '%".$postData['search']."%' ");
	       	$records = $this->db->get('projek')->result();
	       	foreach($records as $row ){
	          	$response[] = array(
	          		"nama_projek"=>$row->nama_projek,
	          		"id_projek"=>$row->id_projek,
	          		"jumlah_unit"=>$row->jumlah_unit,
	          		"lokasi"=>$row->lokasi_projek,
	          	);
	       	}
	    }	    
	    return $response;
	}

	function karyawan($postData){
	    $response = array();
	    if(isset($postData['search']) ){
	     	// Select record
	       	$this->db->select('*');
	       	$this->db->where("nama_karyawan like '%".$postData['search']."%' ");
	       	$records = $this->db->get('karyawan')->result();
	       	foreach($records as $row ){
	          	$response[] = array(
	          		"nama"=>$row->nama_karyawan,
	          		"nrk"=>$row->no_register_karyawan,
	          		"jabatan"=>$row->jabatan_karyawan,
	          		"gapok"=>$row->gaji_pokok_karyawan,
	          	);
	       	}
	    }	    
	    return $response;
	}

	function pilih_menu_id($id) {
		$this->db->where('id_menu',$id);
		$q=$this->db->get('menu');
		return $q->result();
	}
	function edit($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function cek_nrk($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q;
	}

	function cek_nrk_akses($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q->result();
	}

	function menu_in($r) {
		$this->db->where_in('id',$r);
		$this->db->order_by('menu','ASC');
		$q=$this->db->get('menu');
		return $q;
	}

	function menu_not_in($r) {
		$this->db->where_not_in('id',$r);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function update($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function hapus($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}

	function misc() {
		$q=$this->db->get('misc');
		return $q->result();
	}

	function detail_gaji($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('detail_gaji');
		return $q;
	}

	function gettotal($nrk){
		$q="SELECT sum(nominal_gaji) AS totalgaji from detail_gaji where nrk='$nrk' ";
		$result=$this->db->query($q);
		return $result->row()->totalgaji;
	}
	


}