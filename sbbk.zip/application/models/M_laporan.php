<?php
class M_laporan extends CI_Model{


	function pilih_projek($id) {
		$this->db->where('id_projek',$id);
		$q=$this->db->get('projek');
		return $q->result();
	}	

	function pilih_pengeluaran() {
		$this->db->where('jenis_pengeluaran','jb01');
		$this->db->or_where('jenis_pengeluaran','jb03');
		$this->db->or_where('jenis_pengeluaran','jb04');
		$this->db->or_where('jenis_pengeluaran','jb05');
		$this->db->or_where('jenis_pengeluaran','jb07');
		$this->db->order_by('tanggal','ASC');
		$q=$this->db->get('pengeluaran');
		return $q->result();
	}

	//total pemasukan keseluruhan
	function total_masuk(){
		$q="SELECT sum(total_masuk) AS totalmasuk from pemasukan ";
		$result=$this->db->query($q);
		return $result->row()->totalmasuk;
	}

	function total_masuk_hari($tgl){
		$q="SELECT sum(total_masuk) AS totalmasuk from pemasukan where tgl_masuk='$tgl' ";
		$result=$this->db->query($q);
		return $result->row()->totalmasuk;
	}

	function total_masuk_bulan($bulan){
		$q="SELECT sum(total_masuk) AS totalmasuk from pemasukan where MONTH(tgl_masuk)='$bulan' ";
		$result=$this->db->query($q);
		return $result->row()->totalmasuk;
	}

	function total_masuk_tahun($tahun){
		$q="SELECT sum(total_masuk) AS totalmasuk from pemasukan where YEAR(tgl_masuk)='$tahun' ";
		$result=$this->db->query($q);
		return $result->row()->totalmasuk;
	}
	function total_masuk_rentang($tgl1,$tgl2){
		$q="SELECT sum(total_masuk) AS totalmasuk from pemasukan where tgl_masuk between '$tgl1' and '$tgl2'  ";
		$result=$this->db->query($q);
		return $result->row()->totalmasuk;
	}

	//total pemasukan per projek
	function total_masuk_pro($projek){
		$q="SELECT sum(total_masuk) AS totalmasuk from pemasukan where id_projek='$projek' ";
		$result=$this->db->query($q);
		return $result->row()->totalmasuk;
	}

	function total_masuk_hari_pro($projek,$tgl){
		$q="SELECT sum(total_masuk) AS totalmasuk from pemasukan where tgl_masuk='$tgl' and id_projek='$projek' ";
		$result=$this->db->query($q);
		return $result->row()->totalmasuk;
	}

	function total_masuk_bulan_pro($projek,$bulan){
		$q="SELECT sum(total_masuk) AS totalmasuk from pemasukan where MONTH(tgl_masuk)='$bulan' and id_projek='$projek' ";
		$result=$this->db->query($q);
		return $result->row()->totalmasuk;
	}

	function total_masuk_tahun_pro($projek,$tahun){
		$q="SELECT sum(total_masuk) AS totalmasuk from pemasukan where YEAR(tgl_masuk)='$tahun' and id_projek='$projek' ";
		$result=$this->db->query($q);
		return $result->row()->totalmasuk;
	}
	function total_masuk_rentang_pro($projek,$tgl1,$tgl2){
		$q="SELECT sum(total_masuk) AS totalmasuk from pemasukan where tgl_masuk between '$tgl1' and '$tgl2' and id_projek='$projek' ";
		$result=$this->db->query($q);
		return $result->row()->totalmasuk;
	}

	//Total Cashflow Pemasukan

	//total pengeluaran
	function total_keluar($idprojek){
		$q="SELECT sum(total_keluar) AS totalkeluar from keluar_projek where id_projek='$idprojek' ";
		$result=$this->db->query($q);
		return $result->row()->totalkeluar;
	}

	function total_keluar_hari($idprojek,$tgl){
		$q="SELECT sum(total_keluar) AS totalkeluar from keluar_projek where id_projek='$idprojek' and tgl_keluar_projek='$tgl' ";
		$result=$this->db->query($q);
		return $result->row()->totalkeluar;
	}

	function total_keluar_bulan($idprojek,$bulan){
		$q="SELECT sum(total_keluar) AS totalkeluar from keluar_projek where id_projek='$idprojek' and MONTH(tgl_keluar_projek)='$bulan'  ";
		$result=$this->db->query($q);
		return $result->row()->totalkeluar;
	}

	function total_keluar_tahun($idprojek,$tahun){
		$q="SELECT sum(total_keluar) AS totalkeluar from keluar_projek where id_projek='$idprojek' and YEAR(tgl_keluar_projek)='$tahun'  ";
		$result=$this->db->query($q);
		return $result->row()->totalkeluar;
	}
	function total_keluar_rentang($idprojek,$tgl1,$tgl2){
		$q="SELECT sum(total_keluar) AS totalkeluar from keluar_projek where id_projek='$idprojek' and tgl_keluar_projek between '$tgl1' and '$tgl2'  ";
		$result=$this->db->query($q);
		return $result->row()->totalkeluar;
	}

	function total_keluar_ops(){
		$q="SELECT sum(total_keluar_ops) AS totalkeluar from keluar_ops ";
		$result=$this->db->query($q);
		return $result->row()->totalkeluar;
	}

	function total_keluar_ops_hari($tgl){
		$q="SELECT sum(total_keluar_ops) AS totalkeluar from keluar_ops where tgl_bayar_ops='$tgl' ";
		$result=$this->db->query($q);
		return $result->row()->totalkeluar;
	}

	function total_keluar_ops_bulan($bulan){
		$q="SELECT sum(total_keluar_ops) AS totalkeluar from keluar_ops where MONTH(tgl_bayar_ops)='$bulan'  ";
		$result=$this->db->query($q);
		return $result->row()->totalkeluar;
	}

	function total_keluar_ops_tahun($tahun){
		$q="SELECT sum(total_keluar_ops) AS totalkeluar from keluar_ops where YEAR(tgl_bayar_ops)='$tahun'  ";
		$result=$this->db->query($q);
		return $result->row()->totalkeluar;
	}
	function total_keluar_ops_rentang($tgl1,$tgl2){
		$q="SELECT sum(total_keluar_ops) AS totalkeluar from keluar_ops where tgl_bayar_ops between '$tgl1' and '$tgl2'  ";
		$result=$this->db->query($q);
		return $result->row()->totalkeluar;
	}

	//tampil data laporan
	function tampil_data_keluar_hari($projek,$tgl) {
		$this->db->where('id_projek',$projek);
		$this->db->where('tgl_keluar_projek',$tgl);
		$this->db->order_by('tgl_keluar_projek','ASC');
		$q=$this->db->get('keluar_projek');
		return $q->result();
	}	

	function tampil_data_keluar_bulan($projek,$bulan) {
		$query="SELECT * from keluar_projek where MONTH(tgl_keluar_projek)='$bulan' and  id_projek='$projek' ";
		$q=$this->db->query($query);
		return $q->result();
	}

	function tampil_data_keluar_tahun($projek,$tahun) {
		$query="SELECT * from keluar_projek where YEAR(tgl_keluar_projek)='$tahun' and  id_projek='$projek' ";
		$q=$this->db->query($query);
		return $q->result();
	}

	function tampil_data_keluar_rentang($projek,$tgl1,$tgl2) {
		$query="SELECT * from keluar_projek where tgl_keluar_projek between '$tgl1' and '$tgl2' and  id_projek='$projek' ";
		$q=$this->db->query($query);
		return $q->result();
	}
	//operasional

	function tampil_data_keluar_ops_hari($tgl) {
		$this->db->where('tgl_bayar_ops',$tgl);
		$this->db->order_by('tgl_bayar_ops','ASC');
		$q=$this->db->get('keluar_ops');
		return $q->result();
	}	

	function tampil_data_keluar_ops_bulan($bulan) {
		$query="SELECT * from keluar_ops where MONTH(tgl_bayar_ops)='$bulan' ";
		$q=$this->db->query($query);
		return $q->result();
	}

	function tampil_data_keluar_ops_tahun($tahun) {
		$query="SELECT * from keluar_ops where YEAR(tgl_bayar_ops)='$tahun' ";
		$q=$this->db->query($query);
		return $q->result();
	}

	function tampil_data_keluar_ops_rentang($tgl1,$tgl2) {
		$query="SELECT * from keluar_ops where tgl_bayar_ops between '$tgl1' and '$tgl2' ";
		$q=$this->db->query($query);
		return $q->result();
	}

	//Pemasukan keseluruhan

	function tampil_data_masuk_hari($tgl) {
		$query="SELECT * from pemasukan where tgl_masuk='$tgl' ";
		$q=$this->db->query($query);
		return $q->result();
	}
	function tampil_data_masuk_bulan($bulan) {
		$query="SELECT * from pemasukan where MONTH(tgl_masuk)='$bulan' ";
		$q=$this->db->query($query);
		return $q->result();
	}
	function tampil_data_masuk_tahun($tahun) {
		$query="SELECT * from pemasukan where YEAR(tgl_masuk)='$tahun' ";
		$q=$this->db->query($query);
		return $q->result();
	}
	function tampil_data_masuk_rentang($tgl1,$tgl2) {
		$query="SELECT * from pemasukan where tgl_masuk between '$tgl1' and '$tgl2' ";
		$q=$this->db->query($query);
		return $q->result();
	}

	//Pemasukan per projek

	function tampil_data_masuk_pro($idprojek) {
		$query="SELECT * from pemasukan where id_projek='$idprojek' ";
		$q=$this->db->query($query);
		return $q->result();
	}

	function tampil_data_masuk_hari_pro($idprojek,$tgl) {
		$query="SELECT * from pemasukan where id_projek='$idprojek' and tgl_masuk='$tgl' ";
		$q=$this->db->query($query);
		return $q->result();
	}

	
	function tampil_data_masuk_bulan_pro($idprojek,$bulan) {
		$query="SELECT * from pemasukan where id_projek='$idprojek' and MONTH(tgl_masuk)='$bulan' ";
		$q=$this->db->query($query);
		return $q->result();
	}
	function tampil_data_masuk_tahun_pro($idprojek,$tahun) {
		$query="SELECT * from pemasukan where id_projek='$idprojek' and YEAR(tgl_masuk)='$tahun' ";
		$q=$this->db->query($query);
		return $q->result();
	}
	function tampil_data_masuk_rentang_pro($idprojek,$tgl1,$tgl2) {
		$query="SELECT * from pemasukan where id_projek='$idprojek' and tgl_masuk between '$tgl1' and '$tgl2' ";
		$q=$this->db->query($query);
		return $q->result();
	}

	//Tampil Laporan Hutang

	function tampil_hutang() {
		$query="SELECT * from hutang  ";
		$q=$this->db->query($query);
		return $q->result();
	}
	function tampil_hutang_pro_hari($projek,$tgl) {
		$query="SELECT * from hutang where id_projek='$projek' and tgl_faktur='$tgl'  ";
		$q=$this->db->query($query);
		return $q->result();
	}

	function tampil_hutang_pro_bulan($projek,$bulan) {
		$query="SELECT * from hutang where id_projek='$projek' and MONTH(tgl_faktur)='$bulan'  ";
		$q=$this->db->query($query);
		return $q->result();
	}
	function tampil_hutang_pro_tahun($projek,$tahun) {
		$query="SELECT * from hutang where id_projek='$projek' and YEAR(tgl_faktur)='$tahun'  ";
		$q=$this->db->query($query);
		return $q->result();
	}
	function tampil_hutang_pro_rentang($projek,$tgl1,$tgl2) {
		$query="SELECT * from hutang where id_projek='$projek' and tgl_faktur between '$tgl1' and '$tgl2'  ";
		$q=$this->db->query($query);
		return $q->result();
	}

	//total hutang
	function nominal_bayar_faktur(){
		$q="SELECT sum(nominal_bayar) AS nominalbayar from hutang_bayar ";
		$result=$this->db->query($q);
		return $result->row()->nominalbayar;
	}


	// Cashflow Query

	function cf_masuk_bulan_pro($idprojek,$bulan) {
		$query="SELECT * from pemasukan where id_projek='$idprojek' and MONTH(tgl_masuk)='$bulan' ";
		$q=$this->db->query($query);
		return $q;
	}
	function cf_total_masuk_bulan_pro($projek,$bulan){
		$q="SELECT sum(total_masuk) AS totalmasuk from pemasukan where MONTH(tgl_masuk)='$bulan' and id_projek='$projek' ";
		$result=$this->db->query($q);
		return $result->row()->totalmasuk;
	}

	

	function pilih_data_upah($id) {
		$this->db->where('id_upah',$id);
		$q=$this->db->get('upah');
		return $q->result();
	}

	function pilih_data_gaji($id) {
		$this->db->where('id_gaji',$id);
		$q=$this->db->get('gaji');
		return $q->result();
	}

	function pilih_data_lc($id) {
		$this->db->where('id_lc',$id);
		$q=$this->db->get('lc');
		return $q->result();
	}
	function pilih_data_material($id) {
		$this->db->where('no_faktur',$id);
		$q=$this->db->get('faktur');
		return $q->result();
	}
	function pilih_data_operasional($id) {
		$this->db->where('id_operasional',$id);
		$q=$this->db->get('operasional');
		return $q->result();
	}
	function pilih_data_izin($id) {
		$this->db->where('id_izin',$id);
		$q=$this->db->get('izin');
		return $q->result();
	}
	function pilih_data_hutang($id) {
		$this->db->where('id_hutang_bayar',$id);
		$q=$this->db->get('hutang_bayar');
		return $q->result();
	}
	function rinci_faktur($nofaktur) {
		$this->db->where('no_faktur',$nofaktur);
		$q=$this->db->get('tbl_material_smt');
		return $q->result();
	}

	function tampil_data() {
		$this->db->order_by('tanggal_lc','ASC');
		$q=$this->db->get('lc');
		return $q->result();
	}

	function tampil_data_keluar($projek) {
		$this->db->where('id_projek',$projek);
		$this->db->order_by('tgl_keluar_projek','ASC');
		$q=$this->db->get('keluar_projek');
		return $q->result();
	}

	function tampil_data_submenu() {
		$this->db->order_by('id_menu','ASC');
		$q=$this->db->get('submenu');
		return $q->result();
	}

	function akses($status) {
		$this->db->where('status_menu',$status);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function cekmenu($idmenu) {
		$this->db->where('id_menu',$idmenu);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function pilih_submenu($idmenu) {
		$this->db->where('id_menu',$idmenu);
		$q=$this->db->get('submenu');
		return $q->result();
	}

	function pilih_menu_id($id) {
		$this->db->where('id_menu',$id);
		$q=$this->db->get('menu');
		return $q->result();
	}
	function edit($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function cek_nrk($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q;
	}

	function cek_nrk_akses($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('hak_akses');
		return $q->result();
	}

	function menu_in($r) {
		$this->db->where_in('id',$r);
		$this->db->order_by('menu','ASC');
		$q=$this->db->get('menu');
		return $q;
	}

	function menu_not_in($r) {
		$this->db->where_not_in('id',$r);
		$q=$this->db->get('menu');
		return $q->result();
	}

	function update($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function hapus($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}

	function misc() {
		$q=$this->db->get('misc');
		return $q->result();
	}
	


}