<?php
class M_mapel extends CI_Model{	

	function showAll() {
		$this->db->order_by('mapel','ASC');
		$q=$this->db->get('mapel');
		return $q->result();
	}
	function add($table,$data){
		$this->db->insert($table,$data);
	}	
	function hapus($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}
	function sel_idmapel($id) {
		$this->db->where('id',$id);
		$q=$this->db->get('mapel');
		return $q->result();
	}
	function cek_wali($idkelas) {
		$this->db->where('id_kelas',$idkelas);
		$q=$this->db->get('wali_kelas');
		return $q;
	}

	function tatap_muka($nrk) {
		$this->db->where('noreg_guru',$nrk);
		$this->db->order_by('id_kelas');
		$q=$this->db->get('roster');
		return $q->result();
	}
}