<?php
class M_karyawan extends CI_Model{	

	function showAll() {
		$this->db->order_by('nama','ASC');
		$q=$this->db->get('karyawan');
		return $q->result();
	}

	function tampil_data() {
		$this->db->order_by('nama_karyawan','ASC');
		$q=$this->db->get('karyawan');
		return $q->result();
	}
	function cektabel() {
		$q=$this->db->get('karyawan');
		return $q;
	}

	function add($table,$data){
		$this->db->insert($table,$data);
	}	

	function edit($where,$data,$table){
		$this->db->where('no_register_karyawan',$where);
		$this->db->update($table,$data);
	}

	function cek_noreg($noreg){
		$this->db->where('noreg',$noreg);
		$q=$this->db->get('karyawan');
		return $q;
	}

	function cek_nrk($nrk) {
		$this->db->where('no_register_karyawan',$nrk);
		$q=$this->db->get('karyawan');
		return $q->result();
	}

	function hapus($nrk) {
		$this->db->where('no_register_karyawan',$nrk);
		return $this->db->delete('karyawan');
	}

	function hapus_detail_gaji($nrk,$id) {
		$this->db->where('nrk',$nrk);
		$this->db->or_where('id_projek',$id);
		return $this->db->delete('detail_gaji');
	}

	function pilih_data($nrk) {
		$this->db->where('no_register_karyawan',$nrk);
		$q=$this->db->get('karyawan');
		return $q->result();
	}

	function pilih_data_gaji($nrk) {
		$this->db->where('nrk',$nrk);
		$q=$this->db->get('nominal_gaji');
		return $q;
	}

}