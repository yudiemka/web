<?php
class M_masuk extends CI_Model{	

	function tampil_data() {
		$this->db->order_by('tgl_masuk','ASC');
		$query = $this->db->get('pemasukan');
        return $query->result();
	}
	// Cash Flow
	function tampil_data_masuk_hari_pro($tgl,$projek) {
		$this->db->where('tgl_masuk',$tgl);
		$this->db->where('id_projek',$projek);
		$this->db->order_by('tgl_masuk','ASC');
		$q=$this->db->get('pemasukan');
		return $q;
	}

	function tampil_data_keluar_hari_pro($tgl,$projek) {
		$this->db->where('tgl_keluar_projek',$tgl);
		$this->db->where('id_projek',$projek);
		$this->db->order_by('tgl_keluar_projek','ASC');
		$q=$this->db->get('keluar_projek');
		return $q;
	}

	function cf_masuk_bulan_pro($idprojek,$bulan) {
		$query="SELECT * from pemasukan where id_projek='$idprojek' and MONTH(tgl_masuk)='$bulan' ";
		$q=$this->db->query($query);
		return $q;
	}

	function cf_masuk_tahun_pro($idprojek,$tahun) {
		$query="SELECT * from pemasukan where id_projek='$idprojek' and YEAR(tgl_masuk)='$tahun' ";
		$q=$this->db->query($query);
		return $q;
	}

	function cf_masuk_rentang($projek,$tgl1,$tgl2) {
		$query="SELECT * from pemasukan where tgl_masuk between '$tgl1' and '$tgl2' and  id_projek='$projek' ";
		$q=$this->db->query($query);
		return $q;
	}

	function cf_keluar_rentang_pro($projek,$tgl1,$tgl2) {
		$query="SELECT * from keluar_projek where tgl_keluar_projek between '$tgl1' and '$tgl2' and  id_projek='$projek' ";
		$q=$this->db->query($query);
		return $q;
	}

	function cf_keluar_bulan_pro($idprojek,$bulan) {
		$query="SELECT * from keluar_projek where id_projek='$idprojek' and MONTH(tgl_keluar_projek)='$bulan' ";
		$q=$this->db->query($query);
		return $q;
	}
	function cf_keluar_tahun_pro($idprojek,$tahun) {
		$query="SELECT * from keluar_projek where id_projek='$idprojek' and YEAR(tgl_keluar_projek)='$tahun' ";
		$q=$this->db->query($query);
		return $q;
	}

	//end listing cashflow

	function jenis_masuk($jm) {
		$this->db->where('kode',$jm);
		$q=$this->db->get('jenis_masuk');
		return $q->result();
	}

	function jenis_keluar($jk) {
		$this->db->where('kode',$jk);
		$q=$this->db->get('jenis_pengeluaran');
		return $q->result();
	}

	function pilih_detail_masuk($table,$id) {
		$var='id_'.$table;
		$this->db->where($var,$id);
		$q=$this->db->get($table);
		return $q->result();
	}

	function row_data() {
		$q=$this->db->get('tbl_sbbk');
		return $q;
	}

	function add($table,$data){
		$this->db->insert($table,$data);
	}	

	function ceksbbk() {
		$q=$this->db->get('tbl_sbbk');
		return $q;
	}
	
	function cek_surat_minta($no_surat_minta) {
		$this->db->where('no_surat_minta',$no_surat_minta);
		$q=$this->db->get('disposisi');
		return $q;
	}

	function add_minta_tmp($data,$table){
		$this->db->insert($table,$data);
	}

	function cek_minta_tmp($kd_brg,$no_sbbk) {
		$this->db->where('no_sbbk',$no_sbbk);
		$this->db->where('kd_brg',$kd_brg);
		$q=$this->db->get('stok_keluar_tmp');
		return $q;
	}

	function hapus_tmp($nosbbk){
		$hasil=$this->db->query("DELETE FROM tbl_sbbk WHERE no_sbbk='$nosbbk' ");
        return $hasil;
	}
	function hapus_brg_keluar($nosbbk){
		$hasil=$this->db->query("DELETE FROM tbl_brg_keluar WHERE no_sbbk='$nosbbk' ");
        return $hasil;
	}

	function salin_data($nosbbk){
		$salin=$this->db->query("insert into tbl_brg_keluar(no_sbbk,id_brg,jml_brg_keluar,subtotal) select no_sbbk,kd_brg,jml,subtotal from stok_keluar_tmp where no_sbbk='$nosbbk' ");
		return $salin;
	}


	function pilih_data($nosbbk) {
		$this->db->where('no_sbbk',$nosbbk);
		$q=$this->db->get('tbl_sbbk');
		return $q->result();
	}

	function pilih_data_tmp($nosbbk) {
		$this->db->where('no_sbbk',$nosbbk);
		$q=$this->db->get('stok_keluar_tmp');
		return $q->result();
	}

	function pilih_sbbk() {
		$this->db->order_by('no_sbbk','ASC');
		$q=$this->db->get('tbl_sbbk');
		return $q->result();
	}

	function pilih_data_disp($no_disposisi) {
		$this->db->where('no_disposisi',$no_disposisi);
		$q=$this->db->get('disposisi');
		return $q->result();
	}

	function hapus($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}

	public function subtotal_sbbk($nosbbk){
      		return $this->db->query("SELECT sum(subtotal) AS subtotal from tbl_brg_keluar where no_sbbk='$nosbbk' ");
   	}

   	function cek_brg($nosbbk) {
   		$this->db->where('no_sbbk',$nosbbk);
   		$q=$this->db->get('stok_keluar_tmp');
   		return $q->result();
   	}

   	function hapus_data($iddp) {
		$this->db->where('id_masuk',$iddp);
		return $this->db->delete('pemasukan');
	}

	
}