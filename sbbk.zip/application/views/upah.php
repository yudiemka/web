			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Data Menu Sistem</h5> 
					<div>
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#upah">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Data Pembayaran Upah
						</button>
					</div>
				<hr>
				<table class="table table-bordered table-striped" id="myTable">
					<thead class="table-dark">			      
			        	<th width="30">#</th>
			            <th width="150">Tanggal Transaksi</th>
			            <th width="200">Projek</th>
			            <th width="200">Keterangan</th>
			            <th width="200">Penerima Upah</th>
			            <th width="100">Nominal Upah(IDR)</th>
			            <th width="100">Potongan Upah(IDR)</th>
			            <th width="100" align="right">Nominal Upah Dibayarkan</th>
			            <th width="120">Panel</th>                        
			        </thead>  
			        <tbody>
			        <?php
			        $no=1;
			        $data=$this->M_upah->tampil_data_upah(); 
			        foreach($data as $dt) {	   
			        	?>
			        	<tr>
			        		<td><?php echo $no ?></td>			        		
			        		<td><?php echo $dt->tanggal_upah ?></td>
			        		<td>
			        			<?php
			        			$projek=$this->M_projek->pilih_data($dt->id_projek);  
			        			foreach($projek as $pro) {
			        				echo $pro->nama_projek;
			        			}
			        			?>		        				
			        		</td>
			        		<td><?php echo $dt->keterangan_upah ?></i></td>
			        		<td><?php echo $dt->penerima_upah ?></td>
			        		<td align="right"><?php echo number_format($dt->nominal_upah) ?></td>		
			        		<td align="right"><?php echo number_format($dt->potongan_upah) ?></td>		
			        		<td align="right"><?php echo number_format($dt->nominal_upah_bayar) ?></td>			        		
			        		<td>
			        			<div class="cp">
				        			<a href="#"><span>
				        				<button class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i></button>
				        			</a>
				        			<a href="#"><span>
				        				<button class="btn btn-sm btn-info"><i class="fas fa-pen"></i></button>
				        			</a>
				        		</div>
			        		</td>
			        	</tr>
			        	<?php
			        	$no++;
			        }
			        ?>
			        </tbody>
			    </table> 
				</div>
			</div>

<!-- Form Pembayaran -->
<div class="upah modal fade" id="upah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md text-uppercase">
    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Form Pembayaran Upah Pekerja</h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>        
	        <div class="container-fluid p-3" style="text-align: left;">
	        	<form method="post" action="<?php echo base_url().'Upah/add' ?>">
	        	<table class="table table-borderless" >
	        		<tr>
	        			<td>
	        				<label>Tanggal Upah</label>
	        				<input type="date" name="tanggal_upah" class="form-control" placeholder="Tanggal Upah">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Pilih Projek</label>
	        				<input type="text" name="projek" id="projek" class="form-control text-uppercase" placeholder="Ketikan Nama Projek">
	        				<input type="hidden" name="id_projek" id="id_projek">
	        			</td>
	        		</tr>
	        		
	        		<tr>
	        			<td>
	        				<label>Penerima Upah</label>
	        				<input type="text" name="penerima_upah" class="form-control text-uppercase" placeholder="Nama Penerima Upah">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Nominal Upah (IDR)</label>
	        				<input type="text" id="nominal_upah" name="nominal_upah" class="form-control text-uppercase" placeholder="Nominal Upah (IDR)">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Potongan</label>
	        				<input type="text" id="potongan_upah" name="potongan_upah" placeholder="Potongan Gaji (IDR)" class="form-control" onkeyup="sum();">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Nominal Upah Dibayarkan</label>
	        				<input type="text" id="nominal_upah_bayar" name="nominal_upah_bayar" placeholder="Nominal Upah Dibayarkan (IDR)" class="form-control" onchange="return numbersonly(this, event);" onchange="javascript:tandaPemisahTitik(this);" readonly>
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Keterangan Pembayaran Upah</label>
	        				<textarea class="form-control" placeholder="Keterangan Pembayaran Upah" name="keterangan_upah" rows="4"></textarea>
	        			</td>
	        		</tr>
	        	</table>
	        </div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        		</form>
      </div>
    </div>
  </div>
</div>
<!-- Form tambah KPR-->


</body>
<script>
$(document).ready( function () {
	$('#myTable').DataTable();
} );
</script>

<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#projek" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Modal/cari_projek'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        autoFocua:true,
        appendTo:"#modal-fullscreen",
        select: function (event, ui) {
          // Set selection
          $('#projek').val(ui.item.nama_projek); // display the selected text
          $('#id_projek').val(ui.item.id_projek);
          return false;
        }
      })
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='table table-striped'>" )
		.append( "<tr><td width='200'>"+item.nama_projek+"</td><td width='200'>"+item.lokasi_projek+"</td><td width='50'>"+item.jumlah_unit+"</td></tr>" )
		.appendTo( ul );
		};
    });
</script>

<script>
	function sum() {
      var txtFirstNumberValue = document.getElementById('nominal_upah').value;
      var txtSecondNumberValue = document.getElementById('potongan_upah').value;
      var result = (txtFirstNumberValue) - parseInt(txtSecondNumberValue);
      if (!isNaN(result)) {
         document.getElementById('nominal_upah_bayar').value = result;
      }
	}
</script>

</html>




