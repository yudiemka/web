			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Rekapitulasi Data Pembelian Material</h5> 
					<div>
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#material">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Data Pembelian Material
						</button>
					</div>
				<hr>

				

					<table class="table table-bordered table-striped" id="myTable">
						<thead class="table-dark">			      
				    	<th width="20">#</th>
				      <th width="100">Tanggal Faktur</th>
				      <th width="100">No. Faktur</th>
				      <th width="100">Supplier</th>
				      <th width="200">Projek</th>
				      <th width="150">Cash/No Cash</th>
				      <th width="50">Total Faktur (IDR)</th>
				      <th width="75">Panel</th>                        
				    </thead>  
				    <tbody>
				    	<?php
				      $no=1;
				      $faktur=$this->M_material->tampil_data_faktur();
				      foreach($faktur as $f){
				      	?>
				      	<tr>
				      		<td><?php echo $no ?></td>
				      		<td><?php echo $f->tanggal_faktur ?></td>
				      		<td><?php echo $f->no_faktur ?></td>
				      		<td><?php echo $f->suplier ?></td>
				      		<td><?php echo $f->id_projek ?></td>
				      		<td><?php if($f->jenis_bayar=='1'){echo "Cash";}else{echo"Non Cash";} ?></td>
				      		<td align="right"><?php echo number_format($f->total) ?></td>
				      		<td>
				      			<button type="button" class="detail-faktur btn btn-primary btn-sm edit" data-bs-toggle="modal" data-bs-target="#detailfaktur" id="<?php echo $f->no_faktur; ?>">
						          <i class="fas fa-search"></i>
						        </button>
				      		</td>
				      	</tr>
				      	<?php
				      	$no++;
				      }
				      
				      ?>
				    </tbody>
				  </table> 
				</div>
			</div>

<!-- Form Pembelian Material -->
<div class="modal fade" id="material" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl text-uppercase">

  	<?php
  	// Cek row //
  	$cekrow=$this->M_material->cekrow();
  	$cr=$cekrow->num_rows()+1;
  	?>

    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Form Pembelian Material </h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>        
	        <div class="container-fluid p-3" style="text-align: left;">

	        	<form method="post" id="formmaterial" name="formmaterial" action="<?php echo base_url().'Material/beli/';echo $cr ?>">
	        		<input type="hidden" name="row" value="<?php echo $cr ?>" >
	        	<table class="table table-borderless" >
	        		<tr>
	        			<td width="200">
	        				<label>Tanggal Faktur</label>
	        				<input type="date" name="tanggal_faktur" class="form-control" placeholder="Tanggal Faktur">
	        			</td>
	        			<td width="200">
	        				<label>No. faktur</label>
	        				<input type="text" name="no_faktur" id="no_faktur" class="form-control" placeholder="Nomor Faktur Pembelian Material">
	        			</td>
	        			<td>
	        				<label>Cash/Non-Cash</label>
	        				<select name="jenis_bayar" class="form-control">
	        					<option value="00">pilh pembayaran</option>
	        					<option value="1">Cash</option>
	        					<option value="2">Non-Cash</option>
	        				</select>
	        			</td>
	        			<td>
	        				<label>Toko / Suplier</label>
	        				<input type="text" name="suplier" class="form-control" placeholder="Nama Toko / Suplier Material">
	        			</td>
	        			<td>
	        				<label>Projek</label>
	        				<input type="text" name="projek" id="projek" class="form-control" placeholder="Ketikan Projek" id="projek">
	        				<input type="hidden" name="id_projek" id="id_projek">
	        			</td>
	        		</tr>
	        	</table>
	        	<div style="border-top: solid thin #555;">
	        	<table class="table table-borderless">
	        		<tr>
	        			<td width="40%">
	        				<label>Nama Material</label>
	        				<input type="text" name="nama_material" id="nama_material" class="form-control" placeholder="Nama Material">
	        			</td>
	        			<td width="100">
	        				<label>Qty</label>
	        				<input type="text" name="qty" id="qty" class="form-control" id="qty" placeholder="Qty">
	        			</td>
	        			<td width="100">
	        				<label>Satuan</label>
	        				<input type="text" name="satuan" id="satuan" class="form-control" id="satuan" placeholder="Satuan">
	        			</td>
	        			<td>
	        				<label>Harga Satuan (IDR)</label>
	        				<input type="text" name="harga" id="harga" id="harga" class="form-control" placeholder="Harga (IDR)" onkeyup="sum();">
	        			</td>
	        			<td>
	        				<label>Subtotal(IDR)</label>
	        				<input type="text" name="subtotal" id="subtotal" id="subtotal" class="form-control" placeholder="Subtotal (IDR)" readonly>
	        			</td>
	        			<td>
	        				<label>&nbsp;&nbsp;</label>
	        				<button class=" btn btn-primary" id="addmat" type="button"><i class="fas fa-plus-circle"></i></button>
	        			</td>
	        		</tr>
	        	</table>
	        	</div>
	        	<div style="border-top: solid thin #555;padding-top: 10px;">
	        		<h6>List Pembelian Material</h6>
	        		<table class="table table-bordered table-striped table-hover">
	        			<thead class="table-primary">
	        				<th width="30">#</th>
	        				<th>Nama Material</th>
	        				<th>Qty</th>
	        				<th>Satuan</th>
	        				<th>Harga @ (IDR)</th>
	        				<th>Subtotal (IDR)</th>
	        				<th width="30"><i class="fas fa-trash"></i></th>
	        			</thead>
	        			<tbody id="tampil">
	        			</tbody>
	        			<tr>
	        			</tr>
	        		</table>

	        	</div>
	        </div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
       </form>

      </div>
    </div>
  </div>
</div>
<!-- Form tambah KPR-->

<!-- Detail Faktur -->
<div class="modal fade" id="detailfaktur" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl text-uppercase">
    <div class="modal-content">
      <div class="container-fluid bg-primary text-white p-3">
	      <h5 style="font-size: 12pt; float:left;">Detail faktur </h5>
	      <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>        
	    <div class="container-fluid p-3" style="text-align: left;">
	    	<div id="data-faktur"></div>
      </div>
    </div>
  </div>
</div>
<!-- End Detail Faktur-->


</body>
</html>
<script type="text/javascript">
	$(document).ready(function(){
		$('#tampil').load("<?php echo base_url().'Material/list_mat_tmp/';echo $cr ?>");
        $('#addmat').click(function(){
        	var data=$('#formmaterial').serialize();
            $.ajax({
            	type	: 'POST',
                url	: "<?php echo base_url().'Material/add_item_tmp';?>",
                data: data,
                cache	: false,
                success	: function(data){
                	$('#tampil').load("<?php echo base_url().'Material/list_mat_tmp/';echo $cr ?>");
                	$('#nama_material').val("");
                	$('#qty').val("");
                	$('#harga').val("");
                	$('#satuan').val("");
                	$('#subtotal').val("");
                	$('#nama_material').focus();
                	$('#no_faktur').attr("readonly","readonly");
                },
                appendTo:"#modal-fullscreen",
            });
        }); 
    });     
	</script>



<script>
$(document).ready( function () {
	$('#myTable').DataTable();
} );
</script>

<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#projek" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Gaji/projek'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        autoFocua:true,
        appendTo:"#modal-fullscreen",
        select: function (event, ui) {
          // Set selection
          $('#projek').val(ui.item.nama_projek); // display the selected text
          $('#id_projek').val(ui.item.id_projek);
          return false;
        }
      })
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='table table-striped'>" )
		.append( "<tr><td width='200'>"+item.nama_projek+"</td><td width='200'>"+item.lokasi_projek+"</td><td width='50'>"+item.jumlah_unit+"</td></tr>" )
		.appendTo( ul );
		};
    });
</script>

<script>
	$(document).ready(function () {
		tampil_data();
	});            
 
         //fungsi tampil data
	function tampil_data() {
		$.ajax({
			url: "<?php echo base_url().'permintaan/data_minta_tmp' ?>",
			type: 'get',
			success: function(data) {
				$('#list_material_smt').html(data);
			}
		});
	}
</script>

<script>
function sum() {
      var txtFirstNumberValue = document.getElementById('qty').value;
      var txtSecondNumberValue = document.getElementById('harga').value;
      var result = parseInt(txtFirstNumberValue) * parseInt(txtSecondNumberValue);
      if (!isNaN(result)) {
         document.getElementById('subtotal').value = result;
      }
}
</script>

<script>
	
	 $(document).ready(function() {
    $('.detail-faktur').on('click', function() {
    	var idfaktur=$(this).attr("id"); 
      const data = {
        id: idfaktur,
        nama: 'John Doe'
      };

      // Kirim data ke modal
      $('#data-faktur').load('<?php echo base_url().'Material/detail_faktur/' ?>'+data.id);
    });
  });

</script>

</html>




