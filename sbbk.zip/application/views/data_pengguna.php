			<div class="container-fluid container-lg p-3 bg-white my-3 border">
				<h6><?php echo $header ?>&nbsp;
					<a href="<?php echo base_url().'admin/form_pengguna'; ?>">
						<button class="btn btn-primary btn-sm">
							<i class="fas fa-plus-circle"></i>&nbsp;Entry Data Pengguna Sistem
						</button>
					</a>
				</h6>
				<hr>
				<table class="table table-striped table-hover datatab">
			        <thead class="table-primary">
			          <tr>
			            <th width="30">No</th>
			            <th>Nama Legkap</th>
			            <th width="200">Username</th>
			            <th width="200">Passowrd</th>
			            <th width="150">Panel</th>                         
			          </tr>
			        </thead>  
			        <tbody>
			        	<?php
			        	$user=$this->M_user->tampil();
			        	$no=1;
			        	foreach($user as $dt) {
			        		?>
			        		<tr>
			        			<td width="25"><?php echo $no ?></td>
			        			<td><?php echo $dt->nama ?></td>
			        			<td><?php echo $dt->username ?></td>
			        			<td><?php echo $dt->password ?></td>
			        			<td align="center">
			        				<a href="<?php echo base_url().'admin/hak_akses/';echo $dt->id_user; ?>"><span class="badge badge-success">hak Akses</span></a>
				        			<a href="<?php echo base_url().'Pengguna/del/'; echo $dt->id_user;  ?>"><span class="badge badge-danger">hapus</span></a>
			        			</td>
			        		</tr>
			        		<?php
			        		$no++;
			        	}
			        	?>
			        </tbody>
			       
			    </table>     
			</div>
		</div>
	</div>
</body>
  
</html>