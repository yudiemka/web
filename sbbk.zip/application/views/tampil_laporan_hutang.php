<div id="layout">
<?php
if($projek=='0') {
	if($periode=='0') {
		?>
		<h5 class="text-uppercase">Laporan Hutang pembelian Material Perusahaan</h5>
		<h6>Periode laporan : Keseluruhan</h6>
		
		<table class="table table-bordered table-sm table-striped text-uppercase" id="laporan">
			<thead class="table-primary align-middle ">
				<tr>
					<th width="30" rowspan="2" >#</th>
					<th width="150" rowspan="2">No Faktur</th>
					<th width="150" rowspan="2">Tanggal Faktur</th>
					<th  rowspan="2">Projek Perumahan</th>
					<th width="200" rowspan="2">Nominal (IDR)</th>
					<th width="300" colspan="2" class="text-center">Pembayaran</th>
					<th width="200" rowspan="2">Sisa Hutang(IDR)</th>
				</tr>
				<tr>
					<th width="150">Tanggal Bayar</th>
					<th width="150">Jumlah (IDR)</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no=1;
				$data=$this->M_laporan->tampil_hutang();
				foreach($data as $dt) {
					?>
					<tr class="table-success">
						<td><?php echo $no ?></td>
						<td><?php echo $dt->no_faktur ?></td>
						<td><?php echo $dt->tgl_faktur ?></td>
						<td>
							<?php
							$projek=$this->M_projek->pilih_data($dt->id_projek);
							foreach ($projek as $p) { echo $p->nama_projek; }
							?>
						</td>
						<td align="right"><?php echo number_format($dt->nominal_hutang) ?></td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<?php
					//cek pembayaran
					$cekbayar=$this->M_hutang->cekbayar($dt->no_faktur);
					$cb=$cekbayar->num_rows();
					if($cb>0) {
						$datahutang=$cekbayar->result();
						foreach($datahutang as $dh) {
							?>
							<tr class="table-info">
								<td colspan="5"></td>
								<td><?php echo $dh->tgl_bayar ?></td>
								<td align="right"><?php echo number_format($dh->nominal_bayar) ?></td>
								<td></td>
							</tr>
							
							<?php
						}

							//totalnominalbayar
							$totalbayar=$this->M_hutang->total_bayar_faktur($dt->no_faktur);	
							$sisa=$dt->nominal_hutang-$totalbayar;				
							?>
							<tr class="table-secondary">
								<td colspan="7"></td>
								<td align="right"><?php echo number_format($sisa) ?></td>
							</tr>
							<?php
					}
					else {

					}
					?>
					<?php
					$no++;
				}
				?>
			</tbody>
		</table>
		<?php
	}
	else {
		?>
		<span style="font-size: 14pt;"><i>Silahkan Pilih Projek Perumahan Terlebih dahulu !</i></span>
		<?php
	}
}

else {
	if($periode=='0') {
		?>
		<span style="font-size: 14pt;"><i>Silahkan Pilih Periode Laporan Terlebih dahulu !</i></span>
		<?php
	}
	elseif($periode=='1') {
		?>
		<h5 class="text-uppercase">Laporan Hutang pembelian Material Perusahaan</h5>
		<h6>Periode laporan per Tanggal <?php echo $tgl ?></h6>
		<h6>Perumahan :
			<?php
			$pro=$this->M_projek->pilih_data($projek);
			foreach ($pro as $p) { echo $p->nama_projek; }
			?>
		</h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary align-middle ">
				<tr>
					<th width="30" rowspan="2" >#</th>
					<th width="150" rowspan="2">No Faktur</th>
					<th width="150" rowspan="2">Tanggal Faktur</th>
					<th width="200" rowspan="2">Nominal (IDR)</th>
					<th width="300" colspan="2" class="text-center">Pembayaran</th>
					<th width="200" rowspan="2">Sisa Hutang(IDR)</th>
				</tr>
				<tr>
					<th width="150">Tanggal Bayar</th>
					<th width="150">Jumlah (IDR)</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no=1;
				$data=$this->M_laporan->tampil_hutang_pro_hari($projek,$tgl);
				foreach($data as $dt) {
					?>
					<tr class="table-success">
						<td><?php echo $no ?></td>
						<td><?php echo $dt->no_faktur ?></td>
						<td><?php echo $dt->tgl_faktur ?></td>
						<td align="right"><?php echo number_format($dt->nominal_hutang) ?></td>
						<td colspan="3"></td>
					<?php
					//cek pembayaran
					$cekbayar=$this->M_hutang->cekbayar($dt->no_faktur);
					$cb=$cekbayar->num_rows();
					if($cb>0) {
						$datahutang=$cekbayar->result();
						foreach($datahutang as $dh) {
							?>
							<tr class="table-info">
								<td colspan="4"></td>
								<td><?php echo $dh->tgl_bayar ?></td>
								<td align="right"><?php echo number_format($dh->nominal_bayar) ?></td>
								<td></td>
							</tr>
							
							<?php
						}

							//totalnominalbayar
							$totalbayar=$this->M_hutang->total_bayar_faktur($dt->no_faktur);	
							$sisa=$dt->nominal_hutang-$totalbayar;				
							?>
							<tr class="table-secondary">
								<td colspan="6"></td>
								<td align="right"><?php echo number_format($sisa) ?></td>
							</tr>
							<?php
					}
					else {

					}
					?>
					<?php
					$no++;
				}
				?>
			</tbody>
		</table>
		<?php
	}

	elseif($periode=='2') {
		?>
		<h5 class="text-uppercase">Laporan Hutang pembelian Material Perusahaan</h5>
		<h6>Periode laporan per Bulan <?php echo $bulan ?></h6>
		<h6>Perumahan :
			<?php
			$pro=$this->M_projek->pilih_data($projek);
			foreach ($pro as $p) { echo $p->nama_projek; }
			?>
		</h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary align-middle ">
				<tr>
					<th width="30" rowspan="2" >#</th>
					<th width="150" rowspan="2">No Faktur</th>
					<th width="150" rowspan="2">Tanggal Faktur</th>
					<th width="200" rowspan="2">Nominal (IDR)</th>
					<th width="300" colspan="2" class="text-center">Pembayaran</th>
					<th width="200" rowspan="2">Sisa Hutang(IDR)</th>
				</tr>
				<tr>
					<th width="150">Tanggal Bayar</th>
					<th width="150">Jumlah (IDR)</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no=1;
				$data=$this->M_laporan->tampil_hutang_pro_bulan($projek,$bulan);
				foreach($data as $dt) {
					?>
					<tr class="table-success">
						<td><?php echo $no ?></td>
						<td><?php echo $dt->no_faktur ?></td>
						<td><?php echo $dt->tgl_faktur ?></td>
						<td align="right"><?php echo number_format($dt->nominal_hutang) ?></td>
						<td colspan="3"></td>
					<?php
					//cek pembayaran
					$cekbayar=$this->M_hutang->cekbayar($dt->no_faktur);
					$cb=$cekbayar->num_rows();
					if($cb>0) {
						$datahutang=$cekbayar->result();
						foreach($datahutang as $dh) {
							?>
							<tr class="table-info">
								<td colspan="4"></td>
								<td><?php echo $dh->tgl_bayar ?></td>
								<td align="right"><?php echo number_format($dh->nominal_bayar) ?></td>
								<td></td>
							</tr>
							
							<?php
						}

							//totalnominalbayar
							$totalbayar=$this->M_hutang->total_bayar_faktur($dt->no_faktur);	
							$sisa=$dt->nominal_hutang-$totalbayar;				
							?>
							<tr class="table-secondary">
								<td colspan="6"></td>
								<td align="right"><?php echo number_format($sisa) ?></td>
							</tr>
							<?php
					}
					else {

					}
					?>
					<?php
					$no++;
				}
				?>
			</tbody>
		</table>
		<?php
	}
	elseif($periode=='3') {
		?>
		<h5 class="text-uppercase">Laporan Hutang pembelian Material Perusahaan</h5>
		<h6>Periode laporan per Tahun <?php echo $tahun ?></h6>
		<h6>Perumahan :
			<?php
			$pro=$this->M_projek->pilih_data($projek);
			foreach ($pro as $p) { echo $p->nama_projek; }
			?>
		</h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary align-middle ">
				<tr>
					<th width="30" rowspan="2" >#</th>
					<th width="150" rowspan="2">No Faktur</th>
					<th width="150" rowspan="2">Tanggal Faktur</th>
					<th width="200" rowspan="2">Nominal (IDR)</th>
					<th width="300" colspan="2" class="text-center">Pembayaran</th>
					<th width="200" rowspan="2">Sisa Hutang(IDR)</th>
				</tr>
				<tr>
					<th width="150">Tanggal Bayar</th>
					<th width="150">Jumlah (IDR)</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no=1;
				$data=$this->M_laporan->tampil_hutang_pro_tahun($projek,$tahun);
				foreach($data as $dt) {
					?>
					<tr class="table-success">
						<td><?php echo $no ?></td>
						<td><?php echo $dt->no_faktur ?></td>
						<td><?php echo $dt->tgl_faktur ?></td>
						<td align="right"><?php echo number_format($dt->nominal_hutang) ?></td>
						<td colspan="3"></td>
					<?php
					//cek pembayaran
					$cekbayar=$this->M_hutang->cekbayar($dt->no_faktur);
					$cb=$cekbayar->num_rows();
					if($cb>0) {
						$datahutang=$cekbayar->result();
						foreach($datahutang as $dh) {
							?>
							<tr class="table-info">
								<td colspan="4"></td>
								<td><?php echo $dh->tgl_bayar ?></td>
								<td align="right"><?php echo number_format($dh->nominal_bayar) ?></td>
								<td></td>
							</tr>
							
							<?php
						}

							//totalnominalbayar
							$totalbayar=$this->M_hutang->total_bayar_faktur($dt->no_faktur);	
							$sisa=$dt->nominal_hutang-$totalbayar;				
							?>
							<tr class="table-secondary">
								<td colspan="6"></td>
								<td align="right"><?php echo number_format($sisa) ?></td>
							</tr>
							<?php
					}
					else {

					}
					?>
					<?php
					$no++;
				}
				?>
			</tbody>
		</table>
		<?php
	}
	elseif($periode=='4') {
		?>
		<h5 class="text-uppercase">Laporan Hutang pembelian Material Perusahaan</h5>
		<h6>Periode laporan per Tanggal <?php echo $tgl1 ?> s.d Tanggal <?php echo $tgl2 ?> </h6>
		<h6>Perumahan :
			<?php
			$pro=$this->M_projek->pilih_data($projek);
			foreach ($pro as $p) { echo $p->nama_projek; }
			?>
		</h6>
		<table class="table table-bordered table-sm table-striped text-uppercase" id="myTable">
			<thead class="table-primary align-middle ">
				<tr>
					<th width="30" rowspan="2" >#</th>
					<th width="150" rowspan="2">No Faktur</th>
					<th width="150" rowspan="2">Tanggal Faktur</th>
					<th width="200" rowspan="2">Nominal (IDR)</th>
					<th width="300" colspan="2" class="text-center">Pembayaran</th>
					<th width="200" rowspan="2">Sisa Hutang(IDR)</th>
				</tr>
				<tr>
					<th width="150">Tanggal Bayar</th>
					<th width="150">Jumlah (IDR)</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$no=1;
				$data=$this->M_laporan->tampil_hutang_pro_rentang($projek,$tgl1,$tgl2);
				foreach($data as $dt) {
					?>
					<tr class="table-success">
						<td><?php echo $no ?></td>
						<td><?php echo $dt->no_faktur ?></td>
						<td><?php echo $dt->tgl_faktur ?></td>
						<td align="right"><?php echo number_format($dt->nominal_hutang) ?></td>
						<td colspan="3"></td>
					<?php
					//cek pembayaran
					$cekbayar=$this->M_hutang->cekbayar($dt->no_faktur);
					$cb=$cekbayar->num_rows();
					if($cb>0) {
						$datahutang=$cekbayar->result();
						foreach($datahutang as $dh) {
							?>
							<tr class="table-info">
								<td colspan="4"></td>
								<td><?php echo $dh->tgl_bayar ?></td>
								<td align="right"><?php echo number_format($dh->nominal_bayar) ?></td>
								<td></td>
							</tr>
							
							<?php
						}

							//totalnominalbayar
							$totalbayar=$this->M_hutang->total_bayar_faktur($dt->no_faktur);	
							$sisa=$dt->nominal_hutang-$totalbayar;				
							?>
							<tr class="table-secondary">
								<td colspan="6"></td>
								<td align="right"><?php echo number_format($sisa) ?></td>
							</tr>
							<?php
					}
					else {

					}
					?>
					<?php
					$no++;
				}
				?>
			</tbody>
		</table>
		<?php
	}
}


?>

</div>

<iframe id="printing-frame" name="print_frame" src="about:blank" style="display:none;"></iframe>
<script type="text/javascript">
function printDiv(elementId) {
	var myPrintContent = document.getElementById('tampil');
  var myPrintWindow = window.open('','','');
  myPrintWindow.document.write('<html><head>');
  myPrintWindow.document.write('<link rel="stylesheet" href="<?php echo base_url() ?>assets/lib/bs5/css/bootstrap.min.css">');
  myPrintWindow.document.write('<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/cetak.css">');
  myPrintWindow.document.write('</head><body>');
  myPrintWindow.document.write(myPrintContent.innerHTML);
  myPrintWindow.document.write('</body></html>');            
  myPrintWindow.document.getElementById('tampil').style.display = 'block';
  myPrintWindow.document.close();

 return false;
}

</script>

