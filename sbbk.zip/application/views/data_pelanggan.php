			<div class="container-fluid container-lg p-3 bg-white my-3 border">
				<h6>Data Pelanggan Perushaan&nbsp;
					<a href="<?php echo base_url().'admin/form_pelanggan'; ?>">
						<button class="btn btn-primary btn-sm">
							<i class="fas fa-book"></i>&nbsp;Pelanggan
						</button>
					</a>
				</h6>
				<hr>
				<table class="table table-striped table-hover data" id="datatable">
			        <thead class="table-primary">
			          <tr>
			            <th width="30">No</th>
			            <th width="250">Nama Pelanggan</th>
			            <th width="150">Jenis Identitas /<br> No. Identitas</th> 
			            <th>Alamat Pelanggan / Perusahaan</th>
			            <th width="150">No. Kontak</th>
			            <th width="60">Panel</th>                   
			          </tr>
			        </thead>  
			        <tbody>
			        <?php
			        $no=1;
			        $pelanggan=$this->M_pelanggan->tampil_data(); 
			        foreach($pelanggan->result() as $dt) {	
			        	if($dt->jenis_id=='1') {$id='KTP';}
			        	elseif($dt->jenis_id=='0'){$id='Jenis Identitas';}
			        	else{$id="Lainya";}		        	
			        	?>
			        	<tr>
			        		<td><?php echo $no ?></td>			        		
			        		<td style="text-transform: uppercase;"><?php echo $dt->nama ?></td>
			        		<td><?php echo $id  ?><br><?php echo $dt->no_id  ?></td>
			        		<td style="text-transform: uppercase;"><?php echo $dt->alamat ?></td>
			        		<td><?php echo $dt->kontak ?></td>
			        		<td>
			        			<a href="<?php echo base_url().'Kontrak/del/';echo $dt->id ?>"><span class="panel"><i class="fas fa-trash"></i></span></a>
			        			<a href="#"><span class="panel"><i class="fas fa-pen"></i></span></a>
			        		</td>
			        	</tr>
			        	<?php
			        	$no++;
			        }
			        ?>
			        </tbody>
			    </table>     
			</div>
		</div>
	</div>


</body>
<script>
$(document).ready(function() {
$('#datatable').DataTable();
} );
</script>


  
</html>
