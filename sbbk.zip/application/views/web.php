<!DOCTYPE html>
<html>
<head>
  <title>SIMKU - MIRANDA GRUP</title>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/bs5/css/bootstrap.min.css"> 
  <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/jquery14/jquery-ui.css">
  <script type="text/javascript" src="<?php echo base_url().'assets/icon/js/all.min.js'?>"></script>
  <script src="<?php echo base_url() ?>assets/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url() ?>assets/lib/bootstrap/js/bootstrap.js"></script>
  <script src="<?php echo base_url() ?>assets/lib/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url() ?>assets/lib/jquery/jquery.js"></script>
  <script src="<?php echo base_url() ?>assets/lib/jquery/jquery-3.3.1.js"></script>
  <script src="<?php echo base_url() ?>assets/lib/jquery14/jquery-ui.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/DataTables/datatables.min.css"/> 
  <script type="text/javascript" src="<?php echo base_url() ?>assets/lib/DataTables/datatables.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>assets/js/number.js"></script>
  <script src="<?php echo base_url() ?>assets/lib/bs5/css/bootstrap.min.css"></script>
  <script src="<?php echo base_url() ?>assets/lib/bs5/js/bootstrap.bundle.min.js"></script> 
  <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/style.css"> 
  <script src="<?php echo base_url() ?>assets/lib/jquery/jquery-ui.js"></script>

  <script type="text/javascript" src="js/jquery-ui/jquery-ui.js"></script>
  <link rel="stylesheet" type="text/css" href="js/jquery-ui/jquery-ui.css">


</head>
<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Logo</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>  
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Dropdown</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Link</a></li>
            <li><a class="dropdown-item" href="#">Another link</a></li>
            <li><a class="dropdown-item" href="#">A third link</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
</body>