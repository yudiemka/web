		<div id="content-bar">
			<div class="box container-fluid bg-white p-3 text-dark"> 
				<b><?php echo $header ?></b>
				<div style="float: right;margin-top: -5px;">
					<a href="<?php echo base_url().'admin/formaddkelas'; ?>">
						<a href="<?php echo base_url().'admin/addstok'; ?>">
						<button class="btn btn-primary"><i class="fas fa-plus-circle"></i>&nbsp;Data S B B K</button>	
					</a>	
				</div>
				<br>
			</div>
			<?php
			$nama=$this->session->userdata("nama");
			$hak=$this->session->userdata("hak_akses");
			?>	
			<div class="box container-fluid bg-white p-3 my-2 text-dark"> 
				<form id="sbbk" action="<?php echo base_url().'sbbk/proses_sbbk' ?>" method="post">
					<table class="table">
						<tr>
							<td>
								<label>Nomor SBBK</label>
																
								<input type="text" name="no_sbbk" id="no_sbbk" class="form-control">
								<input type="hidden" name="staff_logistik" value="<?php echo $nama ?>">
							</td>
							<td>
								<label>Tanggal SBBK</label>
								
								<input type="date" name="tgl_sbbk" class="form-control">
							</td>
						</tr>
						<tr>
							<td colspan="2">
								<label>Instansi Penerima</label>
								<input type="text" name="instansi" placeholder="Instansi Penerima Barang" class="form-control">
							</td>
						</tr>
					</table>
				</div>
				<div class="box container-fluid bg-white p-3 my-2 text-dark">
					<table  class="table">
						<tr>
							<td>
								<label>Nama Barang</label>
								<input type="text" name="key_brg" id="key_brg" class="form-control" placeholder="Ketikan Nama Barang">
							</td>
						</tr>
					</table>
					<table class="table">
						<tr>
							<td width="100">
								<label>Kode</label>
								<input type="text" name="kd_brg" id="kd_brg" class="form-control" readonly>
							</td>
							<td>
								<label>Nama Barang</label>
								<input type="text" name="nm_brg" id="nm_brg" class="form-control" readonly>
							</td>
							<td width="50">
								<label>Satuan</label>
								<input type="text" name="satuan" id="satuan" class="form-control" readonly>
							</td>
							<td  width="120">
								<label>Jumlah</label>
								<input type="number" name="qty" id="qty" class="form-control" onkeyup="sum()" value="0">
							</td>
							<td>
								<label>Harga Satuan Barang</label>
								<input type="text" name="hrg_brg" id="hrg_brg" class="form-control" readonly>
							</td>
							<td>
								<label>Sub Total Harga</label>
								<input type="text" name="subtotal" id="subtotal" class="form-control" >
							</td>
							<td width="50">
								<label>Aksi</label>
								<button class="add btn btn-primary" type="button" id="btn-add">
									<i class="fas fa-plus-circle"></i>
								</button>
							</td>
						</tr>
					</table>
					<table class="table table-bordered table-striped">
						<tr>
							<th width="25">No.</th>
							<th width="100">Kode</th>
							<th width="200">Nama Barang</th>
							<th width="120">Satuan</th>
							<th width="150">Harga Satuan</th>
							<th width="120">Jumlah</th>
							<th width="150">Sub Total</th>
							<th width="50">Aksi</th>
						</tr>
						<tbody id="tampil"></tbody>
					</table>
					<hr>
					<table>
						<tr>
							<td>
								<button type="submit" class="btn btn-primary">
									<i class="fas fa-save"></i>&nbsp;Proses Data SBBK
								</button>
								<button type="reset" class="btn btn-danger">
									<i class="fas fa-times-circle"></i>&nbsp;Batal Proses Data SBBK
								</button>
							</td>
						</tr>
					</table>
				</div>
			</div>
		</form>
	</div>
</body>
<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#key_brg" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'stok/cari_nm_brg'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        select: function (event, ui) {
          // Set selection
          var hrg=ui.item.hrg_brg;
          $('#nm_brg').val(ui.item.nm_brg); // display the selected text
          $('#kd_brg').val(ui.item.kd_brg);
          $('#satuan').val(ui.item.satuan);
          $('#hrg_brg').val(hrg);
          $("#jml").focus();
          return false;
        }
      })
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='auto'>" )
		.append( "<tr><td width='300'>"+item.nm_brg+"</td><td width='150'>"+item.satuan+"</td><td width='150'>"+item.hrg_brg+"</td><td width='300'>"+item.pengadaan+"</td><td>"+item.tgl_eksp+"</td></tr>" )
		.appendTo( ul );
		};
    });
</script>
<script type="text/javascript">
	$(document).ready(function(){
        $('#btn-add').click(function(){
        	var nosbbk=$('#no_sbbk').val();
        	var tglsbbk=$('#tgl_sbbk').val();\
        	var kdbrg=$('#kd_brg').val();
        	var qty=$('#qty').val();
        	var instansi=$('#instansi').val();
        	var sbt=$('#subtotal').val();
            $.ajax({
            	type	: 'POST',
                url	: "<?php echo base_url().'permintaan/sbbk_tmp' ?>",
                data: {no:nosbbk;tgl:tglsbbk;kdbrg;kbrg;qty:qty;instansi:instansi;sbt:sbt},
                cache	: false,
                success	: function(data){
                	$('#tampil').load("<?php echo base_url().'permintaan/data_sbbk_tmp' ?>");
                	$('#nm_brg').val(""); // display the selected text
		          	$('#kd_brg').val("");
		          	$('#satuan').val("");
		          	$('#hrg_brg').val("");
		          	$("#subtotal").val("");
		          	$("#jml").val("");
		          	$("#key_brg").val("");
		          	$("#key_brg").focus();
                }
            });
        }); 
    });     
</script>
<script>
function sum() {
      var txtFirstNumberValue = document.getElementById('jml').value;
      var txtSecondNumberValue = document.getElementById('hrg_brg').value;
      var result = parseInt(txtFirstNumberValue) * parseInt(txtSecondNumberValue);
      if (!isNaN(result)) {
         document.getElementById('subtotal').value = result;
      }
}
</script>


</html>