		<div id="content-bar">
			<div class="box container-fluid bg-white p-3 text-dark"> 
				<b><?php echo $header ?></b>
				<div style="float: right;margin-top: -5px;">
					<a href="<?php echo base_url().'admin/form_sbbk'; ?>">
						<button class="btn btn-primary"><i class="fas fa-plus-circle"></i>&nbsp;Data S B B K</button>	
					</a>
					<a href="<?php echo base_url().'admin/input_sbbk'; ?>">
						<button class="btn btn-primary"><i class="fas fa-plus-circle"></i>&nbsp;Entry SBBK Manual</button>	
					</a>		
				</div>
			</div>
			<div class="box container-fluid bg-white p-3 my-2 text-dark"> 
				<form>
					<table class="">
						<tr>
							<td>
								<input type="text" name="key" class="form-control" placeholder="Ketikan Kata Kunci Pencariaon..">
							</td>
							<td width="50">
								<button class="btn btn-primary">
									<i class="fas fa-search"></i>
								</button>
							</td>
						</tr>
					</table>
				</form>
				<br>
				<table class="data table table-bordered table-hover">
					<tr class="table-primary">
						<th width="20">No.</th>
						<th width="10"><i class="fas fa-trash-alt"></i></th>
						<th width="140">Nomor SBBK</th>
						<th width="100">Tanggal SBBK</th>
						<th width="300">Instansi Penerima</th>
						<th width="100">Staff Logistik</th>
						<th width="20"><i class="fas fa-print"></i></th>
					</tr>
					<?php
					$no = $this->uri->segment('3') + 1;
					foreach($sbbk->result() as $dt) {
						?>
						<tbody id="tampil">
							<tr>
								<td><?php echo $no ?></td>
								<td align="center">
									<a href="#" class="del" id="<?php echo $dt->no_sbbk ?>">
										<i class="fas fa-trash-alt" ></i>
									</a>
								</td>
								<td align="center">442/DINKES.7.3/<?php echo $dt->no_sbbk ?></td>
								<td align="center"><?php echo $dt->tgl_sbbk ?></td>
								<td><?php echo $dt->instansi ?></td>
								<td align="center"><?php echo $dt->staff_logistik ?></td>
								<td align="center">
									<a href="<?php echo base_url().'sbbk/cetak/';echo $dt->no_sbbk ?>" target="_blank">
										<i class="fas fa-print"></i>
									</a>
								</td>
							</tr>
						</tbody>
						<?php
						$no++;
					}
					?>
				</table>
					<table class="table">
						<tr>
							<td>
								<div id="paging"><?php echo $pagination; ?></div>
							</td>
						</tr>
					</table>
			</div>
		</div>
	</div>
</body>
<script type="text/javascript">
	$(document).ready(function(){
        $('.del').click(function(){
        	var nosbbk=$(this).attr('id');
            $.ajax({
            	type	: 'POST',
                url	: "<?php echo base_url().'sbbk/del_sbbk';?>",
                data: {nosbbk:nosbbk},
                cache	: false,
                success	: function(data){
                	window.location='/sbbk/admin/sbbk';
                }
            });
        }); 
    });     
</script>
</html>