<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tabel 5 - Gilacoding.com</title>
 <style type="text/css">
    body {
  background: #eee;
  font-family: 'Segoe UI';
  padding: 20px;
  text-align: center;
}
.tabel5 {
  border-collapse: collapse;
  margin: 25px auto;
  width: 1200px; /*silahkan disesuaikan width nya*/
  
}
.tabel5 thead tr {
  background-color: #ff48b4;
  color: #ffffff;
  font-weight: bold;
}
.tabel5 th,
.tabel5 td {
  text-align: left;
  padding: 5px;
  font-size: 10pt;
}
.tabel5 tbody tr {
  border-bottom: 1px solid #dddddd;
}
.tabel5 tbody tr:nth-of-type(even) {
  background-color: #f3f3f3;
}
.tabel5 tbody tr:last-of-type {
  border-bottom: 2px solid #ff48b4;
}
.tabel5 tbody tr.active-row {
  font-weight: bold;
  color: #ff48b4;
}
  .tabel5 tr:hover > td {
    background: #ddd !important;
    color: #ff48b4;
  }


    </style>
</head>
<body>
<table class="tabel5">
  <thead>
   <tr>
      <th>No</th>
      <th>Nama</th>
      <th>Asal</th>
      <th>Tgl Lahir</th>
      <th>No Hp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Tretan Muslim</td>
      <td>Bangkalan</td>
      <td>1991-03-10</td>
      <td>0800 0000 0000</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Coki Pardede</td>
      <td>Jakarta</td>
      <td>1988-01-21</td>
      <td>0800 0000 0000</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Mukti Entut EL Metronom</td>
      <td>Yogyakarta</td>
      <td>1991-04-07</td>
      <td>0800 0000 0000</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Dono Pradana</td>
      <td>Surabaya</td>
      <td>1989-04-16</td>
      <td>0800 0000 0000</td>
    </tr>
  </tbody>
</table>

</body>
</html>