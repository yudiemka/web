			
			
				<div class="container-fluid p-5 bg-white">
					<h6 class="text-uppercase">Laporan Pengeluaran Operasional Perusahaan</h6>
					<hr>
					<form id="formlaporan" name="formlaporan" method="get">
						<table class="table table-borderless">
							<tr>
								<td width="300">
									<select class="form-control" name="periode" id="periode">
										<option value="0">Pilih Periode</option>
										<option value="1">Hari</option>
										<option value="2">Bulan</option>
										<option value="3">Tahun</option>
										<option value="4">Rentang Tanggal</option>
									</select>
								</td>
								<td width="300">
									<div id="jenisperiode"></div>
								</td>	
								<td width="150">
									<button type="submit" id="btn-tampil" class="btn btn-primary">TAMPIL</button>
									<a href="javascript:printDiv('tampil');" class="btn btn-primary"><i class="fas fa-print"></i></a>
								</td>
								<td></td>
							</tr>
						</table>
					</form>
				</div>
				<br>
				<div id="tampil" class="container-fluid p-5 bg-white">
					<h6>Silahkan Pilih Jenis Laporan</h6>
				</div>
			</div>

		</div>
	</div>
</body>

</html>


<script>
$(document).ready(function(){
  $("#btn-tampil").click(function(){ // Ketika tombol simpan di klik
    // Ubah text tombol search menjadi SEARCHING... 
    // Dan tambahkan atribut disable pada tombol nya agar tidak bisa diklik lagi
    $(this).html("SEARCHING...").attr("disabled", "disabled");
    
    $.ajax({
      url: "<?php echo base_url().'Laporan/tampil_laporan_ops'?>", // File tujuan
      type: 'POST', // Tentukan type nya POST atau GET
      data: {
	      periode:$("#periode").val(),
	      jp:$("#jenis_lap").val(),
	      tgl:$("#tanggalperiode").val(),
	      bulan:$("#bulan").val(),
	      tahun:$("#tahun").val(),
	      tgl1:$("#tgl1").val(),
	      tgl2:$("#tgl2").val(),
      }, // Set data yang akan dikirim
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){ // Ketika proses pengiriman berhasil
        // Ubah kembali text button search menjadi SEARCH
        // Dan hapus atribut disabled untuk meng-enable kembali button search nya
        $("#btn-tampil").html("TAMPIL").removeAttr("disabled");
        
        // Ganti isi dari div view dengan view yang diambil dari controller siswa function search
        $("#tampil").html(response.hasil);
      },
      error: function (xhr, ajaxOptions, thrownError) { // Ketika terjadi error
        alert(xhr.responseText); // munculkan alert
      }
    });
  });
});
</script>

<script type="text/javascript">
$(document).ready(function(){
	$("#periode").change(function(){			
			$.ajax({
				url: "<?php echo base_url().'Laporan/periode' ?>",	
				type:'POST',
				data:{periode:$('#periode').val()},
				dataType: "json",
				beforeSend: function(e) {
	        if(e && e.overrideMimeType) {
	          e.overrideMimeType("application/json;charset=UTF-8");
	        }
	      },
				success: function(response){
					$("#jenisperiode").html(response.hasil);
				},
				error: function (xhr, ajaxOptions, thrownError) { // Ketika terjadi error
	        alert(xhr.responseText); // munculkan alert
	      }
			})		
	});
})


</script>
<script>
$(document).ready( function () {
		$('#laporan').DataTable({
	    dom: 'Bftip',
	    buttons: [
	        'copy', 'excel', 'pdf'
	    ]
	});
} );
</script>