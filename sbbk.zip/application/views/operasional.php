			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Data Pengeluaran Operasional Perusahaan</h5> 
					<div>
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#operasional">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Data Pengeluaran Operasional
						</button>
					</div>
				<hr>

				

					<table class="table table-bordered table-striped" id="myTable">
						<thead class="table-dark">			      
				    	<th width="20">#</th>
				      <th width="100">Tanggal Bayar</th>
				      <th width="">Rincian Pembayaran</th>
				      <th width="150">Nominal (IDR)</th>
				      <th width="300">Keterangan</th>
				      <th width="150">Panel</th>                        
				    </thead>  
				    <tbody>
				    	<?php
				      $no=1;
				      $query=$this->M_operasional->tampil_data();
				      foreach($query as $q){
				      	?>
				      	<tr>
				      		<td><?php echo $no ?></td>
				      		<td><?php echo $q->tgl_bayar ?></td>
				      		<td><?php echo $q->rincian ?></td>				      		
				      		<td align="right"><?php echo number_format($q->nominal) ?></td>
				      		<td><?php echo $q->keterangan ?></td>
				      		<td>
				      			<button class="btn btn-sm btn-info">
				      				<i class="fas fa-clipboard"></i>
				      			</button>
				      			<button class="btn btn-sm btn-danger">
				      				<i class="fas fa-trash-alt"></i>
				      			</button>
				      			<button class="btn btn-sm btn-primary">
				      				<i class="fas fa-search"></i>
				      			</button>
				      		</td>
				      	</tr>
				      	<?php
				      	$no++;
				      }
				      
				      ?>
				    </tbody>
				  </table> 
				</div>
			</div>

<!-- Form Pengeluaran Operasional -->
<div class="modal fade" id="operasional" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modallg text-uppercase">

  	<div class="modal-content">
      <div class="container-fluid bg-primary text-white p-3">
	      <h5 style="font-size: 12pt; float:left;">Form Pengeluaran Operasional</h5>
	      <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>        
	    
	    <div class="container-fluid p-3" style="text-align: left;">
	    	<form method="post" id="formmaterial" name="formmoperasional" action="<?php echo base_url().'Operasional/add';?>">
	      <table class="table table-borderless">
	      	<tr>
	      		<td>
	      			<label>Tanggal</label>
	      			<input type="date" name="tanggal" class="form-control text-uppercase" placeholder="Ketikan Nama Projek" id="tanggal_bayar">
	      		</td>
	      	</tr>
	      	<tr>
	      		<td>
	      			<label>Rincian</label>
	      			<textarea class="form-control" placeholder="Rincian Pembayaran" name="rincian"></textarea>
	      		</td>
	      	</tr>
	      	<tr>
	      		<td>
	      			<label>Nominal Bayar (IDR)</label>
	      			<input type="text" name="nominal" class="form-control" placeholder="Nominal Pembayaran Izin" id="nominal">
	      		</td>
	      	</tr>	      	
	      	<tr>
	      		<td>
	      			<label>Keterangan</label>
	      			<textarea class="form-control" placeholder="Keterangan Pembayaran" name="keterangan"></textarea>
	      		</td>
	      	</tr>
	      </table>  		
	    </div>
      	
      <div class="modal-footer" style="float: right">
        	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        	<button type="submit" class="btn btn-primary">Simpan</button>
       	</form>
      </div>
    </div>
  </div>
</div>
<!-- Form tambah KPR-->

<!-- Detail Faktur -->
<div class="modal fade" id="detailfaktur" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl text-uppercase">
    <div class="modal-content">
      <div class="container-fluid bg-primary text-white p-3">
	      <h5 style="font-size: 12pt; float:left;">Detail faktur </h5>
	      <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>        
	    <div class="container-fluid p-3" style="text-align: left;">
	    	<div id="data-faktur"></div>
      </div>
    </div>
  </div>
</div>
<!-- End Detail Faktur-->


</body>
</html>
<script type="text/javascript">
	$(document).ready(function(){
		$('#tampil').load("<?php echo base_url().'Material/list_mat_tmp/';echo $cr ?>");
        $('#addmat').click(function(){
        	var data=$('#formmaterial').serialize();
            $.ajax({
            	type	: 'POST',
                url	: "<?php echo base_url().'Material/add_item_tmp';?>",
                data: data,
                cache	: false,
                success	: function(data){
                	$('#tampil').load("<?php echo base_url().'Material/list_mat_tmp/';echo $cr ?>");
                	$('#nama_material').val("");
                	$('#qty').val("");
                	$('#harga').val("");
                	$('#satuan').val("");
                	$('#subtotal').val("");
                	$('#nama_material').focus();
                	$('#no_faktur').attr("readonly","readonly");
                },
                appendTo:"#modal-fullscreen",
            });
        }); 
    });     
	</script>



<script>
$(document).ready( function () {
	$('#myTable').DataTable();
} );
</script>

<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#projek" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Modal/cari_projek'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        autoFocua:true,
        appendTo:"#modal-fullscreen",
        select: function (event, ui) {
          // Set selection
          $('#projek').val(ui.item.nama_projek); // display the selected text
          $('#id_projek').val(ui.item.id_projek);
          return false;
        }
      })
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='table table-striped'>" )
		.append( "<tr><td width='200'>"+item.nama_projek+"</td><td width='200'>"+item.lokasi_projek+"</td><td width='50'>"+item.jumlah_unit+"</td></tr>" )
		.appendTo( ul );
		};
    });
</script>

<script>
	$(document).ready(function () {
		tampil_data();
	});            
 
         //fungsi tampil data
	function tampil_data() {
		$.ajax({
			url: "<?php echo base_url().'permintaan/data_minta_tmp' ?>",
			type: 'get',
			success: function(data) {
				$('#list_material_smt').html(data);
			}
		});
	}
</script>

<script>
function sum() {
      var txtFirstNumberValue = document.getElementById('qty').value;
      var txtSecondNumberValue = document.getElementById('harga').value;
      var result = parseInt(txtFirstNumberValue) * parseInt(txtSecondNumberValue);
      if (!isNaN(result)) {
         document.getElementById('subtotal').value = result;
      }
}
</script>

<script>
	
	 $(document).ready(function() {
    $('.detail-faktur').on('click', function() {
    	var idfaktur=$(this).attr("id"); 
      const data = {
        id: idfaktur,
        nama: 'John Doe'
      };

      // Kirim data ke modal
      $('#data-faktur').load('<?php echo base_url().'Material/detail_faktur/' ?>'+data.id);
    });
  });

</script>

</html>




