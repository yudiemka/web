
<?php



$data=$this->m_permintaan->pilih_data_minta_tmp($nosbbk);
$no=1;
foreach ($data as $dt){
	$stok=$this->m_stok->pilih_stok($dt->kd_brg);
	foreach($stok as $s)
		if($s->harga=='0') {
			$subtotal="-";
			$harga="-";
		}
		else {
			$subtotal="Rp&nbsp;".number_format($dt->jml*$s->harga);
			$harga="Rp&nbsp;".number_format($s->harga);
		}
	?>
	<tr>
		<td><?php echo $no ?></td>
		<td align="center"><?php echo $dt->kd_brg ?></td>
		<td><?php echo $s->nm_brg ?></td>
		<td align="center"><?php echo $s->satuan ?></td>
		<td align="right"><?php echo $harga ?></td>
		<td align="right"><?php echo number_format($dt->jml) ?></td>\
		<td align="right"><?php echo$subtotal ?></td>
		<td align="center">
			<button type="button" class="del btn btn-danger btn-sm" id="<?php echo $dt->kd_brg ?>" >
				<i class="fas fa-times-circle"></i>
			</button>
		</td>
	</tr>
	<?php
	$no++;
}
?>

<script type="text/javascript">
	$(document).ready(function(){		
        //Hapus Barang
        $('.del').click(function(){
            var kdbrg=$(this).attr('id');
            $.ajax({
	            type : "POST",
	            url  : "<?php echo base_url().'permintaan/hapus_tmp'; ?>",
	            dataType : "JSON",
	            data : {kdbrg: kdbrg},
	            success: function(data){
	            	$('#tampil').load("<?php echo base_url().'permintaan/data_minta_tmp/';echo $nosbbk ?>");	               
	            }
            });
            return false;
        }); 
    }); 
</script>


