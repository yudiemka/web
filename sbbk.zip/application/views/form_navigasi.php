			<div class="container-fluid container-lg p-3 bg-white my-3 border">
				<h6>Hakaman Tabah Data Navigasi Sistem</h6>
				<hr>

				<form class="form" method="post" action="<?php echo base_url().'Menu/add' ?>" >
					<table class="table table-borderless table-hover">
						<tr>
							<td width="200">Nama Navigasi</td>
							<td>
								<input type="text" name="title" class="form-control form-control-sm" placeholder="Nama Navigasi">
							</td>
						</tr>
						<tr>
							<td width="200">Anchor Navigasi</td>
							<td>
								<input type="text" name="anchor" class="form-control form-control-sm" placeholder="Anchor / Link Navigasi">
							</td>
						</tr>
						<tr>
							<td width="200">Icon</td>
							<td>
								<input type="text" name="icon" class="form-control form-control-sm" placeholder="Icon Navigasi">
							</td>
						</tr>
					</table>
					<table class="table">
						<tr>
							<td colspan="2">
								<br>
								<button class="btn btn-primary btn-sm" type="submit">
									<i class="fas fa-save"></i>&nbsp;Simpan Data Navigasi
								</button>
								<button class="btn btn-danger btn-sm" type="reset">
									<i class="fas fa-times-circle"></i>&nbsp;Reset Form
								</button>
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</div>
</body>
  
</html>