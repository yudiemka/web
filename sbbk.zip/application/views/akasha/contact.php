    <div class="container-fluid mt-7 mb-25">
        <div class="row">
            <div class="col-12">
                <section class="tm-contact-form-box mx-auto mb-7">
                    <h3 class="tm-title-gray mb-4 text-center">Contact Information</h3>
                    <hr class="mb-8 tm-hr tm-hr-s mx-auto">
                    <form id="contact-form" action="" method="POST" class="tm-contact-form">
                        <div class="form-group">
                            <input type="text" name="name" class="form-control rounded-0" placeholder="Name" required />
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" class="form-control rounded-0" placeholder="Email" required />
                        </div>
                        <div class="form-group">
                            <select class="form-control" id="contact-select" name="inquiry">
                                <option value="-">Subject</option>
                                <option value="sales">Sales &amp; Marketing</option>
                                <option value="creative">Creative Design</option>
                                <option value="uiux">UI / UX</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <textarea rows="8" name="message" class="form-control rounded-0" placeholder="Message" required=></textarea>
                        </div>

                        <div class="form-group mb-0">
                            <button type="submit" class="btn btn-primary rounded-0 d-block mx-auto">Submit</button>
                        </div>
                    </form>
                </section>
                <section class="tm-address-box mx-auto">
                    <h3 class="tm-title-gray mb-4 text-center">Hubungi Kami Segera !!!</h3>
                    <hr class="mb-5 tm-hr tm-hr-s mx-auto">
                    <p class="mb-8 mx-auto text-center tm-address-text"><center><h4 style="margin-top:-50px">CV Akasha Cahaya Prima</h4>
                        Jl. Kutilang Sakti No. 126, Kec. Bina Widya<br>
                        Pekanbaru, Riau, Indonesia<br>
                        <span style="font-size:10pt;">
                            admin : 0811 62762726<br>
                            sales : 0811 67686960<br>
                            official website : www.akashaproperty.com<br>
                            Email : info@akashaproperty.com
                        </span>
                    </center>
                        <hr>
                        <br><br>
                    </p>
                    <div class="mapouter mb-60">
                        <div class="gmap_canvas">
                            <iframe width="100%" height="520" id="gmap_canvas"
                                src="https://maps.google.com/maps?q=Av.+L%C3%BAcio+Costa,+Rio+de+Janeiro+-+RJ,+Brazil&t=&z=13&ie=UTF8&iwloc=&output=embed"
                                frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                        </div>
                    </div>
                    <p class="mx-auto text-center tm-address-text">Aenean id posuere dui. Sed luctus luctus quam at blanbit. Aenean molestie lacinia mauris sed vestibulum. Praesent laoreet commodo sem eget fermentum.</p>
                </section>
            </div>
        </div>
    </div>

    