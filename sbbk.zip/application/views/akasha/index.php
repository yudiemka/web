<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Business Oriented CSS Template</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" /> <!-- https://fonts.google.com/ -->
    <link href="<?php echo base_url().'assets/akasha/css/bootstrap.min.css'?>" rel="stylesheet" /> <!-- https://getbootstrap.com/ -->
    <link href="<?php echo base_url().'assets/akasha/fontawesome/css/all.min.css'?>" rel="stylesheet" /> <!-- https://fontawesome.com/ -->
    <link href="<?php echo base_url().'assets/akasha/css/templatemo-business-oriented.css'?>" rel="stylesheet" />
</head>
<!--

TemplateMo 549 Business Oriented

https://templatemo.com/tm-549-business-oriented

-->
<body>
    <div id="parallax-1" class="parallax-window" data-parallax="scroll" data-image-src="<?php echo base_url().'assets/akasha/img/biz-oriented-header.jpg'?>">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div>
                        <img width="30%" src="<?php echo base_url().'assets/akasha/img/akasha.jpg'?>" style="margin-top:30px ;" >
                        <br>
                        <div class="bg-white p-3" style="width:435px;margin-top: 20px;opacity: 0.5;">
                           <h4>CV Akasha Cahaya Prima</h4> 
                           Developer - Contractor<br>
                           <span style="font-size: 10pt;">
                                Jl. Kutilang Sakti, Pekanbaru<
                               <br>Riau, Indonesia<br>
                               Phone. +62 812 3456 7890 - <br>E-mail : admin@akashaproperty.com
                           </span>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="tm-nav-container-outer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <nav class="navbar navbar-expand-lg" id="tm-main-nav">
                        <button class="navbar-toggler toggler-example" type="button" data-toggle="collapse" data-target="#navbar-nav" 
                            aria-controls="navbar-nav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="dark-blue-text"><i class="fas fa-bars"></i></span>
                        </button>
                        <div class="collapse navbar-collapse tm-nav" id="navbar-nav">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item active">
                                    <a class="nav-link tm-nav-link" href="<?php echo base_url().'web/index' ?>">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link tm-nav-link" href="<?php echo base_url().'web/services' ?>">Services</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link tm-nav-link" href="<?php echo base_url().'web/about' ?>">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link tm-nav-link" href="<?php echo base_url().'web/contact' ?>">Contact</a>
                                </li>

                            </ul>                            
                        </div>                        
                    </nav>
                </div>
            </div>
        </div>
    </div>








<script src="<?php echo base_url().'assets/akasha/js/jquery-3.4.1.min.js' ?>"></script>
<script src="<?php echo base_url().'assets/akasha/js/bootstrap.min.js' ?>"></script>
<script src="<?php echo base_url().'assets/akasha/js/parallax.min.js' ?>"></script> <!-- https://pixelcog.github.io/parallax.js/ -->
<script src="<?php echo base_url().'assets/akasha/js/tooplate-script.js' ?>"></script>
<script>
    $(document).ready(function () {
        $('#parallax-1').parallax({ imageSrc: <?php echo base_url().'assets/akasha/img/biz-oriented-header.jpg' ?> });
        $('#parallax-2').parallax({ imageSrc: 'img/biz-oriented-footer.jpg' });
    });
</script>