<?php
echo "$id";
$faktur=$this->M_material->pilih_data_faktur($id);
foreach ($faktur as $f) {
	?>
	<table class="table table-borderless">
		<tr>
			<td width="200">No. Faktur</td>
			<td>: <?php echo $f->no_faktur ?></td>
			<td width="200"> Suplier</td>
			<td>: <?php echo $f->suplier ?></td>
		</tr>
		<tr>
			<td width="200">Tanggal faktur</td>
			<td>: <?php echo $f->tanggal_faktur ?></td>
			<td width="200">Pembayaran</td>
			<td>: 
				<?php
				if($f->jenis_bayar=='1'){echo "CASH";}elseif($f->jenis_bayar=='2') {echo "NON CASH";}
				?>
			</td>
		</tr>
	</table>
	<?php
}
?>

<table class="table table-bordered table-striped">
	<thead class="table-primary">
		<th width="10">#</th>
		<th width="300">Nama Material</th>
		<th width="100">Qty</th>
		<th width="100">Satuan</th>
		<th width="150">Harga (IDR)</th>
		<th width="150">Sub Total (IDR)#</th>
	</thead>
	<?php
	$no=1;
	$material=$this->M_material->pilih_data($id);
	foreach ($material as $mt) {
		?>
		<tr>
			<td><?php echo $no ?></td>
			<td><?php echo $mt->nama_material ?></td>
			<td><?php echo $mt->qty ?></td>
			<td><?php echo $mt->satuan ?></td>
			<td align="right"><?php echo number_format($mt->harga) ?></td>
			<td align="right"><?php echo number_format($mt->subtotal) ?></td>
		</tr>
		<?php
		$no++;
	}
	?>
	<tr style="border-top: solid thick #5555;">
		<td align="right" colspan="5">Total Pembelian Material (IDR)</td>
		<td colspan="" align="right">
			<?php
			echo number_format($sum)
			?>
		</td>
	</tr>
</table>
