
<table class="table table-borderless">
	<?php
	$faktur=$this->M_hutang->data_faktur($id);
	foreach($faktur as $f) {
		//cek tabel bayar //
		$cekbayar=$this->M_material->cek_tabel($id);
		$cb=$cekbayar->num_rows();
		$data['nb']=$this->M_hutang->totalbayarhutang($f->no_faktur);
		if($cb=='0'){$sisa=$f->total;}else{$sisa=$f->total-$data['nb'];}
		?>
		<tr>
			<td>
				<label>Nomor Faktur</label>
				<input type="text" name="no_faktur" class="form-control" readonly value="<?php echo $id ?>">
				<input type="hidden" name="idprojek" id="idprojek" value="<?php echo $f->id_projek ?>">
			</td>
			<td>
				<label>Tanggal Bayar</label>
				<input type="date" name="tanggal_bayar" class="form-control text-uppercase">
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<label>Suplier</label>
				<input type="text" name="suplier" class="form-control" readonly value="<?php echo $f->suplier ?>">
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<label>Nominal Hutang (IDR)</label>
				<input type="text" name="nominal_hutang" class="form-control" readonly value="<?php echo $sisa ?>" id="nominal_hutang">
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<label>Jumlah Pembayaran (IDR)</label>
				<input type="text" name="nominal_bayar" class="form-control" id="nominal_bayar" onkeyup="kurang();">
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<label>Sisa Hutang (IDR)</label>
				<input type="text" name="nominal_sisa" class="form-control" id="nominal_sisa" readonly id="nominal_bayar">
			</td>
		</tr>
		<?php 
		}
		?>
</table>