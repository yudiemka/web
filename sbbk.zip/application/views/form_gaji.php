<?php 
$karyawan=$this->M_karyawan->pilih_data($nrk);
foreach ($karyawan as $dk)
?>
<table class="table table-primary table-bordered text-uppercase">
	<tr>
		<td width="250">Nama Karyawan</td>
		<td>: <?php echo $dk->nama_karyawan ?></td>
	</tr>
	<tr>
		<td width="250">No. Register Karyawan</td>
		<td>: <?php echo $nrk ?></td>
	</tr>
</table>
<hr>
<form id="formgaji" method="post">
<table class="table table-borderless">
	<tr>
		<td>
			<input type="text" name="pro" id="pro" class="form-control" placeholder="Ketikan Nama Perumahan">
			<input type="hidden" id="idprojek" name="idprojek">
		</td>
		<td width="200">
			<input type="number" name="gaji" id="gaji" class="form-control" placeholder="Nominal Gaji (IDR)">
		</td>
		<td width="50">
			<button class="btn btn-primary" type="button" id="add-gaji">
				<i class="fas fa-plus-circle"></i>
			</button>
		</td>
	</tr>
</table>
<table class="table table-bordered table-striped">
	<thead class="table-primary">
		<th width="25">#</th>
		<th>Nama Perumahan</th>
		<th width="200" class="text-right">Nominal gaji (IDR.)</th>
		<th width="30"><i class="fas fa-trash-alt"></i></th>
	</thead>
	<tbody id="tampil"></tbody>
</table>
</form>


<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#pro" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Karyawan/projek'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        autoFocua:true,
        appendTo:"#modal-fullscreen",
        select: function (event, ui) {
          // Set selection
          $('#projek').val(ui.item.nama_projek); // display the selected text
          $('#idprojek').val(ui.item.id_projek);
          return false;
        }
      })
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='table table-striped'>" )
		.append( "<tr><td width='200'>"+item.nama_projek+"</td><td width='200'>"+item.lokasi+"</td><td width='50'>"+item.jumlah_unit+"</td></tr>" )
		.appendTo( ul );
		};
    });
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$('#tampil').load("<?php echo base_url().'Karyawan/detail_data_gaji/';echo $nrk ?>");
        $('#add-gaji').click(function(){
        	var data=$('#formgaji').serialize();
            $.ajax({
            	type	: 'POST',
                url	: "<?php echo base_url().'Karyawan/add_detail_gaji/';echo $nrk?>",
                data: data,
                cache	: false,
                success	: function(data){
                	$('#tampil').load("<?php echo base_url().'Karyawan/detail_data_gaji/';echo $nrk ?>");
                	$('#pro').val("");
                	$('#gaji').val("");                	
                	$('#pro').focus();
                },
                appendTo:"#modal-fullscreen",
            });
        }); 
    });     
</script>

