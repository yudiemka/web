<!DOCTYPE html>
<html>
<head>
	<title>SIMKU - MIRANDA GRUP</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/bootstrap/css/bootstrap.min.css">
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/jquery-ui.css">
	<script type="text/javascript" src="<?php echo base_url().'assets/icon/js/all.min.js'?>"></script>
	<script src="<?php echo base_url() ?>assets/lib/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/bootstrap/js/bootstrap.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery-3.3.1.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery-ui.js"></script>

	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/DataTables/datatables.min.css"/> 
	<script type="text/javascript" src="<?php echo base_url() ?>assets/lib/DataTables/datatables.min.js"></script>
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/style.css">

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  	<script>
  		$(document).ready( function () {
		    $('#myTable').DataTable();
		} );
	</script>
	<style>
	.accordion {
	  background-color:#222;
	  color: white;
	  cursor: pointer;
	  padding: 10px;
	  width: 100%;
	  border: none;
	  text-align: left;
	  outline: none;
	  font-size: 15px;
	  transition: 0.4s;
	  text-transform: uppercase;
	}

	.active, .accordion:hover {
	  background-color: #9999; 
	}

	.panel {
	  padding: 0 18px;
	  display: none;
	  background-color: #444;
	  overflow: hidden;
	}
	s</style>


</head>
<body>
	<?php
	$status=$this->session->userdata("status_user");
	?>
	<div id="warper">
		<div id="side-bar" class="bg-dark text-white">
			<div class="container-fluid p-4" style="text-align: center;">
				<h4>S I M K U  V1.0</h4>
			</div>
				<div class="menu">

					<?php
					if ($status=='0') {
						$menu=$this->M_menu->akses($status);
						foreach($menu as $m) {
							?>

							<button class="accordion"><?php echo $m->nama_menu; ?></button>
							<div class="panel">
								<?php 
								$submenu=$this->M_menu->pilih_submenu($m->id_menu);
								foreach($submenu as $sm) {
									?>
									<li>
									  	<a href="<?php echo base_url().'admin/'; echo $sm->anchor_submenu ?>"><?php echo $sm->nama_submenu ?></a>
									</li>
									<?php
								}
								?>
							  
							</div>

							<?php
						}
					}
					?>
					
					<button class="accordion">Inflow Cash</button>
					<div class="panel">
					  <li>
					  	<a href="<?php echo base_url().'admin/pendapatan' ?>">Pendapatan</a>
					  </li>
					  <li>
					  	<a href="#">Modal</a>
					  </li>
					</div>

					<button class="accordion">Outflow Cash</button>
					<div class="panel">
					  <li>
					  	<a href="#">Honor Tukang</a>
					  </li>
					  <li>
					  	<a href="#">Gaji Karyawan</a>
					  </li>
					  <li>
					  	<a href="#">Honor Tukang</a>
					  </li>
					  <li>
					  	<a href="#">Pembelian</a>
					  </li>
					</div>

					<button class="accordion">Report</button>
					<div class="panel">
					  <li>
					  	<a href="#">Inflow cash</a>
					  </li>
					  <li>
					  	<a href="#">Outflow Cash</a>
					  </li>
					</div>

					<button class="accordion">Keluar</button>

				</div>
			</div>
		</div>
		<div class="content container-fluid" style="padding-left: 220px;position:static;">
			<div class="header container-fluid bg-primary p-4 text-white" style="width: 100%;">
				SISTEM INFORMASI MANAJEMEN KEUANGAN Versi 1.0 
				<span style="float: right;font-size: 16pt;line-height: 1;font-weight: bold">CV MIRANDA</span>
			</div>
			

<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}
</script>