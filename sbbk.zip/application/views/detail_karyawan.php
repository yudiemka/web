<?php 
$karyawan=$this->M_karyawan->pilih_data($nrk);
foreach ($karyawan as $dk)
?>
<table class="table table-borderless text-uppercase">
	<tr>
		<td>
			<label>No. Register Karyawan</label>
			<input type="text" name="nrk" class="form-control" value="<?php echo $nrk ?>" readonly>
		</td>
	</tr>
	<tr>
	  	<td>
	    	<label>Nama Lengkap Karyawan</label>
	        <input type="text" name="nama_karyawan" class="form-control" value="<?php echo $dk->nama_karyawan ?>">
	   	</td>
	</tr>
	<tr>
	    <td>
		    <label>jabatan</label>
		    <select name="jabatan" class="form-control">
		    	<?php
			    if($dk->jabatan_karyawan=='1'){$jk="Direktur";}
			    elseif($dk->jabatan_karyawan=='2'){$jk="Manajemen";}
			    elseif($dk->jabatan_karyawan=='3'){$jk="Staff Admin";}
			    elseif($dk->jabatan_karyawan=='4'){$jk="Staff Marketing";}
			    else{$jk="Staff Kantor";}
			    ?>
		        <option value="<?php echo $dk->jabatan_karyawan; ?>" selected><?php echo $jk ?></option>
		        <option value="1">Direktur</option>
		        <option value="2">Manajemen</option>
		        <option value="3">Staff Admin</option>
		        <option value="4">Staff Marketing</option>
		    </select>
	    </td>
	</tr>
</table>
