<div id="content-bar">
			<div class="box container-fluid bg-white p-3 text-dark"> 
				<b><?php echo $header ?></b>
				<?php foreach  ($stok as $dt) ?>
				<div style="float: right;margin-top: -5px;">
					<a href="<?php echo base_url().'admin/formaddkelas'; ?>">
						<a target="_blank" href="<?php echo base_url().'stok/cetak_kartu_stok/';echo $dt->kd_brg ?>">
						<button class="btn btn-primary"><i class="fas fa-print"></i>&nbsp;Cetak Kartu Stok</button>	
					</a>	
				</div>
			</div>
			<div class="box container-fluid bg-white p-3 my-2 text-dark"> 
				<table>
				
					<tr>
						<td width="200">Nama B M H P</td>
						<td>: <?php echo $dt->nm_brg ?></td>
					</tr>
					<tr>
						<td>Kemasan</td>
						<td>:</td>
					</tr>
					<tr>
						<td>Isi Kemasan</td>
						<td>:</td>
					</tr>
					<tr>
						<td>Satuan</td>
						<td>: <?php echo $dt->satuan ?></td>
					</tr>
					<tr>
						<td>Anggaran</td>
						<td>:</td>
					</tr>
				</table>
				<br>
				<table class="table table-striped">
					<th width="30">No.</th>
					<th width="150">Tanggal</th>
					<th width="400">Nomor Dokumen</th>
					<th width="350">Kepada / Yth </th>
					<th width="150">No.Batch/Loth</th>
					<th width="150">E.D</th>
					<th width="120">Jml Masuk</th>
					<th width="120">Jml Keluar</th>
					<th width="100">Sisa Stok</th>
					<th width="100">Paraf</th>
					<th width="50">Keterangan</th>
					<?php
					$stokkeluar=$this->m_stok->pilih_stok_keluar($dt->kd_brg);
					$no=1;
					foreach($stokkeluar as $sk) {
						$sbbk=$this->m_sbbk->pilih_data($sk->no_sbbk);
						foreach($sbbk as $sb)
						?>
						<tr>
							<td><?php echo $no ?></td>
							<td align="center"><?php echo $sb->tgl_sbbk ?></td>
							<td align="center">442/DINKES.7.3/<?php echo $sk->no_sbbk ?></td>
							<td align="center"><?php echo $sb->instansi ?></td>
							<td></td>
							<td align="center"><?php echo $dt->tgl_exp ?></td>
							<td></td>
							<td align="right"><?php echo $sk->jml_brg_keluar ?></td>
						</tr>
						<?php
						$no++;
					}
					?>
					<tr>
						<td colspan="7" align="right"></td>
						<td colspan="0" align="right">
							Sisa Stok : 
						</td>
						<td>
							<?php         
							foreach($jmlbrgkeluar as $rows){
							    $jmlkeluar=$rows->totalbrgkeluar;
								$sisa=$dt->jml_brg-$jmlkeluar;
								echo $sisa;
							}
							echo "&nbsp;";
							echo $dt->satuan
							?>
						</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</body>
</html>