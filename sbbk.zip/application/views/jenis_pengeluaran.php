			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Data Jenis Pengeluaran</h5> 
					<div>
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#staticBackdrop">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Data
						</button>
					</div>
				<table class="table table-bordered table-striped" id="myTable">
					<thead class="table-dark">			      
			        	<th width="30">#</th>
			            <th>Jenis Pengeluaran</th>
			            <th width="100">Kode</th>
			            <th width="200">Aktif / Non Aktif</th>
			            <th width="50">Panel</th>                        
			        </thead>  
			        <tbody>
			        <?php
			        $no=1;	
			        $data=$this->M_master->tampil_data_jp();
			        foreach ($data as $jp) {
			        	?>
			        	<tr>
			        		<td><?php echo $no ?></td>
			        		<td><?php echo $jp->jenis_pengeluaran ?></td>
			        		<td><?php echo $jp->kode ?></td>
			        		<td></td>
			        		<td>
			        			<button class="btn btn-danger btn-sm btn-hapus-jp" id="<?php echo $jp->kode?>">
											<i class="fas fa-trash-alt"></i>
										</button>
			        		</td>
			        	</tr>
			        	<?php
			        	$no++;
			        }			        
			        ?>
			        </tbody>
			    </table> 
				</div>
			</div>

		

<!-- Form Master Pengeluaran -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Form Tambah Jenis Pengeluaran</h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>

        
	        <div class="container-fluid p-3" style="text-align: left;">
	        	<form method="post" action="<?php echo base_url().'Pengeluaran/addjp' ?>">
		        	<table class="table table-borderless">
		        		<tr>
		        			<td>
		        				<label>Jenis Menu</label>
		        				<input name="nama_pengeluaran" class="form-control" placeholder="Nama Jenis Pengeluaran">
		        			</td>
		        		</tr>
		        		<tr>
	        		</table>
	        	</div>  
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        		</form>
      </div>
    </div>
  </div>
</div>
<!-- Form tambah KPR-->

<!-- Form tambah submenu sistem -->
<div class="submenu modal fade" id="submenu" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Form Tambah Submenu Navigasi Sistem</h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>

        
	        <div class="container-fluid p-3" style="text-align: left;">
	        	<form method="post" action="<?php echo base_url().'Submenu/add' ?>">
	        	<table class="table table-borderless" >
	        		<tr>
	        			<td>
	        				<label>Pilih Menu Utama</label>
	        				<select name="id_menu" class="form-control text-uppercase">
	        					<option value="00">Pilih menu Utama</option>
	        					<?php
	        					$menu=$this->M_menu->tampil_data_menu();
	        					foreach($menu as $m) {
	        						?>
	        						<option value="<?php echo $m->id_menu ?>"><?php echo $m->nama_menu ?></option>
	        						<?php
	        					}
	        					?>
	        				</select>
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Nama Sub Menu</label>
	        				<input type="text" name="nama_submenu" class="form-control text-uppercase" placeholder="Nama Sub Menu / navigasi">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Icon Sub Menu</label>
	        				<input type="text" name="icon_submenu" class="form-control text-uppercase" placeholder="Icon Sub Menu">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Anchor / Modul Sub Menu</label>
	        				<input type="text" name="anchor_submenu" class="form-control text-uppercase" placeholder="Anchor / Modul Sub Menu">
	        			</td>
	        		</tr>
	        	</table>
	        </div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        		</form>
      </div>
    </div>
  </div>
</div>
<!-- Form tambah KPR-->


</body>
<script>
$(document).ready( function () {
	$('#myTable').DataTable();
} );
$(document).ready( function () {
	$('#myTablesm').DataTable();
} );
</script>

<script>
	$(document).ready(function() {
  // Tangani klik pada tombol hapus
  $(document).on('click', '.btn-hapus-jp', function(e) {
	    e.preventDefault(); // Cegah perilaku default (misalnya, mengikuti tautan)

	    var id = $(this).attr('id'); // Ambil ID data yang akan dihapus (dari atribut data-id)

	    // Konfirmasi penghapusan (opsional)
	    if (confirm('Yakin ingin menghapus data ini?')) {
	      // Kirim permintaan AJAX
	      $.ajax({
	        type: 'POST', // Atau DELETE sesuai kebutuhan
	        url: '<?php echo base_url().'Pengeluaran/hapus_data_jp' ?>', // Ganti dengan URL skrip PHP Anda
	        data: { id: id },
	        success: function(response) {
	          // Tangani respon dari server
	          location.reload();
	        },
	        error: function() {
	          alert('Terjadi kesalahan saat menghapus data.');
	        }
	      });
	    }
	  });
	});
</script>


</html>




