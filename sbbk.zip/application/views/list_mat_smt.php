<?php
$no=1;
$material=$this->M_material->tampil_tmp($cr);
foreach ($material as $mt) {
	?>
	<tr>
		<td><?php echo $no ?></td>
		<td><?php echo $mt->nama_material ?></td>
		<td><?php echo $mt->qty ?></td>
		<td><?php echo $mt->satuan ?></td>
		<td align="right"><?php echo number_format($mt->harga) ?></td>
		<td align="right"><?php echo number_format($mt->subtotal) ?></td>
	</tr>
	<?php
	$no++;
}
?>
<tr style="border-top: solid thick #5555;">
	<td align="right" colspan="5">Total Pembelian Material (IDR)</td>
	<td colspan="" align="right" ">
		<?php
		echo number_format($sum)
		?>
	</td>
</tr>