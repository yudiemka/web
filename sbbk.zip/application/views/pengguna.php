			
			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Data Pengguna Sistem</h5>
					<hr>
					<table class="table table-bordered table-striped" id="myTable">
						<thead class="table-dark">
							<th width="40">#</th>
							<th width="200">No. Register Karyawan</th>
							<th width="">Nama Konsumen</th>
							<th width="200">Username</th>
							<th width="300">Password</th>
							<th width="150">Panel</th>
						</thead>
						<tbody>
							<?php
							$no=1;
							$pengguna=$this->M_karyawan->tampil_data();
							foreach($pengguna as $dp)
							{
								?>
								<tr>
									<td><?php echo $no ?></td>
									<td><?php echo $dp->no_register_karyawan ?></td>
									<td align="left"><?php echo $dp->nama_karyawan ?></td>
									<?php
									$user=$this->M_user->pilih_data($dp->no_register_karyawan);
									foreach($user as $u)
									?>
									<td><?php echo md5($u->username) ?></td>
									<td><?php echo md5($u->password) ?></td>
									<?php
									?>
									<td>
										<button type="button" class="btn-akses btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#formakses" id="<?php echo $dp->no_register_karyawan; ?>">
											Akses
										</button>
										<button type="button" class="btn-panel btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#formpanel" id="<?php echo $dp->no_register_karyawan; ?>">
											Panel
										</button>
									</td>
								</tr>
								<?php
								$no++;
							}
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>



<!-- Form Hak Akses Modul-->
<div class="modal fade" id="formakses" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg text-uppercase">
    <div class="modal-content">
      <div class="container-fluid bg-primary text-white p-3">
	      <h5 style="font-size: 12pt; float:left;">Form Hak Akses Pengguna Sistem</h5>
	      <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>        
	    <div class="container-fluid p-3" style="text-align: left;">
	    <form id="addakses">
	    	<div id="data-akses">cek</div>
      </div>
      <div class="modal-footer" style="float: right">
        	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        	<button type="button" id="add-akses" class="btn btn-primary">Simpan</button>
       	</form>
      </div>
    </div>
  </div>
</div>
<!-- End Form-->

<!-- Form Akses Panel-->
<div class="modal fade" id="formpanel" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg text-uppercase">
    <div class="modal-content">
      <div class="container-fluid bg-primary text-white p-3">
	      <h5 style="font-size: 12pt; float:left;">Form Akses Panel Sistem</h5>
	      <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>        
	    <div class="container-fluid p-3" style="text-align: left;">
	    <form id="addakses">
	    	<div id="data-panel">cek</div>
      </div>
      <div class="modal-footer" style="float: right">
        	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        	<button type="button" id="add-panel" class="btn btn-primary">Simpan</button>
       	</form>
      </div>
    </div>
  </div>
</div>
<!-- End Form-->
</body>
<script>
$(document).ready( function () {
	$('#myTable').DataTable();
});
</script>

<script>
$(document).ready(function() {
  $('.btn-akses').on('click', function() {
   	var idfaktur=$(this).attr("id"); 
    const data = {
      id: idfaktur,
    };
	  // Kirim data ke modal
    $('#data-akses').load('<?php echo base_url().'Material/akses/' ?>'+data.id);
  });
});

$(document).ready(function() {
  $('.btn-panel').on('click', function() {
   	var idfaktur=$(this).attr("id"); 
    const data = {
      id: idfaktur,
    };
	  // Kirim data ke modal
    $('#data-panel').load('<?php echo base_url().'Material/form_panel/' ?>'+data.id);
  });
});

</script>
<script>
$(document).ready(function(){
    $("#add-akses").click(function(){
        var menu = [];
		    $('input[name="modul[]"]:checked').each(function() {
		        menu.push($(this).attr("id"));
		    });
		    var submenu = [];
		    $('input[name="modul[]"]:checked').each(function() {
		        submenu.push($(this).val());
		    });
        var nrk=$("#nrk").val();

        $.ajax({
            url: "<?php echo base_url().'Menu/save_data' ?>",
            type: "POST",
            data: {menu:menu,submenu:submenu,nrk:nrk},
            success: function(response){
            	alert("Data berhasil diambil: " + response); // Menampilkan pesan sukses
            	location.reload();
            },
        });
    });
});

$(document).ready(function() {
  $("#add-panel").click(function() {
    
    var submenu = [];
		$('input[name="modul[]"]').each(function() {
		  submenu.push({
        value: $(this).val(),
      });
		});

    $.ajax({
      type: "POST",
      url: "<?php echo base_url().'Menu/save_data_panel' ?>", // Ganti dengan URL file PHP Anda
      data: { submenu:submenu },
      success: function(response) {
        // Tangani respons dari server (misalnya, tampilkan pesan sukses)
        alert("Data berhasil dikirim: " + response);
      },
      error: function() {
        alert("Terjadi kesalahan saat mengirim data.");
      }
    });
  });
});
</script>

</html>