			<div class="container-fluid container-lg p-3 bg-white my-3 border">
				<h6><?php echo $header ?></h6>
				<?php
				$menu=$this->M_menu->pilih_menu_id($id);
				foreach($menu as $m)
				?>
				<hr>

				<form class="form" method="post" action="<?php echo base_url().'Navigasi/ubah/'; echo $id; ?>" >
					<table class="table">
						<tr>
							<td width="200">Nama Navigasi</td>
							<td>
								<input type="text" name="nama_nav" class="form-control form-control-sm" value="<?php echo $m->nama ?>">
							</td>
						</tr>
						<tr>
							<td width="200">Anchor Navigasi</td>
							<td>
								<input type="text" name="anchor_nav" class="form-control form-control-sm" value="<?php echo $m->anchor ?>">
							</td>
						</tr>
						<tr>
							<td width="200">Icon</td>
							<td>
								<input type="text" name="icon_nav" class="form-control form-control-sm" value="<?php echo $m->icon ?>">
							</td>
						</tr>
					</table>
					<hr>
					<table class="table">
						<tr>
							<td colspan="2">
								<button class="btn btn-primary btn-sm" type="submit">
									<i class="fas fa-save"></i>&nbsp;Ubah Data Navigasi
								</button>
								<button class="btn btn-danger btn-sm" type="reset">
									<i class="fas fa-times-circle"></i>&nbsp;Reset Form
								</button>
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</div>
</body>
  
</html>