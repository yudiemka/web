<?php
$status=$this->session->userdata("status_user");
$nrk=$this->session->userdata("nrk");
?>			
			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Welcome !!</h5>
					Selamat Datang di Sistem Informasi Manajemen Keuangan AKASHA<br>
					No. Register Karyawan : <?php echo $nrk ?> <br>
					Status User : 
					<?php
					if ($status=='99') {echo "Admin System";}
					elseif($status=='1'){echo "Pengguna Sistem";}
					?>
					<br><br><br><br><br><br><br><br>
					<hr>
					SIMKU versi 1.0 developed by : yudi_emka @2025
				</div>
			</div>
		</div>
	</div>
</body>

</html>