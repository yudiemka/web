			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Data Hutang Perusahaan</h5> 
					<div>
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#operasional">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Data Pengeluaran Operasional
						</button>
					</div>
				<hr>

				<table class="table table-bordered table-striped text-uppercase" id="myTable">
						<thead class="table-dark">			      
				    	<th width="20">#</th>
				      <th width="200">Tanggal Faktur</th>
				      <th width="100">No. Faktur</th>
				      <th width="100">Supplier</th>
				      <th width="200">Projek</th>
				      <th width="50">Total Pembelian (IDR)</th>
				      <th width="100">Status / Sisa Hutang</th>
				      <th width="75">Panel</th>                        
				    </thead>  
				    <tbody>
				    	<?php
				      $no=1;
				      $hutang=$this->M_hutang->tampil_data_hutang();
				      foreach($hutang as $f){
				      	$datafaktur=$this->M_hutang->data_faktur($f->no_faktur);
				      	foreach($datafaktur as $df){
					      	?>
					      	<tr>
					      		<td><?php echo $no ?></td>
					      		<td><?php echo $df->tanggal_faktur ?></td>
					      		<td><?php echo $f->no_faktur ?></td>
					      		<td><?php echo $df->suplier ?></td>
					      		<td>
					      			<?php
					      			$dataprojek=$this->M_hutang->cekprojek($f->id_projek);
					      			foreach($dataprojek as $pro) {echo $pro->nama_projek;}
					      			?>
					      		</td>
					      		<td align="right"><?php echo number_format($df->total) ?></td>
					      		<?php
					      		// cek tabel bayar hutang //
					      		$cekbayar=$this->M_hutang->cekbayar($f->no_faktur);
					      		$cb=$cekbayar->num_rows();
					      		$data['nb']=$this->M_hutang->totalbayarhutang($f->no_faktur);
					      			$sisa=$df->total-$data['nb'];
					      		if($cb>'0'){

					      			?>
					      			<td><?php echo number_format($sisa); ?></td>
					      			<td>
					      				<button type="button" class="detail-faktur btn btn-primary btn-sm edit" data-bs-toggle="modal" data-bs-target="#detailfaktur" id="<?php echo $f->no_faktur; ?>">
							          	<i class="fas fa-search"></i>
								        	</button>
								        	<?php
								        	
								        	if($sisa=='0') {}
								        	else {
								        		?>
									        	<button type="button" class="form-hutang btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#formbayar" id="<?php echo $f->no_faktur; ?>">
												        	<i class="fas fa-money-bill"></i>
												  	</button>
												  	<?php
												  }
												  ?>
					      			</td>
					      			<?php
					      			}
					      			else {
					      				?>
					      				<td align="right">
					      					<?php 
					      					echo number_format($f->nominal_hutang);
					      					?>
					      				</td>
					      				<td>
					      					<button type="button" class="detail-faktur btn btn-primary btn-sm edit" data-bs-toggle="modal" data-bs-target="#detailfaktur" id="<?php echo $f->no_faktur; ?>">
							          	<i class="fas fa-search"></i>
								        	</button>
								        	<button type="button" class="form-hutang btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#formbayar" id="<?php echo $f->no_faktur; ?>">
											        	<i class="fas fa-money-bill"></i>
											  	</button>
					      				</td>
					      				<?php
					      			}
					      		?>
					      	</tr>
					      	<?php
					      	$no++;
					      }
				      }
				      
				      ?>
				    </tbody>
				  </table> 

				</div>
			</div>

<!-- Form Pengeluaran Operasional -->
<div class="modal fade" id="operasional" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modallg text-uppercase">

  	<div class="modal-content">
      <div class="container-fluid bg-primary text-white p-3">
	      <h5 style="font-size: 12pt; float:left;">Form Pengeluaran Operasional</h5>
	      <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>        
	    
	    <div class="container-fluid p-3" style="text-align: left;">
	    	<form method="post" id="formmaterial" name="formmoperasional" action="<?php echo base_url().'Operasional/add';?>">
	      <table class="table table-borderless">
	      	<tr>
	      		<td>
	      			<label>Tanggal</label>
	      			<input type="date" name="tanggal" class="form-control text-uppercase" placeholder="Ketikan Nama Projek" id="tanggal_bayar">
	      		</td>
	      	</tr>
	      	<tr>
	      		<td>
	      			<label>Rincian</label>
	      			<textarea class="form-control" placeholder="Rincian Pembayaran" name="rincian"></textarea>
	      		</td>
	      	</tr>
	      	<tr>
	      		<td>
	      			<label>Nominal Bayar (IDR)</label>
	      			<input type="text" name="nominal" class="form-control" placeholder="Nominal Pembayaran Izin" id="nominal">
	      		</td>
	      	</tr>	      	
	      	<tr>
	      		<td>
	      			<label>Keterangan</label>
	      			<textarea class="form-control" placeholder="Keterangan Pembayaran" name="keterangan"></textarea>
	      		</td>
	      	</tr>
	      </table>  		
	    </div>
      	
      <div class="modal-footer" style="float: right">
        	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        	<button type="submit" class="btn btn-primary">Simpan</button>
       	</form>
      </div>
    </div>
  </div>
</div>
<!-- Form tambah KPR-->

<!-- Detail Faktur -->
<div class="modal fade" id="detailfaktur" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl text-uppercase">
    <div class="modal-content">
      <div class="container-fluid bg-primary text-white p-3">
	      <h5 style="font-size: 12pt; float:left;">Detail faktur </h5>
	      <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>        
	    <div class="container-fluid p-3" style="text-align: left;">
	    	<div id="data-faktur"></div>
      </div>
    </div>
  </div>
</div>
<!-- End Detail Faktur-->

<!-- Form Bayar Hutang-->
<div class="modal fade" id="formbayar" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md text-uppercase">
    <div class="modal-content">
      <div class="container-fluid bg-primary text-white p-3">
	      <h5 style="font-size: 12pt; float:left;">Form Pembayaran Hutang</h5>
	      <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>        
	    <div class="container-fluid p-3" style="text-align: left;">
	    	<form action="<?php echo base_url().'Hutang/add'; ?>" method="post">
	    	<div id="data-hutang">cek</div>
      </div>
      <div class="modal-footer" style="float: right">
        	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        	<button type="submit" class="btn btn-primary">Simpan</button>
       	</form>
      </div>
    </div>
  </div>
</div>
<!-- End Form-->


</body>
</html>
<script type="text/javascript">
	$(document).ready(function(){
		$('#tampil').load("<?php echo base_url().'Material/list_mat_tmp/';echo $cr ?>");
        $('#addmat').click(function(){
        	var data=$('#formmaterial').serialize();
            $.ajax({
            	type	: 'POST',
                url	: "<?php echo base_url().'Material/add_item_tmp';?>",
                data: data,
                cache	: false,
                success	: function(data){
                	$('#tampil').load("<?php echo base_url().'Material/list_mat_tmp/';echo $cr ?>");
                	$('#nama_material').val("");
                	$('#qty').val("");
                	$('#harga').val("");
                	$('#satuan').val("");
                	$('#subtotal').val("");
                	$('#nama_material').focus();
                	$('#no_faktur').attr("readonly","readonly");
                },
                appendTo:"#modal-fullscreen",
            });
        }); 
    });     
	</script>



<script>
$(document).ready( function () {
	$('#myTable').DataTable();
} );
</script>

<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#projek" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Modal/cari_projek'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        autoFocua:true,
        appendTo:"#modal-fullscreen",
        select: function (event, ui) {
          // Set selection
          $('#projek').val(ui.item.nama_projek); // display the selected text
          $('#id_projek').val(ui.item.id_projek);
          return false;
        }
      })
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='table table-striped'>" )
		.append( "<tr><td width='200'>"+item.nama_projek+"</td><td width='200'>"+item.lokasi_projek+"</td><td width='50'>"+item.jumlah_unit+"</td></tr>" )
		.appendTo( ul );
		};
    });
</script>

<script>
	$(document).ready(function () {
		tampil_data();
	});            
 
  //fungsi tampil data
	function tampil_data() {
		$.ajax({
			url: "<?php echo base_url().'permintaan/data_minta_tmp' ?>",
			type: 'get',
			success: function(data) {
				$('#list_material_smt').html(data);
			}
		});
	}
</script>

<script>
function sum() {
      var txtFirstNumberValue = document.getElementById('qty').value;
      var txtSecondNumberValue = document.getElementById('harga').value;
      var result = parseInt(txtFirstNumberValue) * parseInt(txtSecondNumberValue);
      if (!isNaN(result)) {
         document.getElementById('subtotal').value = result;
      }
}

function kurang() {
      var txtFirstNumberValue = document.getElementById('nominal_hutang').value;
      var txtSecondNumberValue = document.getElementById('nominal_bayar').value;
      var result = parseInt(txtFirstNumberValue) - parseInt(txtSecondNumberValue);
      if (!isNaN(result)) {
         document.getElementById('nominal_sisa').value = result;
      }
}
</script>

<script>	
	 $(document).ready(function() {
    $('.detail-faktur').on('click', function() {
    	var idfaktur=$(this).attr("id"); 
      const data = {
        id: idfaktur,
      };
       // Kirim data ke modal
      $('#data-faktur').load('<?php echo base_url().'Material/detail_faktur/' ?>'+data.id);
    });
  });

</script>

<script>	
	 $(document).ready(function() {
    $('.form-hutang').on('click', function() {
    	var idfaktur=$(this).attr('id'); 
      const data = {
        id: idfaktur,
      };
      // Kirim data ke modal
      $('#data-hutang').load('<?php echo base_url().'Material/form_hutang_bayar/' ?>'+data.id);
    });
  });

</script>

</html>




