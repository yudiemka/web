			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Data Karyawan Perusahaan</h5> 
					<div>
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#formkaryawan">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Data Karyawan
						</button>
					</div>
				<hr>
				<table class="table table-bordered table-striped text-uppercase" id="myTable">
					<thead class="table-dark">			      
			        	<th width="30">#</th>
			            <th width="200">No. Register Karyawan</th>
			            <th width="">Nama Lengkap Karyawan</th>
			            <th width="200">Jabatan</th>
			            <th width="200" align="right">Gaji Pokok</th>
			            <th width="300">Panel</th>                        
			        </thead>  
			        <tbody>
			        <?php
			        $no=1;
			        $data=$this->M_karyawan->tampil_data(); 
			        foreach($data as $dt) {
			        	?>

			        	<tr>
			        		<td><?php echo $no ?></td>			        		
			        		<td><?php echo $dt->no_register_karyawan ?></td>
			        		<td><?php echo $dt->nama_karyawan ?></td>
			        		<td>
			        			<?php
			        			if($dt->jabatan_karyawan=='1'){echo"Direktur";}
			        			elseif($dt->jabatan_karyawan=='2'){echo"Manajemen";}
			        			elseif($dt->jabatan_karyawan=='3'){echo"Staff Admin";}
			        			elseif($dt->jabatan_karyawan=='4'){echo"Staff Marketing";}
			        			else{echo"Staff Kantor";}
			        			?>
			        		</td>
			        		<td></td>			        		
			        		<td width="250">
			        			<div class="cp">
				        			<a href="#"><span>
				        				<button class="btn btn-sm btn-danger btn-hapus" id="<?php echo $dt->no_register_karyawan ?>"><i class="fas fa-trash-alt"></i></button>
				        			</a>
				        			<a href="#"><span>
				        				<button id="<?php echo $dt->no_register_karyawan ?>" class="btn btn-sm btn-info btn-edit" data-bs-toggle="modal" data-bs-target="#formeditkaryawan" ><i class="fas fa-pen"></i></button>
				        			</a>
				        			<button class="btn btn-success btn-sm btn-gaji" id="<?php echo $dt->no_register_karyawan ?>" data-bs-toggle="modal" data-bs-target="#formgajikaryawan">
				        				detail gaji
				        			</button>
				        		</div>
			        		</td>
			        	</tr>
			        	<?php
			        	$no++;
			        }
			        ?>
			        </tbody>
			    </table> 
				</div>
			</div>

<!-- Form tambah karyawan -->
<div class="modal fade" id="formkaryawan" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Form Tambah Karyawan Perusahaan</h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>

        
	        <div class="container-fluid p-3" style="text-align: left;">
	        	<form method="post" action="<?php echo base_url().'Karyawan/add' ?>">
	        	<table class="table table-borderless text-uppercase">
	        		<tr>
	        			<td>
	        				<label>Nama Lengkap Karyawan</label>
	        				<input type="text" name="nama_karyawan" class="form-control" placeholder="Nama Lengkap Karyawan">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>jabatan</label>
	        				<select name="jabatan" class="form-control">
	        					<option value="00">Pilih Jabatan</option>
	        					<option value="1">Direktur</option>
	        					<option value="2">Manajemen</option>
	        					<option value="3">Staff Admin</option>
	        					<option value="4">Staff Marketing</option>
	        				</select>
	        			</td>
	        		</tr>
	        		
	        	</table>
	        	<div>
	        		<table class="table table-borderless">
	        		</table>
	        	</div>
	        		
	        	
	        </div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        		</form>
      </div>
    </div>
  </div>
</div>

<!-- Form Ubah Data karyawan -->
<div class="modal fade" id="formeditkaryawan" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Form Ubah Data Karyawan Perusahaan</h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>

        
	        <div class="container-fluid p-3" style="text-align: left;">
	        	<form method="post" action="<?php echo base_url().'Karyawan/edit' ?>">
	        	<div id="data-karyawan">
	        	
	        	</div>
	        		
	        	
	        </div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        		</form>
      </div>
    </div>
  </div>
</div>

<!-- Form Gajikaryawan -->
<div class="modal fade" id="formgajikaryawan" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Form Data Gaji Karyawan Perusahaan</h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>

        
	        <div class="container-fluid p-3" style="text-align: left;">
	        	<div id="data-gaji">
	        	tes
	        	</div>
	        		
	        	
	        </div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
      </div>
    </div>
  </div>
</div>



</body>


<script>
	$(document).on('click', '.btn-hapus', function(){
		var id = $(this).attr('id');
		$.ajax({
			type: 'POST',
			url: "<?php echo base_url().'Karyawan/hapus_data' ?>",
			data: {id:id},			
			success: function(response) {				
				//setelah simpan data, update data terbaru
				window.location.reload();
				
			}
		});
	});

	$(document).ready(function() {
    $('.btn-edit').on('click', function() {
    	var nrk=$(this).attr("id"); 
      const data = {
        nrk: nrk,
      };
       // Kirim data ke modal
      $('#data-karyawan').load('<?php echo base_url().'Karyawan/detail_karyawan/' ?>'+data.nrk);
    });
  });

  $(document).ready(function() {
    $('.btn-gaji').on('click', function() {
    	var nrk=$(this).attr("id"); 
      const data = {
        nrk: nrk,
      };
       // Kirim data ke modal
      $('#data-gaji').load('<?php echo base_url().'Karyawan/form_gaji_karyawan/' ?>'+data.nrk);
    });
  }); 

</script>

<script>
	$(document).ready(function() {
  // Tangani klik pada tombol hapus
  $(document).on('click', '.btn-hapus', function(e) {
    e.preventDefault(); // Cegah perilaku default (misalnya, mengikuti tautan)

    var id = $(this).data('id'); // Ambil ID data yang akan dihapus (dari atribut data-id)

    // Konfirmasi penghapusan (opsional)
    if (confirm('Yakin ingin menghapus data ini?')) {
      // Kirim permintaan AJAX
      $.ajax({
        type: 'POST', // Atau DELETE sesuai kebutuhan
        url: '<?php echo base_url().'Karyawan/hapus_data' ?>', // Ganti dengan URL skrip PHP Anda
        data: { id: id },
        success: function(response) {
          // Tangani respon dari server
          if (response === 'success') {
            // Hapus baris data dari tampilan (tanpa reload)
            $(this).closest('tr').remove(); // Contoh: jika data ditampilkan dalam tabel
            alert('Data berhasil dihapus.');
          }
        },
        error: function() {
          alert('Terjadi kesalahan saat menghapus data.');
        }
      });
    }
  });
});
</script>




</html>




