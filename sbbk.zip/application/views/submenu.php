			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Data Menu Sistem</h5> 
					<div>
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#staticBackdrop">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Menu Sistem
						</button>
					</div>
				<hr>
				<table class="table table-bordered table-striped" id="myTable">
					<thead class="table-dark">			      
			        	<th width="30">#</th>
			            <th>Nama Menu</th>
			            <th width="100">Icon</th>
			            <th width="200">Jenis Menu</th>
			            <th width="200" align="right">Anchor</th>
			            <th width="200">Panel</th>                        
			        </thead>  
			        <tbody>
			        <?php
			        $no=1;
			        $data=$this->M_menu->tampil_data_menu(); 
			        foreach($data as $dt) {
			        	if($dt->jenis_menu=='0'){$jem='Dropdown Menu';}else{$jm='Single Menu';}
			        	?>

			        	<tr>
			        		<td><?php echo $no ?></td>			        		
			        		<td><?php echo $dt->nama_menu ?></td>
			        		<td><i class="<?php echo $dt->icon_menu ?>"></i></td>
			        		<td><?php echo $jem ?></td>
			        		<td><?php echo $dt->anchor_menu ?></td>			        		
			        		<td>
			        			<div class="cp">
				        			<a href="#"><span>
				        				<button class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i></button>
				        			</a>
				        			<a href="#"><span>
				        				<button class="btn btn-sm btn-info"><i class="fas fa-pen"></i></button>
				        			</a>
				        		</div>
			        		</td>
			        	</tr>
			        	<?php
			        	$no++;
			        }
			        ?>
			        </tbody>
			    </table> 
				</div>
			</div>

			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Data Menu Sistem</h5> 
					<div>
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#staticBackdrop">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Menu Sistem
						</button>
					</div>
				<hr>
				<table class="table table-bordered table-striped" id="myTable">
					<thead class="table-dark">			      
			        	<th width="30">#</th>
			            <th>Nama Submenu</th>
			            <th width="200">Menu</th>
			            <th width="100">Icon</th>
			            <th width="200">Anchor / Modul</th>
			            <th width="200">Panel</th>                        
			        </thead>  
			        <tbody>
			        <?php
			        $no=1;
			        $data=$this->M_submenu->tampil_data_submenu(); 
			        foreach($data as $dt) {
			        	?>
			        	<tr>
			        		<td><?php echo $no ?></td>			        		
			        		<td><?php echo $dt->nama_submenu ?></td>
			        		<td><i class="<?php echo $dt->icon_submenu ?>"></i></td>
			        		<td><?php echo $dt->anchor_submenu ?></td>			        		
			        		<td>
			        			<div class="cp">
				        			<a href="#"><span>
				        				<button class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i></button>
				        			</a>
				        			<a href="#"><span>
				        				<button class="btn btn-sm btn-info"><i class="fas fa-pen"></i></button>
				        			</a>
				        		</div>
			        		</td>
			        	</tr>
			        	<?php
			        	$no++;
			        }
			        ?>
			        </tbody>
			    </table> 
				</div>
			</div>

		</div>
	</div>

<!-- Form tambah menu sistem -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Form Tambah Menu Navigasi Sistem</h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>

        
	        <div class="container-fluid p-3" style="text-align: left;">
	        	<form method="post" action="<?php echo base_url().'menu/add' ?>">
	        	<table class="table table-borderless">
	        		<tr>
	        			<td>
	        				<label>Jenis Menu</label>
	        				<select name="jenis_menu" class="form-control">
	        					<option value="00">Pilih Jenis Menu</option>
	        					<option value="0">Dropdown Menu</option>
	        					<option value="1">Stand Alone Menu Menu</option>
	        				</select>
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Nama Menu</label>
	        				<input type="text" name="nama_menu" class="form-control" placeholder="Nama Menu / navigasi">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Icon Menu</label>
	        				<input type="text" name="icon_menu" class="form-control" placeholder="Icon Menu">
	        			</td>
	        		</tr>
	        	</table>
	        	<div>
	        		<table class="table table-borderless">
	        		</table>
	        	</div>
	        		
	        	
	        </div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        		</form>
      </div>
    </div>
  </div>
</div>
<!-- Form tambah KPR-->

</body>
<script>
$(document).ready( function () {
	$('#myTable').DataTable();
} );
</script>


</html>




