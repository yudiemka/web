			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Data Pembayaran Land Clearing</h5> 
					<div>
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#lc">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Data Land Clearing
						</button>
					</div>
				<hr>

				<tbody id="list_material_smt"></tbody>

				<table class="table table-bordered table-striped" id="myTable">
					<thead class="table-dark">			      
			        	<th width="20">#</th>
			            <th width="200">Tanggal Pembayaran</th>
			            <th width="200">Projek</th>
			            <th width="200">Nominal Pembayaran (IDR)</th>
			            <th width="">Keterangan</th>
			            <th width="75">Panel</th>                        
			        </thead>  
			        <tbody>
			        <?php
			        $no=1;
			        $data=$this->M_lc->tampil_data();
			        foreach ($data as $dt) {
			        	?>
			        	<tr>
			        		<td><?php echo $no ?></td>
			        		<td><?php echo $dt->tanggal_lc ?></td>
			        		<td><?php echo $dt->id_projek ?></td>
			        		<td><?php echo $dt->nominal_lc ?></td>
			        		<td><?php echo $dt->keterangan_lc ?></td>
			        		<td>
			        			<button class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i></button>
			        		</td>
			        	</tr>
			        	<?php
			        	$no++;
			        }			        
			        ?>
			        </tbody>
			    </table> 
				</div>
			</div>

<!-- Form Pembelian Material -->
<div class="modal fade" id="lc" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md text-uppercase">

  	<?php
  	// Cek row //
  	$cekrow=$this->M_material->cekrow();
  	$cr=$cekrow->num_rows()+1;
  	?>

    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Form Input Data Land Clearing </h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    	</div>        
	        <div class="container-fluid p-3" style="text-align: left;">
	        	<form method="post" id="formmaterial" action="<?php echo base_url().'Lc/add' ?>">
	        	<table class="table table-borderless" >
	        		<tr>
	        			<td>
	        				<label>Tanggal</label>
	        				<input type="date" name="tanggal_lc" id="tanggal_lc" class="form-control">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Nama Projek</label>
	        				<input type="text" name="projek" id="projek" class="form-control" placeholder="Ketikan Nama Projek">
	        				<input type="hidden" name="id_projek" id="id_projek">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Nominal Pembayaran (IDR)</label>
	        				<input type="text" name="nominal_lc" class="form-control" placeholder="Nominal Pembayaran Land Clearing (IDR)">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Keterangan</label>
	        				<textarea name="keterangan_lc" class="form-control"></textarea>
	        			</td>
	        		</tr>
	        	</table>
	        	</div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        		</form>
      </div>
    </div>
  </div>
</div>
<!-- Form tambah KPR-->


</body>
<script>
$(document).ready( function () {
	$('#myTable').DataTable();
} );
</script>

<script>
$(document).ready( function () {
	$('#myTable').DataTable();
} );
</script>
<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#projek" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Modal/cari_projek'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        autoFocua:true,
        appendTo:"#modal-fullscreen",
        select: function (event, ui) {
          // Set selection
          $('#projek').val(ui.item.nama_projek); // display the selected text
          $('#id_projek').val(ui.item.id_projek);
          return false;
        }
      })
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='table table-striped'>" )
		.append( "<tr><td width='200'>"+item.nama_projek+"</td><td width='200'>"+item.lokasi_projek+"</td><td width='50'>"+item.jumlah_unit+"</td></tr>" )
		.appendTo( ul );
		};
    });
</script>

</html>




