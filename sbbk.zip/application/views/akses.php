<?php
//cek tabel akses->nrk

$ceknrk=$this->M_user->ceknrk($id);
$row=$ceknrk->num_rows();
if($row=='0') {
	?>
	<input type="hidden" name="nrk" id="nrk" value="<?php echo $id ?>">
	<table class="table table-borderless text-uppercase">
		<tr>
			<td width="150">NRK</td>
			<td>: <?php echo $id ?></td>
		</tr>
		<tr>
			<td width="150">Kama Karyawan</td>
			<td>:</td>
		</tr>
	</table>
	<table class="table table-bordered text-uppercase">
		<thead class="table-primary">
			<th width="30"><input type="checkbox"></th>
			<th>Nama Menu</th>			
		</thead>
		<tbody>
			<?php
	        $modul=$this->M_menu->tampil_data_submenu();
	        foreach($modul as $m) {
	            ?>
	            <tr class="text-uppercase">
	                <td class="text-uppercase">
	                	<input type="checkbox" name="modul[]" id="<?php echo $m->id_menu ?>" class="modul[]" value="<?php echo $m->id_submenu ?>">
	                </td>
	                <td class="text-uppercase"><?php echo $m->nama_submenu ?></td>
	            </tr>
	            <?php
	        }
	        ?>
		</tbody>
	</table>
	<?php
}
elseif($row=='1') {
	?>
	<input type="hidden" name="nrk" id="nrk" value="<?php echo $id ?>">
	<table class="table table-borderless text-uppercase">
		<tr>
			<td width="150">NRK</td>
			<td>: <?php echo $id ?></td>
		</tr>
		<tr>
			<td width="150">Kama Karyawan</td>
			<td>:</td>
		</tr>
	</table>
	<table class="table table-bordered text-uppercase">
		<thead class="table-primary">
			<th width="30"><input type="checkbox"></th>
			<th>Nama Menu</th>			
		</thead>
		<tbody>
			<?php
			//cek tabel hak akses
			$ctbakses1=$ceknrk->result();
			foreach($ctbakses1 as $ctb1)
            $data1=explode(",", $ctb1->modul);
            $cekaktif=$this->M_menu->menu_in($data1);
            foreach($cekaktif->result() as $ca) {
                ?>
                <tr>
                	<td>
                		<input class="modul[]" type="checkbox" name="modul[]" id="modu[]" value="<?php echo $ca->id_submenu ?>" checked>
                	</td>
                	<td><?php echo $ca->nama_submenu ?></td>
                </tr>
                <?php
            }
            ?>
            <?php
			//cek tabel hak akses
			$ctbakses2=$ceknrk->result();
			foreach($ctbakses2 as $ctb2)
            $data2=explode(",", $ctb2->modul);
            $ceknonaktif=$this->M_menu->menu_not_in($data2);
            foreach($ceknonaktif->result() as $co) {
                ?>
                <tr>
                	<td><input type="checkbox" name="modul[]" value="<?php echo $co->id_submenu ?>"></td>
                	<td><?php echo $co->nama_submenu ?></td>
                </tr>
                <?php
            }
            ?>
		</tbody>
	</table>
	<?php
}
?>