<?php
$detgaji=$this->M_gaji->detail_gaji($nrk);
$row=$detgaji->num_rows();

if($row=='0') {
	?>
	<tr>
		<td colspan="4">Belum Ada Detail Gaji</td>
	</tr>
	<?php
}
else {
	$no=1;
	foreach($detgaji->result() as $dg) {
		$perumahan=$this->M_projek->pilih_data($dg->id_projek);
		
		foreach($perumahan as $dp)
		?>
		<tr>
			<td><?php echo $no ?></td>
			<td><?php echo $dp->nama_projek;echo $dp->id_projek ?></td>
			<td align="right"><?php echo number_format($dg->nominal_gaji) ?></td>
			<td>
				<button class="btn btn-primary btn-sm btn-hapus-gaji" id="<?php echo $dp->id_projek ?>">
					<i class="fas fa-trash-alt"></i>
				</button>
			</td>
		</tr>
		<?php
		$no++;
	}
	?>
	<tr>
		<td colspan='2' class="table-primary" align="right"><b>Total Gaji Diterima (IDR.)</b></td>
		<td class="table-primary" align="right"><b><?php echo number_format($totalgaji) ?></b></td>
		<td class="table-primary">&nbsp;</td>
	</tr>
	<?php
	
}
?>

<script>
	$(document).ready(function() {
  // Tangani klik pada tombol hapus
  $(document).on('click', '.btn-hapus-gaji', function(e) {
    e.preventDefault(); // Cegah perilaku default (misalnya, mengikuti tautan)

    var id = $(this).data('id'); // Ambil ID data yang akan dihapus (dari atribut data-id)

    // Konfirmasi penghapusan (opsional)
    if (confirm('Yakin ingin menghapus data ini?')) {
      // Kirim permintaan AJAX
      $.ajax({
        type: 'POST', // Atau DELETE sesuai kebutuhan
        url: '<?php echo base_url().'Karyawan/hapus_detail_gaji/';echo $nrk ?>', // Ganti dengan URL skrip PHP Anda
        data: { id: id },
        success: function(response) {
        	$("#tampil").html(response);
          // Tangani respon dari server
          if (response === 'success') {
            // Hapus baris data dari tampilan (tanpa reload)
            $(this).closest('tr').remove(); // Contoh: jika data ditampilkan dalam tabel
            alert('Data berhasil dihapus.');
          }
        },
        error: function() {
          alert('Terjadi kesalahan saat menghapus data.');
        }
      });
    }
  });
});
</script>