<?php
if($periode=='1') {
	?>
	<input type="date" name="tanggalperiode" id="tanggalperiode" class="form-control">
	<?php
}

elseif($periode=='2') {
	?>
		<select name='bulan' id='bulan' class='form-control'>
			<option value='01'>Januari</option>
			<option value='02'>Februari</option>
			<option value='03'>Maret</option>
			<option value='04'>April</option>
			<option value='05'>Mei</option>
			<option value='06'>Juni</option>
			<option value='07'>Juli</option>
			<option value='08'>Agustus</option>
			<option value='09'>September</option>
			<option value='10'>Oktober</option>
			<option value='11'>November</option>
			<option value='12'>Desember</option>
		</select>
	<?php 
}

else if($periode=='3') {
	?>
	<select name="tahun" id="tahun" class="form-control">
		<?php
		$mulai= date('Y') - 10;
		for($i = $mulai;$i<$mulai + 100;$i++){
		?>			
			<option value='<?php echo $i; ?>'><?php echo $i; ?></option>
		<?php
		}
		?>	
	</select>	
	<?php
}

else if($periode=='4') {
	?>
	<td>
		<input type="date" id="tgl1" name="tgl1" class="form-control" placeholder="Tanggal Awal" value="now()">
	</td>
	<td>-</td>
	<td>
		<input type="date" id="tgl2" name="tgl2" class="form-control" placeholder="Tanggal Akhir" value="now()">
	</td>
	<?php
}

?>