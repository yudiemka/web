			
			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5 style="">Laporan Pengeluaran Perusahaan</h5>
					<hr>	
					<div style="margin-left:0px;">
    			<div class="container-fluid">
					<table class="table table-bordered table-striped" id="myTable">
						<thead class="table-dark">
							<th width="40">#</th>
							<th width="200">Tanggal Transaksi</th>
							<th>Jenis Pengeluaran</th>
							<th width="300">Nominal</th>
							<th width="400">Keterangan</th>
							<th width="150">Panel</th>
						</thead>
						<tbody>
						<?php
						$modal=$this->M_pengeluaran->tampil_data();
						$no=1;
						foreach($modal as $mod) {
							?>
							<tr>
								<td><?php echo $no ?></td>
								<td></td>
								<td></td>
								<td align="right">></td>
								<td><?php ?></td>
								<td></td>
							</tr>
							<?php
							$no++;
						}					
						?>
						</tbody>
					</table>
				</div>
				</div>
			</div>
		</div>
	</div>



</body>
<script>
new DataTable('#myTable', {
    searching: true,
});
</script>
<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#nama_projek" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Modal/cari_projek'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        autoFocua:true,
        appendTo:"#modal-fullscreen",
        select: function (event, ui) {
          // Set selection
          $('#nama_projek').val(ui.item.nama_projek); // display the selected text
          $('#id_projek').val(ui.item.id_projek);
          return false;
        }
      })
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='table table-striped'>" )
		.append( "<tr><td width='200'>"+item.nama_projek+"</td><td width='200'>"+item.lokasi_projek+"</td><td width='50'>"+item.jumlah_unit+"</td></tr>" )
		.appendTo( ul );
		};
    });
</script>

<script>
			        function formatAngka(input) {
			            let nilai = input.value.replace(/\D/g, '');
			            if (nilai === '') {
			                input.value = '';
			            } else {
			                let nilaiFormatted = nilai.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
			                input.value = nilaiFormatted;
			            }
			        }
			    </script>
<script type="text/javascript">
	
</script>
</html>