<!DOCTYPE html>
<html>
<head>
	<title>Akasha Group</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/bs5/css/bootstrap.min.css">	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/jquery14/jquery-ui.css">
	<script type="text/javascript" src="<?php echo base_url().'assets/icon/js/all.min.js'?>"></script>
	<script src="<?php echo base_url() ?>assets/lib/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/bootstrap/js/bootstrap.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery-3.3.1.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery14/jquery-ui.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/DataTables/datatables.min.css"/> 
	<script type="text/javascript" src="<?php echo base_url() ?>assets/lib/DataTables/datatables.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>assets/js/number.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/bs5/css/bootstrap.min.css"></script>
	<script src="<?php echo base_url() ?>assets/lib/bs5/js/bootstrap.bundle.min.js"></script>	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/style.css">	
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery-ui.js"></script>

	<script type="text/javascript" src="js/jquery-ui/jquery-ui.js"></script>
	<link rel="stylesheet" type="text/css" href="js/jquery-ui/jquery-ui.css">


</head>


</head>
<body>
	
</body>
</html>