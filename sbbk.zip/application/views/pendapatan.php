			<div id="content" class="container-fluid bg-white p-3">	
				<h5>Data Pendatapatan Perusahaan</h5> 
					<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
						<i class="fas fa-plus-circle"></i>&nbsp;Data Pendapatan
					</button>
				
				<button class="btn btn-success">
					<i class="fas fa-print"></i>&nbsp;Cetak Data
				</button>
				<hr>
				<table class="table table-striped data" id="datatable">
			        <thead class="table-primary-white">
			          <tr>
			            <th width="30">No</th>
			            <th width="150">Tanggal</th>
			            <th>Keterangan</th>
			            <th width="200" align="right">Jumlah (IDR)</th>
			            <th width="150">Panel</th>                        
			          </tr>
			        </thead>  
			        <tbody>
			        <?php
			        $no=1;
			        $data=$this->M_pendapatan->tampil_data(); 
			        foreach($data->result() as $dt) {
			        	?>
			        	<tr>
			        		<td><?php echo $no ?></td>			        		
			        		<td><?php echo $dt->tanggal ?></td>
			        		<td><?php echo $dt->keterangan ?></td>
			        		<td align="right"><?php echo number_format($dt->jumlah) ?></td>			        		
			        		<td align="center">
			        			<div class="cp">
				        			<a href="#"><span>
				        				<button class="btn-sm btn-danger"><i class="fas fa-trash-alt"></i></button>
				        			</a>
				        			<a href="#"><span>
				        				<button class="btn-sm btn-info"><i class="fas fa-pen"></i></button>
				        			</a>
				        		</div>
			        		</td>
			        	</tr>
			        	<?php
			        	$no++;
			        }
			        ?>
			        </tbody>
			    </table> 
			</div>  
		</div>

<!-- Modal Add Pendapatan -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Tambah Data Pendapatan Perusahaan</h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>

        
	        <div class="container-fluid p-3" style="text-align: left;">
	        	<form>
	        		<label>Tanggal</label>
	        		<input type="date" name="tanggal" class="form-control">
	        		<label>Keterangan</label>
	        		<textarea class="form-control" rows="3" placeholder="Keterangan Pendapatan Perusahaan"></textarea>
	        		<label>Jumlah Pendapatan (IDR)</label>
	        		<input type="number" name="jumlah" placeholder="Jumlah Pendapatan (IDR)" class="form-control">
	        	</form>
	        </div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="button" class="btn btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>
</body>
<script>
$(document).ready(function() {
$('#datatable').DataTable();
} );
</script>


  
</html>
