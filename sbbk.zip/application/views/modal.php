			
			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5 style="">Data Pemasukan Modal</h5>
					<div style="">
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#formmodal">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Modal
						</button>
					</div>
					<div style="margin-left:0px;">
    			<div class="container-fluid">
					<table class="table table-bordered table-striped" id="myTable">
						<thead class="table-dark">
							<th width="40">#</th>
							<th width="200">Tanggal Inflow Cash</th>
							<th>Nama Projek</th>
							<th width="300">Nominal (IDR)</th>
							<th width="400">Keterangan</th>
							<th width="150">Panel</th>
						</thead>
						<tbody>
						<?php
						$modal=$this->M_modal->tampil_data_modal();
						$no=1;
						foreach($modal as $mod) {
							?>
							<tr>
								<td><?php echo $no ?></td>
								<td><?php echo $mod->tanggal_cash ?></td>
								<td><?php echo $mod->id_projek ?></td>
								<td align="right"><?php echo number_format($mod->nominal_cash) ?></td>
								<td><?php ?></td>
								<td></td>
							</tr>
							<?php
							$no++;
						}					
						?>
						</tbody>
					</table>
				</div>
				</div>
			</div>
		</div>
	</div>

<!-- Form tambah Modal -->
<div class="modal fade" id="formmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Tambah Data Pendapatan Perusahaan</h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>

        
	        <div class="container-fluid p-3" style="text-align: left;">
	        	<form method="post" action="<?php echo base_url().'Modal/add_modal' ?>">
	        		<label>Tanggal Modal Diterima</label>
	        		<input type="date" name="tanggal_cash" placeholder="Tanggal Modal Diterima" class="form-control"><br>
	        		<label>Pilih Projek</label>
	        		<input type="text" name="nama_projek" class="form-control" placeholder="Ketikan Nama Projek" id="nama_projek">
	        		<input type="hidden" name="id_projek" id="id_projek"><br>
	        		<label>Nominal Cash (IDR)</label>
	        		<input type="text" id="nilai" name="nominal_cash" placeholder="Nominal Cash Diterima (IDR)" class="form-control" onkeydown="return numbersonly(this, event);" onkeyup="javascript:tandaPemisahTitik(this);"><br>	        		
	        	
	        </div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Form tambah Modal -->

</body>
<script>
new DataTable('#myTable', {
    searching: true,
});
</script>
<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#nama_projek" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Gaji/projek'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        autoFocua:true,
        appendTo:"#modal-fullscreen",
        select: function (event, ui) {
          // Set selection
          $('#nama_projek').val(ui.item.nama_projek); // display the selected text
          $('#id_projek').val(ui.item.id_projek);
          return false;
        }
      })
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='table table-striped'>" )
		.append( "<tr><td width='200'>"+item.nama_projek+"</td><td width=''>"+item.lokasi+"</td></tr>" )
		.appendTo( ul );
		};
    });
</script>
<script>
			        function formatAngka(input) {
			            let nilai = input.value.replace(/\D/g, '');
			            if (nilai === '') {
			                input.value = '';
			            } else {
			                let nilaiFormatted = nilai.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
			                input.value = nilaiFormatted;
			            }
			        }
			    </script>
<script type="text/javascript">
	
</script>
</html>