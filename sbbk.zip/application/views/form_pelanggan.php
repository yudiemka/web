			<div class="container-fluid container-lg p-3 bg-white my-3 border">
				<?php
				$kontrak=$this->M_kontrak->kontrak();
				$nokontrak=$kontrak->num_rows()+1;
				$my=date('m/Y');
				?>
				<form class="form" id="form_kontrak" method="post" action="<?php echo base_url().'Kontrak/kontrak_baru' ?>" >
					<fieldset>
						<legend>Data Pelanggan Baru</legend>

						<table class="table table-borderless table-hover">
							<tr>
								<td colspan="3">
									<label>Nomor Kontrak Kendaraan</label>
									<input type="text" name="no_kontrak" class="form-control" readonly value="0<?php echo $nokontrak; echo "/BR/$my"; ?>">
								</td>
								<td>
									<label>Tanggal Kontrak</label>
									<input type="date" name="tgl_kontrak" class="form-control " value="<?php  ?>">
								</td>
							</tr>							
							<tr>
								<td colspan="4">
									<label>Ketikan Nama Pelanggan</label>
									<input type="text" id="key_pelanggan" name="pelanggan" class="form-control" placeholder="Silahkan Ketik Nama Pelanggan">
									<input type="hidden" name="id_pelanggan" id="id_pelanggan">
								</td>
							</tr>
							<tr>
								<td colspan="4">
									<label>ketikan Merk / Tipe Kendaraan</label>
									<input type="text" id="key_kendaraan" name="key_kendaraan" class="form-control" placeholder="Silahkan Ketik Merk / Tipe Kendaraan" >
									<input type="hidden" name="id_kendaraan" id="id_kendaraan">
								</td>
							</tr>
							<tr>					
								<td>
									<label>Jenis Kontrak Paket</label>
									<select id="jenis_kontrak" name="jenis_kontrak" class="form-control" style="text-transform: uppercase;" onchange="tampilkan()">
										<option value="0">Pilih Jenis Kontrak</option>
										<?php 
										$paket=$this->M_kontrak->pilih_paket();
										foreach($paket as $p) {
											echo "
											<option value='$p->id'>$p->jenis</option>
											";
										}
										?>
									</select>
									<input type="hidden" name="persen" id="persen">
									<input id="subtotal" type="hidden" placeholder="sub">
									<input type="hidden" id="harga" name="">
								</td>
								<td>
									<label>Jumlah Hari / Paket</label>
									<input type="number" id="jumlahpaket" name="jumlah_paket" class="form-control" onchange="nilai()">
								</td>
								<td>
									<label>Jam Kendaraan Keluar </label>
									<input type="time" id="jam" name="jam_keluar" class="form-control">
								</td>
								<td align="right">
									<label><b>Nilai Kontrak (Rp.)</b></label>
									<input type="text" name="total" id="total_kontrak" placeholder="Nilai Kontrak (Rp.)" class="form-control" readonly style="text-align: right;">
								</td>
							</tr>
						</table>
						<hr>
						<table class="table table-bordered">							
							<tr>
								<td>Nama Pelanggan</td>
								<td width="450"><div id="nama_pelanggan"></div></td>
								<td>No. Identitas</td>
								<td width="500"><div id="no_id"></td>
							</tr>
							<tr>
								<td>Alamat Lengkap</td>
								<td width="450"><div id="alamat_pelanggan"></div></td>
								<td>No. Kontak Hp / WA</td>
								<td width="500"><div id="kontak_pelanggan"></td>
							</tr>
							<tr>
								<td>Merk Kendaraan</td>
								<td><div id="kendaraan"></div></td>
								<td>Tipe / Grade / Warna</td>
								<td><div></div></td>
							</tr>
							<tr>
								<td>No. Plat Polisi</td>
								<td><div id="no_pol"></div></td>
								<td>Tarif / Hari (R.p)</td>
								<td><div id="tarif"></div></td>
							</tr>
						</table>			
					</fieldset>
					
					<table class="table">
						<tr>
							<td colspan="2">
								<br>
								<button class="btn btn-primary" type="submit" id="btn-proses" disabled>
									<i class="fas fa-save"></i>&nbsp;Proses Kontrak
								</button>
								<button class="btn btn-danger" type="reset">
									<i class="fas fa-times-circle"></i>&nbsp;Reset Form
								</button>
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</div>							
</body>

<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#key_pelanggan" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Kontrak/cari_pelanggan'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        select: function (event, ui) {
          // Set selection          
          $('#nama_pelanggan').html(ui.item.nama); // display the selected text
          $('#alamat_pelanggan').html(ui.item.alamat);
          $('#kontak_pelanggan').html(ui.item.kontak);
          $('#id_pelanggan').val(ui.item.id);
          $("#key_kendaraan").focus();

          return false;
        }
      })

    	
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='auto table table-hover'>" )
		.append( "<tr><td width='200'>"+item.nama+"</td><td width=''>"+item.alamat+"</td><td width='150'>"+item.kontak+"</td></tr>" )
		.appendTo( ul );

		};
		;
    });
</script>

<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#key_kendaraan" ).autocomplete({

        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Kontrak/cari_kendaraan'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        select: function (event, ui) {
          // Set selection
          var p=$('#tarif').val();
          $('#kendaraan').html(ui.item.merk); // display the selected text          
          $('#no_pol').html(ui.item.nopol);
          $('#tarif').html(ui.item.harga);
          $('#harga').val(ui.item.harga);
          $('#id_kendaraan').val(ui.item.id);
          $("#jenis_kontrak").focus();
          return false;
        }
      })
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='auto table table-hover'>" )
		.append( "<tr><td width='' style='text-transform:uppercase;'>"+item.merk+"</td><td width='200'>"+item.nopol+"</td><td width='250'>Rp."+item.harga+"/Hari</td></tr>" )
		.appendTo( ul );
		};
    });

    
</script>

<script type="text/javascript">
	function tampilkan() {
		var xx = document.getElementById('jenis_kontrak').value;
		var yy = document.getElementById('harga').value;
		if(xx=='1') {
			zz = parseInt(xx)*parseInt(yy);
		}
		else if(xx=='2'){
			zz = (parseInt(yy)-(parseInt(yy))*(15/100))*7;
		}
		else if(xx=='3') {
			zz = (parseInt(yy)-(parseInt(yy))*(20/100))*30;
		}
		document.getElementById('persen').value=xx;
		document.getElementById('subtotal').value=zz;
		document.getElementById('jumlahpaket').focus();
	} 

	function nilai() {
		var x = document.getElementById('subtotal').value;
		var y = document.getElementById('jumlahpaket').value;
		document.getElementById('total_kontrak').value=parseInt(x) * parseInt(y);
		document.getElementById('jam').focus();
		document.getElementById('btn-proses').removeAttribute('disabled');
	}

</script>


</html>