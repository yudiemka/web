			
			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Data Pembayaran DP Rumah</h5>
					<div>
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#staticBackdrop">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Pembayaran DP
						</button>
					</div>
						<br><br>
					<div style="margin-left:0px;">
					<table class="table table-bordered table-striped text-uppercase" id="myTable">
						<thead class="table-dark">
							<th width="40">#</th>
							<th width="200">Tanggal Transaksi</th>
							<th width="300">Nama Konsumen</th>
							<th>Projek</th>
							<th width="150">Nominal (IDR.)</th>	
							<th width="150">Panel</th>
						</thead>
						<tbody>
						<?php
						$dope=$this->M_dp->tampil_data();
						$no=1;
						foreach($dope as $dp) {
							?>
							<tr class="align-middle">
								<td><?php echo $no ?></td>
								<td><?php echo $dp->tanggal_dp ?></td>
								<td>
									<?php
									$konsumen=$this->M_konsumen->pilih_data($dp->id_konsumen);
									foreach($konsumen as $k) {
										echo $k->nama_konsumen;
									}
									?>
								</td>
								<td>
									<?php
									$projek=$this->M_projek->pilih_data($dp->id_projek);
									foreach($projek as $pro) {
										echo $pro->nama_projek;
									}
									?>
								</td>
								<td><?php echo number_format($dp->nominal_dp) ?></td>
								<td>
									<button class="btn btn-sm btn-danger btn-hapus-dp" id="<?php echo $dp->id_dp ?>"><i class="fas fa-trash-alt"></i></button>
									<button class="btn btn-sm btn-primary btn-edit-dp" id="<?php echo $dp->id_dp ?>"><i class="fas fa-pen"></i></button>
									<button class="btn btn-sm btn-info btn-detail-dp" id="<?php echo $dp->id_dp ?>"><i class="fas fa-search"></i></button>
								</td>
							</tr>
							<?php
							$no++;
						}					
						?>
						</tbody>
					</table>
				</div>
				</div>
			</div>
		</div>
	</div>

<!-- Pembayaan DP -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Pembayaran Down Payment (DP)</h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>

        
	        <div class="container-fluid p-3" style="text-align: left;text-transform: uppercase;">
	        	<form method="post" action="<?php echo base_url().'Dp/bayar' ?>">
	        	<table class="table table-borderless">
	        		<tr>
	        			<td>
	        				<label>Tanggal Transaksi</label>
	        				<input type="date" name="tgl_transaksi" id="tgl_transaksi" class="form-control" placeholder="tgl_transaksi">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td colspan="2">
	        				<label>Nama Konsumen</label>
	        				<input type="text" name="nama_konsumen" id="nama_konsumen" class="form-control" placeholder="Nama Lengkap Konsumen">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td colspan="2">
	        				<label>Alamat Konsumen</label>
	        				<input type="text" name="alamat_konsumen" id="alamat_konsumen" class="form-control" placeholder="Alamat Lengkap Konsumen">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td colspan="2">
	        				<label>Nomor Hp</label>
	        				<input type="text" name="nohp_konsumen" id="nohp_konsumen" class="form-control" placeholder="Nomor Handphone Konsumen">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td colspan="2">
	        				<label>Perumahan</label>
	        				<input type="text" name="projek" id="projek" class="form-control" placeholder="Silahkan Ketik Nama Prumahan">
	        				<input type="hidden" name="id_projek" id="id_projek">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td>
	        				<label>Blok Rumah</label>
	        				<input type="text" name="blok_rumah" id="blok_rumah" class="form-control" placeholder="Blok Rumah">
	        			</td>
	        			<td>
	        				<label>Nomor</label>
	        				<input type="text" name="no_rumah" id="no_rumah" class="form-control" placeholder="Nomor Rumah">
	        			</td>
	        		</tr>
	        			<td colspan="2">
	        				<label>Nominal Down Payment (IDR.)</label>
	        				<input type="text" name="nominal_dp" id="nilai" class="form-control" placeholder="Nominal K P R (IDR.)">
	        			</td>
	        		</tr>
	        	</table>  	
	        </div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        		</form>
      </div>
    </div>
  </div>
</div>
<!-- Form tambah KPR-->

</body>
<script>
$(document).ready( function () {
	$('#myTable').DataTable();
} );
</script>
<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#projek" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Gaji/projek'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        autoFocua:true,
        appendTo:"#modal-fullscreen",
        select: function (event, ui) {
          // Set selection
          $('#projek').val(ui.item.nama_projek); // display the selected text
          $('#id_projek').val(ui.item.id_projek);
          return false;
        }
      })
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='table table-striped'>" )
		.append( "<tr><td width='200'>"+item.nama_projek+"</td><td width='200'>"+item.lokasi+"</td><td width='50'>"+item.jumlah_unit+"</td></tr>" )
		.appendTo( ul );
		};
    });
</script>
<script>
function formatAngka(input) {
	let nilai = input.value.replace(/\D/g, '');
	if (nilai === '') {
		input.value = '';
	}
	else {
		let nilaiFormatted = nilai.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
		input.value = nilaiFormatted;
		}
	}
</script>

<script>
	$(document).ready(function() {
  // Tangani klik pada tombol hapus
  $(document).on('click', '.btn-hapus-dp', function(e) {
    e.preventDefault(); // Cegah perilaku default (misalnya, mengikuti tautan)

    var id = $(this).attr('id'); // Ambil ID data yang akan dihapus (dari atribut data-id)

    // Konfirmasi penghapusan (opsional)
    if (confirm('Yakin ingin menghapus data ini?')) {
      // Kirim permintaan AJAX
      $.ajax({
        type: 'POST', // Atau DELETE sesuai kebutuhan
        url: '<?php echo base_url().'Dp/hapus_data_dp' ?>', // Ganti dengan URL skrip PHP Anda
        data: { id: id },
        success: function(response) {
          location.reload();
        },
        error: function() {
          alert('Terjadi kesalahan saat menghapus data.');
        }
      });
    }
  });
});
</script>

</html>