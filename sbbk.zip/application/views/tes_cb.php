<form action="<?php echo base_url().'Menu/addmodul' ?>" method="POST">
    <table class="table table-bordered text-uppercase">
        <th width="30"></th>
        <th width="30"></th>
        <th>Modul</th>
        <?php
        $modul=$this->M_menu->tampil_data_submenu();
        foreach($modul as $m) {
            ?>
            <tr class="text-uppercase">
                 <td class="text-uppercase"><input type="checkbox" name="modul[]" value="<?php echo $m->id_menu ?>"><?php echo $m->id_menu ?></td>
                <td class="text-uppercase"><input type="checkbox" name="modul[]" value="<?php echo $m->id_submenu ?>"></td>
                <td class="text-uppercase"><?php echo $m->nama_submenu ?></td>
            </tr>
            <?php
        }
        ?>
        <tr>
            <td>
                <button>Simpan</button>
            </td>
        </tr>
    </table>
</form>
<table class="table table-bordered">
    <?php
    $menu=$this->M_menu->tampil_modul();
    foreach($menu as $mn) {
        ?>
        <tr>
            <td><?php echo $mn->id ?></td>
            <td>
                <?php echo $mn->modul ?>
            </td>
            <td>
                <?php
                $data1=explode(",", $mn->modul);
                $cekaktif=$this->M_menu->menu_in($data1);
                foreach($cekaktif->result() as $ca) {
                    echo "$ca->id_submenu<br>";
                }
                ?>
            </td>
            <td>
                <?php
                $data2=explode(",", $mn->modul);
                $ceknotaktif=$this->M_menu->menu_not_in($data2);
                foreach($ceknotaktif->result() as $can) {
                    echo "$can->id_submenu<br>";
                }
                ?>
            </td>
        </tr>
        <?php
    }
    ?>
</table>