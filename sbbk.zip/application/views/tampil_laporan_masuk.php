<?php
if($projek=='0') {
	if($periode=='0') {
		?>
		<h5 class="text-uppercase">laporan Pemasukan Perusahaan</h5>
		<h6>Periode laporan : Keseluruhan</h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary ">
				<th width="30">#</th>
				<th width="200">Tanggal Transaksi</th>
				<th width="150">Kode</th>
				<th>Projek Perumahan</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
			<tbody>
				<?php
				$no=1;
				$query=$this->M_masuk->tampil_data();
				foreach($query as $q) {
					?>
					<tr>
						<td><?php echo $no ?></td>
						<td><?php echo $q->tgl_masuk ?></td>
						<td>
							<?php
							if($q->jenis_masuk=='jm01') {echo "modal";}
							elseif($q->jenis_masuk=='jm02') {echo "kpr";}
							elseif($q->jenis_masuk=='jm03') {echo "dp";}
							?>
						</td>
						<td>
							<?php
							$projek=$this->M_projek->pilih_data($q->id_projek);
							foreach ($projek as $p) { echo $p->nama_projek; }
							?>
						</td>
						<td align="right"><?php echo number_format($q->total_masuk) ?></td>
					</tr>
					<?php
					$no++;
				} 
				?>
				<tr class="table-primary">
					<td colspan="4" align="right">Total Pemasukan Perusahaan</td>
					<td align="right">
						<?php echo number_format($totalmasuk) ?>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}
	elseif($periode=='1') {
		?>
		<h5 class="text-uppercase">laporan harian Pemasukan Perusahaan</h5>
		<h6>Periode laporan : <?php echo $tgl ?></h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary ">
				<th width="30">#</th>
				<th width="200">Tanggal Transaksi</th>
				<th width="150">Kode</th>
				<th>Projek Perumahan</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
			<tbody>
				<?php
				$no=1;
				$query=$this->M_laporan->tampil_data_masuk_hari($tgl);
				foreach($query as $q) {
					?>
					<tr>
						<td><?php echo $no ?></td>
						<td><?php echo $q->tgl_masuk ?></td>
						<td>
							<?php
							if($q->jenis_masuk=='jm01') {echo "modal";}
							elseif($q->jenis_masuk=='jm02') {echo "kpr";}
							elseif($q->jenis_masuk=='jm03') {echo "dp";}
							?>
						</td>
							<td>
								<?php
								$projek=$this->M_projek->pilih_data($q->id_projek);
								foreach ($projek as $p) { echo $p->nama_projek; }
								?>
							</td>
							<td align="right"><?php echo number_format($q->total_masuk) ?></td>
						</tr>
					<?php
					$no++;
				}
				?>
				<tr class="table-primary">
					<td colspan="4" align="right">Total Pemasukan Perusahaan</td>
					<td align="right">
						<?php echo number_format($totalmasuk) ?>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}
	elseif($periode=='2') {
		?>
		<h5 class="text-uppercase">laporan Bulanan Pemasukan Perusahaan</h5>
		<h6>Periode laporan : <?php echo $bulan ?></h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary ">
				<th width="20">#</th>
				<th width="200">Tanggal Transaksi</th>
				<th width="150">Kode</th>
				<th>Projek Perumahan</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
			<tbody>
				<?php
				$no=1;
				$query=$this->M_laporan->tampil_data_masuk_bulan($bulan);
				foreach($query as $q) {
					?>
					<tr>
						<td><?php echo $no ?></td>
						<td><?php echo $q->tgl_masuk ?></td>
						<td>
							<?php
							if($q->jenis_masuk=='jm01') {echo "modal";}
							elseif($q->jenis_masuk=='jm02') {echo "kpr";}
							elseif($q->jenis_masuk=='jm03') {echo "dp";}
							?>
						</td>
						<td>
							<?php
							$projek=$this->M_projek->pilih_data($q->id_projek);
							foreach ($projek as $p) { echo $p->nama_projek; }
							?>
						</td>
						<td align="right"><?php echo number_format($q->total_masuk) ?></td>
					</tr>
					<?php
					$no++;
				}
				?>
				<tr class="table-primary">
					<td colspan="4" align="right">Total Pemasukan Perusahaan</td>
					<td align="right">
						<?php echo number_format($totalmasuk) ?>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}
	elseif($periode=='3') {
		?>
		<h5 class="text-uppercase">laporan Tahunan Pemasukan Perusahaan</h5>
		<h6>Periode laporan : <?php echo $tahun ?></h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary ">
				<th width="20">#</th>
				<th width="200">Tanggal Transaksi</th>
				<th width="150">Kode</th>
				<th>Projek Perumahan</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
			<tbody>
				<?php
				$no=1;
				$query=$this->M_laporan->tampil_data_masuk_tahun($tahun);
				foreach($query as $q) {
					?>
					<tr>
						<td><?php echo $no ?></td>
						<td><?php echo $q->tgl_masuk ?></td>
						<td>
							<?php
							if($q->jenis_masuk=='jm01') {echo "modal";}
							elseif($q->jenis_masuk=='jm02') {echo "kpr";}
							elseif($q->jenis_masuk=='jm03') {echo "dp";}
							?>
						</td>
						<td>
							<?php
							$projek=$this->M_projek->pilih_data($q->id_projek);
							foreach ($projek as $p) { echo $p->nama_projek; }
							?>
						</td>
						<td align="right"><?php echo number_format($q->total_masuk) ?></td>
					</tr>
					<?php
					$no++;
				}
				?>
				<tr class="table-primary">
					<td colspan="4" align="right">Total Pemasukan Perusahaan</td>
					<td align="right">
						<?php echo number_format($totalmasuk) ?>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}
	elseif($periode=='4') {
		?>
		<h5 class="text-uppercase">laporan harian Pemasukan Perusahaan</h5>
		<h6>Periode laporan : <?php echo $tgl1 ?> hingga <?php echo $tgl1 ?></h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary ">
				<th width="20">#</th>
				<th width="200">Tanggal Transaksi</th>
				<th width="150">Kode</th>
				<th>Projek Perumahan</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
			<tbody>
				<?php
				$no=1;
				$query=$this->M_laporan->tampil_data_masuk_rentang($tgl1,$tgl2);
				foreach($query as $q) {
					?>
					<tr>
						<td><?php echo $no ?></td>
						<td><?php echo $q->tgl_masuk ?></td>
						<td>
							<?php
							if($q->jenis_masuk=='jm01') {echo "modal";}
							elseif($q->jenis_masuk=='jm02') {echo "kpr";}
							elseif($q->jenis_masuk=='jm03') {echo "dp";}
							?>
						</td>
						<td>
							<?php
							$projek=$this->M_projek->pilih_data($q->id_projek);
							foreach ($projek as $p) { echo $p->nama_projek; }
							?>
						</td>
						<td align="right"><?php echo number_format($q->total_masuk) ?></td>
					</tr>
					<?php
					$no++;
				}
				?>
				<tr class="table-primary">
					<td colspan="4" align="right">Total Pemasukan Perusahaan</td>
					<td align="right">
						<?php echo number_format($totalmasuk) ?>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}
}

else {
	if($periode=='0') {
		?>
		<h5 class="text-uppercase">laporan Pemasukan Perusahaan</h5>
		<h6>Periode laporan : Keseluruhan</h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary ">
				<th width="20">#</th>
				<th width="200">Tanggal Transaksi</th>
				<th width="150">Kode</th>
				<th>Projek Perumahan</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
			<tbody>
				<?php
				$no=1;
				$query=$this->M_laporan->tampil_data_masuk_pro($projek);
				foreach($query as $q) {
					?>
					<tr>
						<td><?php echo $no ?></td>
						<td><?php echo $q->tgl_masuk ?></td>
						<td>
							<?php
							if($q->jenis_masuk=='jm01') {echo "modal";}
							elseif($q->jenis_masuk=='jm02') {echo "kpr";}
							elseif($q->jenis_masuk=='jm03') {echo "dp";}
							?>
						</td>
						<td>
							<?php
							$projek=$this->M_projek->pilih_data($q->id_projek);
							foreach ($projek as $p) { echo $p->nama_projek; }
							?>
						</td>
						<td align="right"><?php echo number_format($q->total_masuk) ?></td>
					</tr>
					<?php
					$no++;
				} 
				?>
				<tr class="table-primary">
					<td colspan="4" align="right">Total Pemasukan Perusahaan</td>
					<td align="right">
						<?php echo number_format($totalmasuk) ?>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}
	elseif($periode=='1') {
		?>
		<h5 class="text-uppercase">laporan harian Pemasukan Perusahaan</h5>
		<h6>Periode laporan : Tanggal <?php echo $bulan ?></h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary ">
				<th width="20">#</th>
				<th width="200">Tanggal Transaksi</th>
				<th width="150">Kode</th>
				<th>Projek Perumahan</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
			<tbody>
				<?php
				$no=1;
				$query=$this->M_laporan->tampil_data_masuk_hari_pro($projek,$tgl);
				foreach($query as $q) {
					?>
					<tr>
						<td><?php echo $no ?></td>
						<td><?php echo $q->tgl_masuk ?></td>
						<td>
							<?php
							if($q->jenis_masuk=='jm01') {echo "modal";}
							elseif($q->jenis_masuk=='jm02') {echo "kpr";}
							elseif($q->jenis_masuk=='jm03') {echo "dp";}
							?>
						</td>
						<td>
							<?php
							$projek=$this->M_projek->pilih_data($q->id_projek);
							foreach ($projek as $p) { echo $p->nama_projek; }
							?>
						</td>
						<td align="right"><?php echo number_format($q->total_masuk) ?></td>
						</tr>
					<?php
					$no++;
				}
				?>
				<tr class="table-primary">
					<td colspan="4" align="right">Total Pemasukan Perusahaan</td>
					<td align="right">
						<?php echo number_format($totalmasuk) ?>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}
	elseif($periode=='2') {
		?>
		<h5 class="text-uppercase">laporan Bulanan Pemasukan Perusahaan</h5>
		<h6>Periode laporan : <?php echo $bulan ?></h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary ">
				<th width="20">#</th>
				<th width="200">Tanggal Transaksi</th>
				<th width="150">Kode</th>
				<th>Projek Perumahan</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
			<tbody>
				<?php
				$no=1;
				$query=$this->M_laporan->tampil_data_masuk_bulan_pro($projek,$bulan);
				foreach($query as $q) {
					?>
					<tr>
						<td><?php echo $no ?></td>
						<td><?php echo $q->tgl_masuk ?></td>
						<td>
							<?php
							if($q->jenis_masuk=='jm01') {echo "modal";}
							elseif($q->jenis_masuk=='jm02') {echo "kpr";}
							elseif($q->jenis_masuk=='jm03') {echo "dp";}
							?>
						</td>
						<td>
							<?php
							$projek=$this->M_projek->pilih_data($q->id_projek);
							foreach ($projek as $p) { echo $p->nama_projek; }
							?>
						</td>
						<td align="right"><?php echo number_format($q->total_masuk) ?></td>
					</tr>
					<?php
					$no++;
				}
				?>
				<tr class="table-primary">
					<td colspan="4" align="right">Total Pemasukan Perusahaan</td>
					<td align="right">
						<?php echo number_format($totalmasuk) ?>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}
	elseif($periode=='3') {
		?>
		<h5 class="text-uppercase">laporan Tahunan Pemasukan Perusahaan</h5>
		<h6>Periode laporan : <?php echo $tahun ?></h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary ">
				<th width="20">#</th>
				<th width="200">Tanggal Transaksi</th>
				<th width="150">Kode</th>
				<th>Projek Perumahan</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
			<tbody>
				<?php
				$no=1;
				$query=$this->M_laporan->tampil_data_masuk_tahun_pro($projek,$tahun);
				foreach($query as $q) {
					?>
					<tr>
						<td><?php echo $no ?></td>
						<td><?php echo $q->tgl_masuk ?></td>
						<td>
							<?php
							if($q->jenis_masuk=='jm01') {echo "modal";}
							elseif($q->jenis_masuk=='jm02') {echo "kpr";}
							elseif($q->jenis_masuk=='jm03') {echo "dp";}
							?>
						</td>
						<td>
							<?php
							$projek=$this->M_projek->pilih_data($q->id_projek);
							foreach ($projek as $p) { echo $p->nama_projek; }
							?>
						</td>
						<td align="right"><?php echo number_format($q->total_masuk) ?></td>
					</tr>
					<?php
					$no++;
				}
				?>
				<tr class="table-primary">
					<td colspan="3" align="right">Total Pemasukan Perusahaan</td>
					<td align="right">
						<?php echo number_format($totalmasuk) ?>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}
	elseif($periode=='4') {
		?>
		<h5 class="text-uppercase">laporan harian Pemasukan Perusahaan</h5>
		<h6>Periode laporan : <?php echo $tgl1 ?> hingga <?php echo $tgl1 ?></h6>
		<table class="table table-bordered table-sm table-striped text-uppercase">
			<thead class="table-primary ">
				<th width="20">#</th>
				<th width="200">Tanggal Transaksi</th>
				<th width="150">Kode</th>
				<th>Projek Perumahan</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
			<tbody>
				<?php
				$no=1;
				$query=$this->M_laporan->tampil_data_masuk_rentang_pro($projek,$tgl1,$tgl2);
				foreach($query as $q) {
					?>
					<tr>
						<td><?php echo $no ?></td>
						<td><?php echo $q->tgl_masuk ?></td>
						<td>
							<?php
							if($q->jenis_masuk=='jm01') {echo "modal";}
							elseif($q->jenis_masuk=='jm02') {echo "kpr";}
							elseif($q->jenis_masuk=='jm03') {echo "dp";}
							?>
						</td>
						<td>
							<?php
							$projek=$this->M_projek->pilih_data($q->id_projek);
							foreach ($projek as $p) { echo $p->nama_projek; }
							?>
						</td>
						<td align="right"><?php echo number_format($q->total_masuk) ?></td>
					</tr>
					<?php
					$no++;
				}
				?>
				<tr class="table-primary">
					<td colspan="4" align="right">Total Pemasukan Perusahaan</td>
					<td align="right">
						<?php echo number_format($totalmasuk) ?>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}
}


?>



