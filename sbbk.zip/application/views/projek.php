			
			<div id="row" class="container-fluid p-3">
				<div class="container-fluid p-3 bg-white">
					<h5>Data Projek Perumahan Perusahaan</h5>
					<div>
						<button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#staticBackdrop">
							<i class="fas fa-plus-circle" style="margin-right: 5px;"></i>Projek
						</button>
					</div>
						<br><br>
					<div id="data-karyawan">
					<table class="table table-bordered table-striped" id="myTable">
						<thead class="table-dark">
							<th width="40">#</th>
							<th width="">Nama Projek</th>
							<th width="300">Lokasi Projek</th>
							<th width="200">Jumlah Unit Rumah</th>
							<th width="400">Keterangan</th>
							<th width="150">Panel</th>
						</thead>
						<tbody>
						<?php
						$projek=$this->M_projek->tampil_data();
						$no=1;
						foreach($projek as $pro) {
							?>
							<tr>
								<td><?php echo $no ?></td>
								<td><?php echo $pro->id_projek ?></td>
								<td><?php echo $pro->lokasi_projek ?></td>
								<td><?php echo $pro->jumlah_unit ?></td>
								<td><?php echo $pro->keterangan ?></td>
								<td>
									<button class="btn btn-danger btn-sm btn-hapus-projek" id="<?php echo $pro->id_projek ?>">
										<i class="fas fa-trash-alt"></i>
									</button>
									<?php
									if($pro->status_projek=='0') {
										?>
										<button type="button" class="btn btn-primary btn-sm btn-status" id="<?php echo $pro->id_projek ?>">
											close
										</button>
										<input type="hidden" name="status" id="status" value="<?php echo $pro->status_projek ?>">
										<?php
									}
									else {
										?>
										<button type="button" class="btn btn-success btn-sm btn-status" id="<?php echo $pro->id_projek ?>">
											open
										</button>
										<input type="hidden" name="status" id="status" value="<?php echo $pro->status_projek ?>">
										<?php
									}
									?>
								</td>
							</tr>
							<?php
							$no++;
						}
						?>
						</tbody>
					</table>
				</div>
				</div>
				</div>
			</div>
		</div>
	</div>

<!-- Form Tambah Projek -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      	<div class="container-fluid bg-primary text-white p-3">
	        <h5 style="font-size: 12pt; float:left;">Form Tambah Projek Perumahan</h5>
	        <a class="btn-close btn-sm btn-primary" style="float: right;color: white" data-bs-dismiss="modal" aria-label="Close"></a>
	    </div>

        
	        <div class="container-fluid p-3" style="text-align: left;text-transform: uppercase;">
	        	<form method="post" action="<?php echo base_url().'Projek/add' ?>">
	        	<table class="table table-borderless">
	        		<tr>
	        			<td>
	        				<label>Nama Projek</label>
	        				<input type="text" name="nama_projek" id="nama_projek" class="form-control" placeholder="Nama Projek / Perumahan">
	        			</td>
	        		</tr>
	        		<tr>
	        			<td colspan="2">
	        				<label>Lokasi Projek</label>
	        				<textarea class="form-control" placeholder="Lokasi Projek / Perumahan" name="lokasi_projek" id="lokasi_projek"></textarea>
	        			</td>
	        		</tr>
	        		<tr>
	        			<td colspan="2">
	        				<label>Jumlah Unit / Rumah</label>
	        				<input type="number" name="jumlah_unit" id="jumlah_unit" class="form-control" placeholder="Jumlah Unit Rumah">
	        			</td>
	        		</tr>
	        	</table>  	
	        </div>
      	
      <div class="modal-footer" style="float: right">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
        		</form>
      </div>
    </div>
  </div>
</div>
<!-- Form tambah KPR-->

</body>
<script>
$(document).ready( function () {
	$('#myTable').DataTable();
} );
</script>
<script type='text/javascript'>
    $(document).ready(function(){
     // Initialize 
     $( "#projek" ).autocomplete({
        source: function( request, response ) {
          // Fetch data
          $.ajax({
            url: "<?php echo base_url().'Modal/cari_projek'; ?>",
            type: 'post',
            dataType: "json",
            data: {
              search: request.term
            },
            success: function( data ) {
              response( data);
            }
          });
        },
        autoFocua:true,
        appendTo:"#modal-fullscreen",
        select: function (event, ui) {
          // Set selection
          $('#projek').val(ui.item.nama_projek); // display the selected text
          $('#id_projek').val(ui.item.id_projek);
          return false;
        }
      })
     
     .autocomplete( "instance" )._renderItem = function( ul, item ) {
		return $( "<table class='table table-striped'>" )
		.append( "<tr><td width='200'>"+item.nama_projek+"</td><td width='200'>"+item.lokasi_projek+"</td><td width='50'>"+item.jumlah_unit+"</td></tr>" )
		.appendTo( ul );
		};
    });
</script>
<script>
function formatAngka(input) {
	let nilai = input.value.replace(/\D/g, '');
	if (nilai === '') {
		input.value = '';
	}
	else {
		let nilaiFormatted = nilai.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
		input.value = nilaiFormatted;
		}
	}
</script>

<script>
	$(document).ready(function() {
  // Tangani klik pada tombol hapus
  $(document).on('click', '.btn-hapus-projek', function(e) {
	    e.preventDefault(); // Cegah perilaku default (misalnya, mengikuti tautan)

	    var id = $(this).attr('id'); // Ambil ID data yang akan dihapus (dari atribut data-id)

	    // Konfirmasi penghapusan (opsional)
	    if (confirm('Yakin ingin menghapus data ini?')) {
	      // Kirim permintaan AJAX
	      $.ajax({
	        type: 'POST', // Atau DELETE sesuai kebutuhan
	        url: '<?php echo base_url().'Projek/hapus_data' ?>', // Ganti dengan URL skrip PHP Anda
	        data: { id: id },
	        success: function(response) {
	          // Tangani respon dari server
	          location.reload();
	        },
	        error: function() {
	          alert('Terjadi kesalahan saat menghapus data.');
	        }
	      });
	    }
	  });
	});

	$(document).ready(function() {
  // Tangani klik pada tombol hapus
  $(document).on('click', '.btn-status', function(e) {
	    e.preventDefault(); // Cegah perilaku default (misalnya, mengikuti tautan)

	    var id = $(this).attr('id'); // Ambil ID data yang akan dihapus (dari atribut data-id)
	    var status = $("#status").val();

	    // Konfirmasi penghapusan (opsional)
	    if (confirm('Yakin Ubah Status Projek ini?')) {
	      // Kirim permintaan AJAX
	      $.ajax({
	        type: 'POST', // Atau DELETE sesuai kebutuhan
	        url: '<?php echo base_url().'Projek/ubah_status' ?>', // Ganti dengan URL skrip PHP Anda
	        data: { id: id,status:status },
	        success: function(response) {
	          // Tangani respon dari server
	          location.reload();
	        },
	        error: function() {
	          alert('Terjadi kesalahan saat menghapus data.');
	        }
	      });
	    }
	  });
	});
</script>

</html>