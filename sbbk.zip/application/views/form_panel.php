
<?php
//cek tabel panel->nrk

$cekpanel=$this->M_menu->cek_panel($id);
$row=$cekpanel->num_rows();
if($row=='0') {
	echo "<i>Silahkan Tentukan Hak Akses Menu Terlebih Dahulu</i>";
}
else {
	?>
	<input type="hidden" name="nrk" id="nrk" value="<?php echo $id ?>">
	<table class="table table-bordered table-striped ">
		<thead class="table-primary">
			<tr>
				<th width="25" rowspan="2">#</th>
				<th width="400" rowspan="2" class="text-middle">Modul</th>
				<th colspan="4" class="text-center">Panel Akses</th>
			</tr>
			<tr>
				<th width="50" class="text-center"><i class="fas fa-trash-alt" title="Hapus Data"></i></th>
				<th width="50" class="text-center"><i class="fas fa-pen" title="Ubah Data"></i></th>
				<th width="50" class="text-center"><i class="fas fa-plus-circle" title="Tambah Data"></i></th>
				<th width="50" class="text-center"><i class="fas fa-save" title="Tambah Data"></i></th>

			</tr>
		</thead>
		<tbody>
			<?php
			$modul=$this->M_menu->cek_akses($id);
			foreach($modul->result() as $dm) {
				$sdm=explode(",",$dm->modul);
				$submenu=$this->M_menu->submenu_in($sdm);
				$no=1;
				foreach($submenu->result() as $sm) {
					?>
					<tr>
						<td><?php echo $no ?></td>
						<td>
							<?php echo $sm->nama_submenu ?>
							<input type="text" name="modul[]" id="<?php echo $sm->id_submenu ?>" value="<?php echo $sm->id_submenu ?>">
						</td>
						<td  class="text-center">
							<input type="checkbox" name="hapus[]" id="0" class="hapus" value="1">
						</td>
						<td class="text-center">
							<input type="checkbox" name="ubah[]" id="ubah[]" class="ubah[]" value="1">
						</td>
						<td class="text-center">
							<input type="checkbox" name="tambah[]" id="0" class="tambah" value="1">
						</td>
						<td >
							<button class="btn btn-primary btn-sm" id="btn-add-panel"><i class="fas fa-save"></i></button>
						</td>
					</tr>
					<?php
					$no++;
				}
			}
			?>
		</tbody>
	</table>
	<?php
}
?>