			<div class="container-fluid container-lg p-3 bg-white my-3 border">
				<h6><?php echo $header ?></h6>
				<hr>

				<form class="form" method="post" action="<?php echo base_url().'Pengguna/add' ?>" >
					<table class="table">
						<tr>
							<td width="200">Nama Lengkap</td>
							<td>
								<input type="text" name="nama" class="form-control form-control-sm" placeholder="Nama Lengkap">
							</td>
						</tr>						
						<tr>
							<td width="200">Password</td>
							<td>
								<input type="password" name="password1" class="form-control form-control-sm" placeholder="Password untuk login sistem (Maks. 12 Karakter)">
							</td>
						</tr>
						<tr>
							<td width="200">Konfirmasi Ulang Password</td>
							<td>
								<input type="password" name="password2" class="form-control form-control-sm" placeholder="Ketikan Ulang Password untuk login sistem (Maks. 12 Karakter)">
							</td>
						</tr>
					</table>
					<hr>
					<table class="table">
						<tr>
							<td colspan="2">
								<button class="btn btn-primary btn-sm" type="submit">
									<i class="fas fa-save"></i>&nbsp;Simpan Data Pengguna
								</button>
								<button class="btn btn-danger btn-sm" type="reset">
									<i class="fas fa-times-circle"></i>&nbsp;Reset Form
								</button>
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</div>
</body>
  
</html>