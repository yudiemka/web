<div id="layout">
<?php
if($periode=='0') {
	?>
	no data
	<?php
}
//Harian
elseif($periode=='1') {
		?>
		<h6 class="text-uppercase" style="float: left;">Laporan Pengeluaran Operasional Perusahaan</h6>
		<div style="float:left;margin: -5px 5px 0px 10px;">
		</div>
		<br><br>					
		</table>
		<table class="table table-bordered table-striped table-hovered text-uppercase">
			<thead class="table-primary">
				<th width="20">#</th>
				<th width="200">Kode</th>
				<th width="150">Tanggal</th>
				<th>Rincian</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
		<?php
		$datakeluar=$this->M_laporan->tampil_data_keluar_ops_hari($tgl);
		$no=1;
		foreach($datakeluar as $dk) {
			?>
			<tbody>
				<tr>
					<td><?php echo $no ?></td>
					<td>
						<?php
						if($dk->jenis_keluar_ops=='jb02'){echo"gaji";}
						elseif($dk->jenis_keluar_ops=='jb06'){echo" Operasional";}
						elseif($dk->jenis_keluar_ops=='jb08'){echo" Kas Bon";}
						?>
					</td>
					<td><?php echo $dk->tgl_bayar_ops ?></td>
						<?php 
						if($dk->jenis_keluar_ops=='jb02'){
							$query=$this->M_laporan->pilih_data_gaji($dk->id_keluar_ops);
							foreach($query as $q) {
								echo "<td>$q->keterangan_gaji</td>";
							}
						}
						elseif($dk->jenis_keluar_ops=='jb06'){
							$query=$this->M_laporan->pilih_data_operasional($dk->id_keluar_ops);
							foreach($query as $q) {
								echo "<td>$q->rincian"; echo "&nbsp;(&nbsp;a.n&nbsp;$q->keterangan)</td>";
							}
						}	
						elseif($dk->jenis_keluar_ops=='jb08'){							
						}
						?>
					<td align="right"><?php echo number_format($dk->total_keluar_ops) ?></td>						
				</tr>			
			<?php
			$no++;
		}
		?>
				<tr class="table-info">
					<td colspan="4" align="right">
						Subtotal (IDR)
					</td>
					<td align="right">
					<?php echo number_format($totalkeluar);?>
					
					</td>
				</tr>
			</tbody>
		</table>
	<?php
}
//Bulan
elseif($periode=='2') {
		?>
		<h6 class="text-uppercase" style="float: left;">Laporan Pengeluaran Operasional Perusahaan</h6>
		<div style="float:left;margin: -5px 5px 0px 10px;">
		</div>
		<br><br>					
		</table>
		<table class="table table-bordered table-striped table-hovered text-uppercase">
			<thead class="table-primary">
				<th width="20">#</th>
				<th width="200">Kode</th>
				<th width="150">Tanggal</th>
				<th>Rincian</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
		<?php
		$datakeluar=$this->M_laporan->tampil_data_keluar_ops_bulan($bulan);
		$no=1;
		foreach($datakeluar as $dk) {
			?>
			<tbody>
				<tr>
					<td><?php echo $no ?></td>
					<td>
						<?php
						if($dk->jenis_keluar_ops=='jb02'){echo"gaji";}
						elseif($dk->jenis_keluar_ops=='jb06'){echo" Operasional";}
						elseif($dk->jenis_keluar_ops=='jb08'){echo" Kas Bon";}
						?>
					</td>
					<td><?php echo $dk->tgl_bayar_ops ?></td>
						<?php 
						if($dk->jenis_keluar_ops=='jb02'){
							$query=$this->M_laporan->pilih_data_gaji($dk->id_keluar_ops);
							foreach($query as $q) {
								echo "<td>$q->keterangan_gaji</td>";
							}
						}
						elseif($dk->jenis_keluar_ops=='jb06'){
							$query=$this->M_laporan->pilih_data_operasional($dk->id_keluar_ops);
							foreach($query as $q) {
								echo "<td>$q->rincian"; echo "&nbsp;(&nbsp;a.n&nbsp;$q->keterangan)</td>";
							}
						}	
						elseif($dk->jenis_keluar_ops=='jb08'){							
						}
						?>
					<td align="right"><?php echo number_format($dk->total_keluar_ops) ?></td>						
				</tr>			
			<?php
			$no++;
		}
		?>
				<tr class="table-info">
					<td colspan="4" align="right">
						Subtotal (IDR)
					</td>
					<td align="right">
					<?php echo number_format($totalkeluar);?>
					
					</td>
				</tr>
			</tbody>
		</table>
	<?php
}
//tahun
elseif($periode=='3') {
		?>
		<h6 class="text-uppercase" style="float: left;">Laporan Pengeluaran Operasional Perusahaan</h6>
		<div style="float:left;margin: -5px 5px 0px 10px;">
		</div>
		<br><br>					
		</table>
		<table class="table table-bordered table-striped table-hovered text-uppercase">
			<thead class="table-primary">
				<th width="20">#</th>
				<th width="200">Kode</th>
				<th width="150">Tanggal</th>
				<th>Rincian</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
		<?php
		$datakeluar=$this->M_laporan->tampil_data_keluar_ops_tahun($tahun);
		$no=1;
		foreach($datakeluar as $dk) {
			?>
			<tbody>
				<tr>
					<td><?php echo $no ?></td>
					<td>
						<?php
						if($dk->jenis_keluar_ops=='jb02'){echo"gaji";}
						elseif($dk->jenis_keluar_ops=='jb06'){echo" Operasional";}
						elseif($dk->jenis_keluar_ops=='jb08'){echo" Kas Bon";}
						?>
					</td>
					<td><?php echo $dk->tgl_bayar_ops ?></td>
						<?php 
						if($dk->jenis_keluar_ops=='jb02'){
							$query=$this->M_laporan->pilih_data_gaji($dk->id_keluar_ops);
							foreach($query as $q) {
								echo "<td>$q->keterangan_gaji</td>";
							}
						}
						elseif($dk->jenis_keluar_ops=='jb06'){
							$query=$this->M_laporan->pilih_data_operasional($dk->id_keluar_ops);
							foreach($query as $q) {
								echo "<td>$q->rincian"; echo "&nbsp;(&nbsp;a.n&nbsp;$q->keterangan)</td>";
							}
						}	
						elseif($dk->jenis_keluar_ops=='jb08'){							
						}
						?>
					<td align="right"><?php echo number_format($dk->total_keluar_ops) ?></td>						
				</tr>			
			<?php
			$no++;
		}
		?>
				<tr class="table-info">
					<td colspan="4" align="right">
						Subtotal (IDR)
					</td>
					<td align="right">
					<?php echo number_format($totalkeluar);?>
					
					</td>
				</tr>
			</tbody>
		</table>
	<?php
}
//rentang
elseif($periode=='4') {
		echo $tgl1;echo $tgl2;
		?>
		<h6 class="text-uppercase" style="float: left;">Laporan Pengeluaran Operasional Perusahaan</h6>
		<div style="float:left;margin: -5px 5px 0px 10px;">
		</div>
		<br><br>					
		</table>
		<table class="table table-bordered table-striped table-hovered text-uppercase">
			<thead class="table-primary">
				<th width="20">#</th>
				<th width="200">Kode</th>
				<th width="150">Tanggal</th>
				<th>Rincian</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
		<?php
		$datakeluar=$this->M_laporan->tampil_data_keluar_ops_rentang($tgl1,$tgl2);
		$no=1;
		foreach($datakeluar as $dk) {
			?>
			<tbody>
				<tr>
					<td><?php echo $no ?></td>
					<td>
						<?php
						if($dk->jenis_keluar_ops=='jb02'){echo"gaji";}
						elseif($dk->jenis_keluar_ops=='jb06'){echo" Operasional";}
						elseif($dk->jenis_keluar_ops=='jb08'){echo" Kas Bon";}
						?>
					</td>
					<td><?php echo $dk->tgl_bayar_ops ?></td>
						<?php 
						if($dk->jenis_keluar_ops=='jb02'){
							$query=$this->M_laporan->pilih_data_gaji($dk->id_keluar_ops);
							foreach($query as $q) {
								echo "<td>$q->keterangan_gaji</td>";
							}
						}
						elseif($dk->jenis_keluar_ops=='jb06'){
							$query=$this->M_laporan->pilih_data_operasional($dk->id_keluar_ops);
							foreach($query as $q) {
								echo "<td>$q->rincian"; echo "&nbsp;(&nbsp;a.n&nbsp;$q->keterangan)</td>";
							}
						}	
						elseif($dk->jenis_keluar_ops=='jb08'){							
						}
						?>
					<td align="right"><?php echo number_format($dk->total_keluar_ops) ?></td>						
				</tr>			
			<?php
			$no++;
		}
		?>
				<tr class="table-info">
					<td colspan="4" align="right">
						Subtotal (IDR)
					</td>
					<td align="right">
					<?php echo number_format($totalkeluar);?>
					
					</td>
				</tr>
			</tbody>
		</table>
	<?php
}
?>
</div>
<iframe id="printing-frame" name="print_frame" src="about:blank" style="display:none;"></iframe>
<script type="text/javascript">
function printDiv(elementId) {
	var myPrintContent = document.getElementById('tampil');
  var myPrintWindow = window.open('','','');
  myPrintWindow.document.write('<html><head>');
  myPrintWindow.document.write('<link rel="stylesheet" href="<?php echo base_url() ?>assets/lib/bs5/css/bootstrap.min.css">');
  myPrintWindow.document.write('<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/cetak.css">');
  myPrintWindow.document.write('</head><body>');
  myPrintWindow.document.write(myPrintContent.innerHTML);
  myPrintWindow.document.write('</body></html>');            
  myPrintWindow.document.getElementById('tampil').style.display = 'block';
  myPrintWindow.document.close();

 return false;
}

</script>