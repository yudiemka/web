			<div class="container-fluid container-lg p-3 bg-white my-3 border">
				<h6><?php echo $header ?>&nbsp;
					<?php
					$user=$this->M_user->pilih_data($id);
					foreach($user as $u)
					?>
					<a href="<?php echo base_url().'admin/form_pengguna'; ?>">
						<button class="btn btn-primary btn-sm">
							<i class="fas fa-plus-circle"></i>&nbsp;Entry Data Pengguna Sistem
						</button>
					</a>
				</h6>
				<hr>
				<table class="data table" width="400">
					<tr>
						<td width="150">Nama Pengguna</td>
						<td><b><?php echo $u->nama ?></b></td>
					</tr>
				</table>
				<table class="data table table-striped table-hover">
			        <thead class="table-primary">
			          <tr>
			            <th width="30">No</th>
			            <th>Navigasi</th>
			            <th width="150">Hak Akses <input type="checkbox" checked disabled></th>                         
			          </tr>
			        </thead>  
			        <tbody>
			        	<?php
			        	
			        	?>
			        </tbody>
			       
			    </table>     
			</div>
		</div>
	</div>
</body>
  
</html>