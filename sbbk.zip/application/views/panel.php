<!DOCTYPE html>
<html>
<head>
	<title>SIMKU - MIRANDA GRUP</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/bs5/css/bootstrap.min.css">	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/jquery14/jquery-ui.css">
	<script type="text/javascript" src="<?php echo base_url().'assets/icon/js/all.min.js'?>"></script>
	<script src="<?php echo base_url() ?>assets/lib/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/bootstrap/js/bootstrap.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery-3.3.1.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery14/jquery-ui.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/DataTables/datatables.min.css"/> 
	<script type="text/javascript" src="<?php echo base_url() ?>assets/lib/DataTables/datatables.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url() ?>assets/js/number.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/bs5/css/bootstrap.min.css"></script>
	<script src="<?php echo base_url() ?>assets/lib/bs5/js/bootstrap.bundle.min.js"></script>	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/style.css">	
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery-ui.js"></script>

	<script type="text/javascript" src="js/jquery-ui/jquery-ui.js"></script>
	<link rel="stylesheet" type="text/css" href="js/jquery-ui/jquery-ui.css">


</head>


</head>
<body style="background-color: lightgrey">
<style>
.ui-autocomplete {
	z-index: 2147483647;
	font-size: 9pt;
}
.ui-autocomplete table tr td {
	padding: 10px;
	text-transform: uppercase;
}
</style>
<div id="warper">
	<?php
	$status=$this->session->userdata("status_user");
	$nrk=$this->session->userdata("nrk");
	?>

	<nav class="navbar navbar-expand-md p=5 navbar-dark bg-dark fixed-top">
		<div class="logo" style="color: white;float: right;margin-right: 0px;position: absolute;right: 50px;">
			<b>AKASHA Property</b>
		</div>
	  <div class="container-fluid">
	    <div class="collapse navbar-collapse" id="navbarSupportedContent">

	      <ul class="navy navbar-nav me-auto mb-1 mb-lg-0 text-white" style="float: left;margin-left: 0px;">
	        <li class="nav-item">
	          <a class="nav-link" aria-current="page" href="<?php echo base_url().'admin/index' ?>">
		          <span class="navy"><i class="fas fa-home"></i></span>Home
		      </a>
	        </li>

	        <?php
			if ($status=='0') {
				$menu=$this->M_menu->akses($status);
				foreach($menu as $m) {
					if($m->jenis_menu=='0') {
						?>
						<li class="nav-item dropdown">
				        	<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
				            	<?php echo $m->nama_menu ?>
				          	</a>
				          	<ul class="dropdown-menu bg-dark text-light" aria-labelledby="navbarDropdown" style="font-size: 9.5pt;">
				          	<?php 
							$submenu=$this->M_menu->pilih_submenu($m->id_menu);
							foreach($submenu as $sm) {					
							?>						
					            <li><a class="dropdown-item" href="#"><?php echo $sm->nama_submenu ?></a></li>			          	
							<?php
							}
							?>
							</ul>
						</li>
						<?php
					}
					elseif($m->jenis_menu=='1') {
						?>
						<li class="nav-item">
				         	<a class="nav-link" href="#"><?php echo $m->nama_menu ?></a>
				        </li>
						<?php	
					}
				}
			}
			elseif($status=='99') {
				$menu=$this->M_menu->tampil_data_menu();
				foreach($menu as $m) {
					if($m->jenis_menu=='0') {
						?>
						<li class="nav-item dropdown">
				        	<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
				            	<span class="navy"><i class="<?php echo $m->icon_menu ?>"></i></span><?php echo $m->nama_menu ?>
				          	</a>
				          	<ul class="dropdown-menu bg-dark text-light" aria-labelledby="navbarDropdown" style="font-size: 9.5pt;">
				          	<?php 
							$submenu=$this->M_menu->pilih_submenu($m->id_menu);
							foreach($submenu as $sm) {					
							?>						
					            <li>
					            	<a class="dropdown-item" href="<?php echo $sm->anchor_submenu ?>">
					            		<span class="navy"><i class="<?php echo $sm->icon_submenu ?>"></i></span><?php echo $sm->nama_submenu ?>
					            	</a>
					            </li>			          	
							<?php
							}
							?>
							</ul>
						</li>
						<?php
					}
					elseif($m->jenis_menu=='1') {
						?>
						<li class="nav-item">
				         	<a class="nav-link" href="#"><?php echo $m->nama_menu ?></a>
				        </li>
						<?php	
					}
				}
			}
			else {
				//cek hakses
				$modul=$this->M_menu->cek_modul($nrk);
				$rowmodul=$modul->num_rows();
				if($rowmodul>'0') {
					foreach($modul->result() as $md)
					$datamenu=explode(",",$md->menu);
					$datasubmenu=explode(",",$md->modul);
					$nav=$this->M_menu->datamenu_in($datamenu);
					foreach($nav->result() as $n){
						?>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
				            	<span class="navy"><i class=""></i></span><?php echo $n->nama_menu ?>
				          	</a>
				          	<ul class="dropdown-menu bg-dark text-light" aria-labelledby="navbarDropdown" style="font-size: 9.5pt;">
				          	<?php 
							$submenu=$this->M_menu->pilih_akses($n->id_menu,$datasubmenu,$nrk);
							foreach($submenu as $sb) {
								?>
								<li>
					            	<a class="dropdown-item" href="<?php echo $sb->anchor_submenu ?>">
					            		<span class="navy"><i class="<?php echo $sb->icon_submenu ?>"></i></span><?php echo $sb->nama_submenu ?>
					            	</a>
					            </li>
								<?php
							}
							?>
							</ul>
						</li>
						<?php
					}
				}
				
			}
			?>
	        <li class="nav-item nav-right" style="float: right;margin-right: 0px;">
	          <a class="nav-link" href="<?php echo base_url().'login/logout' ?>">
	          	<span class="navy"><i class="fa fa-power-off"></i></span>LOGOUT
	          </a>
	        </li>
	    </div>
	  </div>
	</nav>
	<div id="row" class="container-fluid p-5">
