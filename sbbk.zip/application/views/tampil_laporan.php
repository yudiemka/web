<?php
if($projek=='0') {
	?>
	no data
	<?php
}
else {
	if($periode=='0') {

		$datakeluar=$this->M_laporan->tampil_data_keluar($projek);
		?>
		<h6 class="text-uppercase" style="float: left;">Laporan Pengeluaran Perusahaan</h6>
		<div style="float:left;margin: -5px 5px 0px 10px;">
			<a href="<?php echo base_url().'Laporan/cetak/';echo $projek; ?>" target="_blank" title="Cetak Laporan">
				<button class="btn btn-primary btn-sm"><i class="fas fa-print"></i></button>
			</a>
		</div>
		<br><br>
		<table class="table table-bordered text-uppercase table-info">
			<?php
			$dataprojek=$this->M_laporan->pilih_projek($projek);
			foreach($dataprojek as $dp) {
				?>
				<tr>
					<td width="150">Perumahan</td>
					<td>: <?php echo $dp->nama_projek; ?></td>
				</tr>
				<tr>
					<td width="150">Lokasi</td>
					<td>: <?php echo $dp->lokasi_projek; ?></td>
				</tr>
				<?php				
			}
			?>			
		</table>
		<table class="table table-bordered table-striped table-hovered text-uppercase">
			<thead class="table-primary">
				<th width="20">#</th>
				<th width="200">Kode</th>
				<th width="150">Tanggal</th>
				<th>Rincian</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
		<?php
		$no=1;
		foreach($datakeluar as $dk) {
			?>
			<tbody>
				<tr>
					<td><?php echo $no ?></td>
					<td>
						<?php
						if($dk->jenis_keluar=='jb01'){echo" LC & Perencanaan";}
						elseif($dk->jenis_keluar=='jb03'){echo"Upah";}
						elseif($dk->jenis_keluar=='jb04'){echo" Material";}
						elseif($dk->jenis_keluar=='jb05'){echo" Izin";}
						elseif($dk->jenis_keluar=='jb07'){echo "Hutang";}
						?>
					</td>
					<td><?php echo $dk->tgl_keluar_projek ?></td>
						<?php 
						if($dk->jenis_keluar=='jb01'){
							$query=$this->M_laporan->pilih_data_lc($dk->id_keluar_projek);
							foreach($query as $q) {
								echo "<td>$q->keterangan_lc</td>";
							}
						}
						elseif($dk->jenis_keluar=='jb03'){
							$query=$this->M_laporan->pilih_data_upah($dk->id_keluar_projek);
							foreach($query as $q) {
								echo "<td>$q->keterangan_upah"; echo "&nbsp;(&nbsp;a.n&nbsp;$q->penerima_upah)</td>";
							}
						}	
						elseif($dk->jenis_keluar=='jb04'){
							$query=$this->M_laporan->pilih_data_material($dk->id_keluar_projek);
							foreach($query as $q) {
								$faktur=$this->M_laporan->rinci_faktur($dk->id_keluar_projek);
								foreach($faktur as $dtf) {
									?>
									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td><?php echo $dtf->nama_material; ?></td>
										<td align="right"><?php echo number_format($dtf->subtotal) ?></td>
									</tr>
									<?php
								}
							}
						}	
						elseif($dk->jenis_keluar=='jb05'){
							$query=$this->M_laporan->pilih_data_izin($dk->id_keluar_projek);
							foreach($query as $q) {
								?>
								<td><?php echo $q->rincian; ?></td>
								<?php
							}
						}	
						elseif($dk->jenis_keluar=='jb07'){
							$query=$this->M_laporan->pilih_data_hutang($dk->id_keluar_projek);
							foreach($query as $q) {
								?>
								<td></td>
								<td>
									Hutang Pembelian Material &nbsp;(No Faktur : <?php echo $q->no_faktur ?>) 
								</td>
								<?php
							}
						}

					if($dk->jenis_keluar=='jb04'){
						?>
						<?php
					}
					else {
						?>
						<td align="right"><?php echo number_format($dk->total_keluar) ?></td>
						<?php
					}
					?>
				</tr>

			</tbody>
			<?php
			$no++;
		}
		?>
			<tr class="table-info">
				<td colspan="4" align="right">
					Subtotal (IDR)
				</td>
				<td align="right">
				<?php echo number_format($totalkeluar);?>
				
				</td>
			</tr>
		</table>
		<?php
	}
	//Hari
	else if($periode=='1') {
		
		$datakeluar=$this->M_laporan->tampil_data_keluar_hari($projek,$tgl);
		?>
		<h6 class="text-uppercase">Laporan Pengeluaran Perusahaan</h6><br>		
		<table class="table table-bordered text-uppercase table-info">
			<?php
			$dataprojek=$this->M_laporan->pilih_projek($projek);
			foreach($dataprojek as $dp) {
				?>
				<tr>
					<td width="150">Perumahan</td>
					<td>: <?php echo $dp->nama_projek; ?></td>
				</tr>
				<tr>
					<td width="150">Lokasi</td>
					<td>: <?php echo $dp->lokasi_projek; ?></td>
				</tr>
				<tr>
					<td width="150">Periode</td>
					<td>: Harian</td>
				</tr>
				<tr>
					<td width="150">Tanggal</td>
					<td>: <?php echo $tgl ?></td>
				</tr>
				<?php				
			}
			?>			
		</table>
		<table class="table table-bordered table-striped table-hovered text-uppercase" id="laporan">
			<thead class="table-primary">
				<th width="20">#</th>
				<th width="200">Kode</th>
				<th width="150">Tanggal</th>
				<th>Rincian</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
		<?php
		$no=1;
		foreach($datakeluar as $dk) {
			?>
			<tbody>
				<tr>
					<td><?php echo $no ?></td>
					<td>
						<?php
						if($dk->jenis_keluar=='jb01'){echo" LC & Perencanaan";}
						elseif($dk->jenis_keluar=='jb03'){echo"Upah";}
						elseif($dk->jenis_keluar=='jb04'){echo" Material";}
						elseif($dk->jenis_keluar=='jb05'){echo" Izin";}
						elseif($dk->jenis_keluar=='jb07'){echo "hutang";}
						?>
					</td>
					<td><?php echo $dk->tgl_keluar_projek ?></td>
						<?php 
						if($dk->jenis_keluar=='jb01'){
							$query=$this->M_laporan->pilih_data_lc($dk->id_keluar_projek);
							foreach($query as $q) {
								echo "<td>$q->keterangan_lc</td>";
							}
						}
						elseif($dk->jenis_keluar=='jb03'){
							$query=$this->M_laporan->pilih_data_upah($dk->id_keluar_projek);
							foreach($query as $q) {
								echo "<td>$q->keterangan_upah"; echo "&nbsp;(&nbsp;a.n&nbsp;$q->penerima_upah)</td>";
							}
						}	
						elseif($dk->jenis_keluar=='jb04'){
							$query=$this->M_laporan->pilih_data_material($dk->id_keluar_projek);
							foreach($query as $q) {
								$faktur=$this->M_laporan->rinci_faktur($dk->id_keluar_projek);
								foreach($faktur as $dtf) {
									?>
									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td><?php echo $dtf->nama_material; ?></td>
										<td align="right"><?php echo number_format($dtf->subtotal) ?></td>
									</tr>
									<?php
								}
							}
						}	
						elseif($dk->jenis_keluar=='jb05'){
							$query=$this->M_laporan->pilih_data_izin($dk->id_keluar_projek);
							foreach($query as $q) {
								?>
								<td><?php echo $q->rincian; ?></td>
								<?php
							}
						}	
						elseif($dk->jenis_keluar=='jb07'){
							$query=$this->M_laporan->pilih_data_hutang($dk->id_keluar_projek);
							foreach($query as $q) {
								?>
								<td>
									Hutang Pembelian Material &nbsp;(No Faktur : <?php echo $q->no_faktur ?>) 
								</td>
								<?php
							}
						}

					if($dk->jenis_keluar=='jb04'){
						?>
						<?php
					}
					else {
						?>
						<td align="right"><?php echo number_format($dk->total_keluar) ?></td>
						<?php
					}
					?>
				</tr>

			</tbody>
			<?php
			$no++;
		}
		?>
			<tr class="table-info">
				<td colspan="4" align="right">
					Subtotal (IDR)
				</td>
				<td align="right">
				<?php echo number_format($totalkeluar);?>
				
				</td>
			</tr>
		</table>
		<?php
	}
	//Hari
	//Bulan
	else if($periode=='2') {

		$datakeluar=$this->M_laporan->tampil_data_keluar_bulan($projek,$bulan);
		
		?>
		<h6 class="text-uppercase">Laporan Pengeluaran Perusahaan</h6><br>
		<table class="table table-bordered text-uppercase table-info">
			<?php
			$dataprojek=$this->M_laporan->pilih_projek($projek);
			foreach($dataprojek as $dp) {
				?>
				<tr>
					<td width="150">Perumahan</td>
					<td>: <?php echo $dp->nama_projek; ?></td>
				</tr>
				<tr>
					<td width="150">Lokasi</td>
					<td>: <?php echo $dp->lokasi_projek; ?></td>
				</tr>
				<tr>
					<td width="150">Periode</td>
					<td>: Bulanan</td>
				</tr>
				<tr>
					<td width="150">Bulan</td>
					<td>: <?php echo $bulan ?></td>
				</tr>
				<?php				
			}
			?>			
		</table>
		<table class="table table-bordered table-striped table-hovered text-uppercase">
			<thead class="table-primary">
				<th width="20">#</th>
				<th width="200">Kode</th>
				<th width="150">Tanggal</th>
				<th>Rincian</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
		<?php
		$no=1;
		foreach($datakeluar as $dk) {
			?>

			<tbody>
				<tr>
					<td><?php echo $no ?></td>
					<td>
						<?php
						if($dk->jenis_keluar=='jb01'){echo" LC & Perencanaan";}
						elseif($dk->jenis_keluar=='jb03'){echo"Upah";}
						elseif($dk->jenis_keluar=='jb04'){echo" Material";}
						elseif($dk->jenis_keluar=='jb05'){echo" Izin";}
						elseif($dk->jenis_keluar=='jb07'){echo "hutang";}
						?>
					</td>
					<td><?php echo $dk->tgl_keluar_projek ?></td>
						<?php 
						if($dk->jenis_keluar=='jb01'){
							$query=$this->M_laporan->pilih_data_lc($dk->id_keluar_projek);
							foreach($query as $q) {
								echo "<td>$q->keterangan_lc</td>";
							}
						}
						elseif($dk->jenis_keluar=='jb03'){
							$query=$this->M_laporan->pilih_data_upah($dk->id_keluar_projek);
							foreach($query as $q) {
								echo "<td>$q->keterangan_upah"; echo "&nbsp;(&nbsp;a.n&nbsp;$q->penerima_upah)</td>";
							}
						}	
						elseif($dk->jenis_keluar=='jb04'){
							$query=$this->M_laporan->pilih_data_material($dk->id_keluar_projek);
							foreach($query as $q) {
								$faktur=$this->M_laporan->rinci_faktur($dk->id_keluar_projek);
								foreach($faktur as $dtf) {
									?>
									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td><?php echo $dtf->nama_material; ?></td>
										<td align="right"><?php echo number_format($dtf->subtotal) ?></td>
									</tr>
									<?php
								}
							}
						}	
						elseif($dk->jenis_keluar=='jb05'){
							$query=$this->M_laporan->pilih_data_izin($dk->id_keluar_projek);
							foreach($query as $q) {
								?>
								<td><?php echo $q->rincian; ?></td>
								<?php
							}
						}	
						elseif($dk->jenis_keluar=='jb07'){
							$query=$this->M_laporan->pilih_data_hutang($dk->id_keluar_projek);
							foreach($query as $q) {
								?>
								<td>
									Hutang Pembelian Material &nbsp;(No Faktur : <?php echo $q->no_faktur ?>) 
								</td>
								<?php
							}
						}

					if($dk->jenis_keluar=='jb04'){
						?>
						<?php
					}
					else {
						?>
						<td align="right"><?php echo number_format($dk->total_keluar) ?></td>
						<?php
					}
					?>
				</tr>

			</tbody>
			<?php
			$no++;
		}
		?>
			<tr class="table-info">
				<td colspan="4" align="right">
					Subtotal (IDR)
				</td>
				<td align="right">
				<?php echo number_format($totalkeluar);?>
				
				</td>
			</tr>
		</table>
		<?php
	}
	//Bulan
	//Tahun
	else if($periode=='3') {

		$datakeluar=$this->M_laporan->tampil_data_keluar_tahun($projek,$tahun);
		
		?>
		
		<h6 class="text-uppercase">Laporan Pengeluaran Perusahaan</h6><br>
		<table class="table table-bordered text-uppercase table-info">
			<?php
			$dataprojek=$this->M_laporan->pilih_projek($projek);
			foreach($dataprojek as $dp) {
				?>
				<tr>
					<td width="150">Perumahan</td>
					<td>: <?php echo $dp->nama_projek; ?></td>
				</tr>
				<tr>
					<td width="150">Lokasi</td>
					<td>: <?php echo $dp->lokasi_projek; ?></td>
				</tr>
				<tr>
					<td width="150">Periode</td>
					<td>: TAHUNAN</td>
				</tr>
				<tr>
					<td width="150">Tahun</td>
					<td>: <?php echo $tahun ?></td>
				</tr>
				<?php				
			}
			?>			
		</table>
		<table class="table table-bordered table-striped table-hovered text-uppercase">
			<thead class="table-primary">
				<th width="20">#</th>
				<th width="200">Kode</th>
				<th width="150">Tanggal</th>
				<th>Rincian</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
		<?php
		$no=1;
		foreach($datakeluar as $dk) {
			?>

			<tbody>
				<tr>
					<td><?php echo $no ?></td>
					<td>
						<?php
						if($dk->jenis_keluar=='jb01'){echo" LC & Perencanaan";}
						elseif($dk->jenis_keluar=='jb03'){echo"Upah";}
						elseif($dk->jenis_keluar=='jb04'){echo" Material";}
						elseif($dk->jenis_keluar=='jb05'){echo" Izin";}
						elseif($dk->jenis_keluar=='jb07'){echo "hutang";}
						?>
					</td>
					<td><?php echo $dk->tgl_keluar_projek ?></td>
						<?php 
						if($dk->jenis_keluar=='jb01'){
							$query=$this->M_laporan->pilih_data_lc($dk->id_keluar_projek);
							foreach($query as $q) {
								echo "<td>$q->keterangan_lc</td>";
							}
						}
						elseif($dk->jenis_keluar=='jb03'){
							$query=$this->M_laporan->pilih_data_upah($dk->id_keluar_projek);
							foreach($query as $q) {
								echo "<td>$q->keterangan_upah"; echo "&nbsp;(&nbsp;a.n&nbsp;$q->penerima_upah)</td>";
							}
						}	
						elseif($dk->jenis_keluar=='jb04'){
							$query=$this->M_laporan->pilih_data_material($dk->id_keluar_projek);
							foreach($query as $q) {
								$faktur=$this->M_laporan->rinci_faktur($dk->id_keluar_projek);
								foreach($faktur as $dtf) {
									?>
									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td><?php echo $dtf->nama_material; ?></td>
										<td align="right"><?php echo number_format($dtf->subtotal) ?></td>
									</tr>
									<?php
								}
							}
						}	
						elseif($dk->jenis_keluar=='jb05'){
							$query=$this->M_laporan->pilih_data_izin($dk->id_keluar_projek);
							foreach($query as $q) {
								?>
								<td><?php echo $q->rincian; ?></td>
								<?php
							}
						}	
						elseif($dk->jenis_keluar=='jb07'){
							$query=$this->M_laporan->pilih_data_hutang($dk->id_keluar_projek);
							foreach($query as $q) {
								?>
								<td>
									Hutang Pembelian Material &nbsp;(No Faktur : <?php echo $q->no_faktur ?>) 
								</td>
								<?php
							}
						}

					if($dk->jenis_keluar=='jb04'){
						?>
						<?php
					}
					else {
						?>
						<td align="right"><?php echo number_format($dk->total_keluar) ?></td>
						<?php
					}
					?>
				</tr>

			</tbody>
			<?php
			$no++;
		}
		?>
			<tr class="table-info">
				<td colspan="4" align="right">
					Subtotal (IDR)
				</td>
				<td align="right">
				<?php echo number_format($totalkeluar);?>				
				</td>
			</tr>
		</table>
		<?php
	}
	//Tahun
	//Rentang Tanggal
	else if($periode=='4') {
		$datakeluar=$this->M_laporan->tampil_data_keluar_rentang($projek,$tgl1,$tgl2);
		
		?>
		
		<h6 class="text-uppercase">Laporan Pengeluaran Perusahaan</h6><br>
		<table class="table table-bordered text-uppercase table-info">
			<?php
			$dataprojek=$this->M_laporan->pilih_projek($projek);
			foreach($dataprojek as $dp) {
				?>
				<tr>
					<td width="150">Perumahan</td>
					<td>: <?php echo $dp->nama_projek; ?></td>
				</tr>
				<tr>
					<td width="150">Lokasi</td>
					<td>: <?php echo $dp->lokasi_projek; ?></td>
				</tr>
				<tr>
					<td width="150">Periode</td>
					<td>: Tanggal Tertentu</td>
				</tr>
				<tr>
					<td width="150">Rentang Tanggal</td>
					<td>: <?php echo $tgl1 ?>&nbsp;-&nbsp;<?php echo $tgl2 ?></td>
				</tr>
				<?php				
			}
			?>			
		</table>
		<table class="table table-bordered table-striped table-hovered text-uppercase">
			<thead class="table-primary">
				<th width="20">#</th>
				<th width="200">Kode</th>
				<th width="150">Tanggal</th>
				<th>Rincian</th>
				<th width="200">Nominal (IDR)</th>
			</thead>
		<?php
		$no=1;
		foreach($datakeluar as $dk) {
			?>

			<tbody>
				<tr>
					<td><?php echo $no ?></td>
					<td>
						<?php
						if($dk->jenis_keluar=='jb01'){echo" LC & Perencanaan";}
						elseif($dk->jenis_keluar=='jb03'){echo"Upah";}
						elseif($dk->jenis_keluar=='jb04'){echo" Material";}
						elseif($dk->jenis_keluar=='jb05'){echo" Izin";}
						elseif($dk->jenis_keluar=='jb07'){echo "hutang";}
						?>
					</td>
					<td><?php echo $dk->tgl_keluar_projek ?></td>
						<?php 
						if($dk->jenis_keluar=='jb01'){
							$query=$this->M_laporan->pilih_data_lc($dk->id_keluar_projek);
							foreach($query as $q) {
								echo "<td>$q->keterangan_lc</td>";
							}
						}
						elseif($dk->jenis_keluar=='jb03'){
							$query=$this->M_laporan->pilih_data_upah($dk->id_keluar_projek);
							foreach($query as $q) {
								echo "<td>$q->keterangan_upah"; echo "&nbsp;(&nbsp;a.n&nbsp;$q->penerima_upah)</td>";
							}
						}	
						elseif($dk->jenis_keluar=='jb04'){
							$query=$this->M_laporan->pilih_data_material($dk->id_keluar_projek);
							foreach($query as $q) {
								$faktur=$this->M_laporan->rinci_faktur($dk->id_keluar_projek);
								foreach($faktur as $dtf) {
									?>
									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td><?php echo $dtf->nama_material; ?></td>
										<td align="right"><?php echo number_format($dtf->subtotal) ?></td>
									</tr>
									<?php
								}
							}
						}	
						elseif($dk->jenis_keluar=='jb05'){
							$query=$this->M_laporan->pilih_data_izin($dk->id_keluar_projek);
							foreach($query as $q) {
								?>
								<td><?php echo $q->rincian; ?></td>
								<?php
							}
						}	
						elseif($dk->jenis_keluar=='jb07'){
							$query=$this->M_laporan->pilih_data_hutang($dk->id_keluar_projek);
							foreach($query as $q) {
								?>
								<td>
									Hutang Pembelian Material &nbsp;(No Faktur : <?php echo $q->no_faktur ?>) 
								</td>
								<?php
							}
						}

					if($dk->jenis_keluar=='jb04'){
						?>
						<?php
					}
					else {
						?>
						<td align="right"><?php echo number_format($dk->total_keluar) ?></td>
						<?php
					}
					?>
				</tr>

			</tbody>
			<?php
			$no++;
		}
		?>
			<tr class="table-info">
				<td colspan="4" align="right">
					Subtotal (IDR)
				</td>
				<td align="right">
				<?php echo number_format($totalkeluar);?>				
				</td>
			</tr>
		</table>
		<?php
	}
}
?>



