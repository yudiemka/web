	<div id="content-bar">
		<div class="box container-fluid bg-white p-3 text-dark"> 
		<h5><b><?php echo $header ?></b></h5><br>
		<?php foreach($bmhp as $dt) ?>
			<table class="">
				<tr>
					<td width="200">Nama B M H P</td>
					<td>: <?php echo $dt->nama_brg; ?></td>
				</tr>
				<tr>
					<td>Kemasan</td>
					<td>:</td>
				</tr>
				<tr>
					<td>Isi Kemasan</td>
					<td>:</td>
				</tr>
				<tr>
					<td>Satuan terkecil</td>
					<td>: <?php echo $dt->satuan ?></td>
				</tr>
				<tr>
					<td>Anggaran</td>
					<td>: <?php echo $dt->anggaran ?></td>
				</tr>
			</table>
			<br>
			<table class="data table-striped table-bordered">
				<tr class="table-primary">
					<th width="20" rowspan="2" valign="middle">#</th>
					<th width="150" rowspan="2">Tgl. Transaksi</th>
					<th rowspan="2">Nomor Dokumen Transaski</th>
					<th rowspan="2" width="350">Instansi</th>
					<th width="300" colspan="2">Jumlah Transaksi</th>
					<th rowspan="2" width="150">Jumlah Stok BMHP</th>
					<th rowspan="2" width="200">Staff</th>
				</tr>
				<tr class="table-primary">
					<th width="150">Masuk</th>
					<th width="150">Keluar</th>
				</tr>
				<?php
				$transaksi=$this->M_transaksi->pilih_data_transaksi($dt->id);
				$no=1;
				foreach($transaksi as $dt) {
					?>
					<tr>
						<td><?php echo $no; ?></td>
						<td align="center"><?php echo $dt->tgl_trans; ?></td>
						<td align="center"><?php echo $dt->no_transaksi; ?></td>
						<td align="center"></td>
						<?php
						if($dt->jenis_trans=='0') {
							?>
							<td align="right"></td>
							<td align="right"><?php echo $dt->jml_transaksi;?></td>
							<?php
						}
						else {
							?>
							<td align="right"><?php echo $dt->jml_transaksi;?></td>
							<td align="right"></td>
							<?php
						}
						?>
						<td></td>
						<td></td>
					</tr>
					<?php
					$no++;
				}
				?>
			</table>
		</div>
	</div>
</div>
</body>
</html>