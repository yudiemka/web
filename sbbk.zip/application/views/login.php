<!DOCTYPE html>
<html>
<head>
	<title>SIMLOG UPT IFLK</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/lib/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/login.css">
	<script type="text/javascript" src="<?php echo base_url().'assets/icon/js/all.min.js'?>"></script>
	<script src="<?php echo base_url() ?>assets/lib/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/bootstrap/js/bootstrap.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery-3.3.1.js"></script>
	<script src="<?php echo base_url() ?>assets/lib/jquery/jquery-ui.js"></script>
</head>
<body>
	
	<div id="login-box" class="text-primary">
		<img style="width:50%;margin-left:-20px" src="<?php echo base_url().'assets/img/akasha.jpg';?>">
		<h2 class="text-primary"><b>SIMKU</b></h2>
		<h6>Sistem Informasi Manajemen Keuangan</h63>
		<hr>
		<form action="<?php echo base_url().'login/aksi_login/';?>" method="post">
			<div class="input-group mb-3">
				<div class="input-group-prepend">
					<span class="btn btn-primary"><i class="fas fa-user-alt"></i></span>
				</div>
				<input type="text" class="form-control" placeholder="Username Karyawan" aria-label="Example text with button addon" aria-describedby="button-addon1" name="username">			
			</div>
			<div class="input-group mb-3">
				<div class="input-group-prepend">
					<span class="btn btn-primary"><i class="fas fa-lock"></i></span>
				</div>
				<input type="password" class="form-control" placeholder="Password Karyawan" aria-label="Example text with button addon" aria-describedby="button-addon1" name="password">			
			</div>
			<button class="btn btn-primary" type="submit" style="width: 100%"><b>M A S U K</b></button>
		</form>
	</div>
</body>
</html>

