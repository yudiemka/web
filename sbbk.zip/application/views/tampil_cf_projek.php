<?php
if($projek=='0') {
	?>
	<span style="font-size:12pt;">Silahkan Pilih Projek Perumahan dan Periode Cashflow</span>
	<?php
}
else {
	if($periode=='0') {
		?>
		<span style="font-size:12pt;">Silahkan Pilih Periode Cashflow</span>
		<?php
	}
	//Hari
	else if($periode=='1') {
		$dataprojek=$this->M_laporan->pilih_projek($projek);
		foreach($dataprojek as $dp)
		?>
	<h4>CASHFLOW PROJEK PEMBANGUNAN PERUMAHAN</h4>
	<hr>
		<table class="table table-borderless text-uppercase">
			<thead>
				<tr>
					<td width="200">Nama Perumahan</td>
					<td>: <?php echo $dp->nama_projek ?></td>
				</tr>
				<tr>
					<td width="200">Lokasi</td>
					<td>: <?php echo $dp->lokasi_projek ?></td>
				</tr>
				<tr>
					<td width="200">periode</td>
					<td>: Harian (Tanggal : <?php echo $tgl ?>)</td>
				</tr>
			</thead>
		</table>
		<table class="table table-bordered text-uppercase">
			<thead>
				<tr class="table-success">
					<th colspan="6">penerimaan</th>
				</tr>
				<tr class="table-primary">
					<th>No</th>
					<th>kode</th>
					<th>Tanggal transaksi</th>
					<th>keterangan</th>
					<th>Jumlah (Rp.)</th>
					<th>Total</th>
				</tr>
				<?php
				$in=$this->M_masuk->tampil_data_masuk_hari_pro($tgl,$projek);
				$row=$in->num_rows();
				if($row=='0') {
					?>
					<tr>
						<td colspan="6">Data Pemasukan Tidak Ada</td>
					</tr>
					<?php
				}
				else {
					$no=1;
					foreach($in->result() as $dm) {
						?>
						<tr>
							<td><?php echo $no ?></td>
							<?php
							$jenismasuk=$this->M_masuk->jenis_masuk($dm->jenis_masuk);
							foreach($jenismasuk as $jm) 
								?>
								<td><?php echo $jm->jenis_masuk; ?></td>
								
								<td><?php echo $dm->tgl_masuk ?></td>
								<td>
									<?php
									$ket=$this->M_masuk->pilih_detail_masuk($jm->jenis_masuk,$dm->id_masuk);
									foreach($ket as $k) echo $k->keterangan;
									?>
								</td>
							<td align="right"><?php echo number_format($dm->total_masuk) ?></td>
							<td></td>
							
						</tr>
						
						<?php
						$no++;
					}	
					?>
					<tr class="table-danger">
						<td colspan="5" align="right"><b>Total Pemasukan (Rp.)</b></td>
						<td align="right"><b><?php echo number_format($totalmasuk);?></b></td>
					</tr>
					<?php					
				}
				?>
				<tr class="table-success">
					<th colspan="6">pengeluaran</th>
				</tr>
				<tr class="table-primary">
					<th>No</th>
					<th>kode</th>
					<th>Tanggal transaksi</th>
					<th>keterangan</th>
					<th>Jumlah (Rp.)</th>
					<th>Total</th>
				</tr>
				<?php
				$out=$this->M_masuk->tampil_data_keluar_hari_pro($tgl,$projek);
				$row=$out->num_rows();
				if($row=='0') {
					?>
					<tr>
						<td colspan="6">Data Pengeluaran tidak ditemukan</td>
					</tr>
					<?php
				}
				else {
					$no=1;
					foreach($out->result() as $do) {
						?>
						<tr>
							<td><?php echo $no ?></td>
							<?php
							$jeniskeluar=$this->M_masuk->jenis_keluar($do->jenis_keluar);
							foreach($jeniskeluar as $jk) 
								?>
								<td><?php echo $jk->jenis_pengeluaran; ?></td>
								
								<td><?php echo $do->tgl_keluar_projek ?></td>
								<td>
									<?php
									echo $do->keterangan;
									?>
								</td>
								<td align="right">
									<?php echo number_format($do->total_keluar); ?>
								</td>
							<td></td>							
						</tr>
						
						
						<?php
						$no++;
					}
					?>
					<tr class="table-danger">
						<td colspan="5" align="right"><b>Total Pengeluaran (Rp.)</b></td>
						<td align="right"><b><?php echo number_format($totalkeluar);?></b></td>
					</tr>
					<tr class="table-success">
						<td colspan="5" align="right"><b>Neraca</b></td>
						<td align="right"><b><h6><?php echo number_format($totalmasuk-$totalkeluar);?></h6></b></td>
					</tr>					
					<?php						
				}
				?>
			</thead>
		</table>
		<?php
	}
	//Hari
	//Bulan
	else if($periode=='2') {
		$dataprojek=$this->M_laporan->pilih_projek($projek);
		foreach($dataprojek as $dp)
		?>
	<h4>CASHFLOW PROJEK PEMBANGUNAN PERUMAHAN</h4>
	<hr>
		<table class="table table-borderless text-uppercase">
			<thead>
				<tr>
					<td width="200">Nama Perumahan</td>
					<td>: <?php echo $dp->nama_projek ?></td>
				</tr>
				<tr>
					<td width="200">Lokasi</td>
					<td>: <?php echo $dp->lokasi_projek ?></td>
				</tr>
				<tr>
					<td width="200">periode</td>
					<td>: Harian (Bulan : <?php echo $bulan ?>)</td>
				</tr>
			</thead>
		</table>
		<table class="table table-bordered text-uppercase">
			<thead>
				<tr class="table-success">
					<th colspan="6">penerimaan</th>
				</tr>
				<tr class="table-primary">
					<th>No</th>
					<th>kode</th>
					<th>Tanggal transaksi</th>
					<th>keterangan</th>
					<th>Jumlah (Rp.)</th>
					<th>Total</th>
				</tr>
				<?php
				$in=$this->M_masuk->cf_masuk_bulan_pro($projek,$bulan);
				$row=$in->num_rows();
				if($row=='0') {
					?>
					<tr>
						<td colspan="6">Data Pemasukan Tidak Ada</td>
					</tr>
					<?php
				}
				else {
					$no=1;
					foreach($in->result() as $dm) {
						?>
						<tr>
							<td><?php echo $no ?></td>
							<?php
							$jenismasuk=$this->M_masuk->jenis_masuk($dm->jenis_masuk);
							foreach($jenismasuk as $jm) 
								?>
								<td><?php echo $jm->jenis_masuk; ?></td>
								
								<td><?php echo $dm->tgl_masuk ?></td>
								<td>
									<?php
									$ket=$this->M_masuk->pilih_detail_masuk($jm->jenis_masuk,$dm->id_masuk);
									foreach($ket as $k) echo $k->keterangan;
									?>
								</td>
							<td align="right"><?php echo number_format($dm->total_masuk) ?></td>
							<td></td>
							
						</tr>
						
						<?php
						$no++;
					}	
					?>
					<tr class="table-danger">
						<td colspan="5" align="right"><b>Total Pemasukan (Rp.)</b></td>
						<td align="right"><b><?php echo number_format($totalmasuk);?></b></td>
					</tr>
					<?php					
				}
				?>
				<tr class="table-success">
					<th colspan="6">pengeluaran</th>
				</tr>
				<tr class="table-primary">
					<th>No</th>
					<th>kode</th>
					<th>Tanggal transaksi</th>
					<th>keterangan</th>
					<th>Jumlah (Rp.)</th>
					<th>Total</th>
				</tr>
				<?php
				$out=$this->M_masuk->cf_keluar_bulan_pro($projek,$bulan);
				$row=$out->num_rows();
				if($row=='0') {
					?>
					<tr>
						<td colspan="6">Data Pengeluaran tidak ditemukan</td>
					</tr>
					<?php
				}
				else {
					$no=1;
					foreach($out->result() as $do) {
						?>
						<tr>
							<td><?php echo $no ?></td>
							<?php
							$jeniskeluar=$this->M_masuk->jenis_keluar($do->jenis_keluar);
							foreach($jeniskeluar as $jk) 
								?>
								<td><?php echo $jk->jenis_pengeluaran; ?></td>
								
								<td><?php echo $do->tgl_keluar_projek ?></td>
								<td>
									<?php
									echo $do->keterangan;
									?>
								</td>
								<td align="right">
									<?php echo number_format($do->total_keluar); ?>
								</td>
							<td></td>							
						</tr>
						
						
						<?php
						$no++;
					}
					?>
					<tr class="table-danger">
						<td colspan="5" align="right"><b>Total Pengeluaran (Rp.)</b></td>
						<td align="right"><b><?php echo number_format($totalkeluar);?></b></td>
					</tr>
					<tr class="table-success">
						<td colspan="5" align="right"><b>Neraca</b></td>
						<td align="right"><b><h6><?php echo number_format($totalmasuk-$totalkeluar);?></h6></b></td>
					</tr>					
					<?php						
				}
				?>
			</thead>
		</table>
		<?php
	}
	//Bulan
	//Tahun
	else if($periode=='3') {

		$dataprojek=$this->M_laporan->pilih_projek($projek);
		foreach($dataprojek as $dp)
		?>
	<h4>CASHFLOW PROJEK PEMBANGUNAN PERUMAHAN</h4>
	<hr>
		<table class="table table-borderless text-uppercase">
			<thead>
				<tr>
					<td width="200">Nama Perumahan</td>
					<td>: <?php echo $dp->nama_projek ?></td>
				</tr>
				<tr>
					<td width="200">Lokasi</td>
					<td>: <?php echo $dp->lokasi_projek ?></td>
				</tr>
				<tr>
					<td width="200">periode</td>
					<td>: Per Tahun (Tahun : <?php echo $tahun ?>)</td>
				</tr>
			</thead>
		</table>
		<table class="table table-bordered text-uppercase">
			<thead>
				<tr class="table-success">
					<th colspan="6">penerimaan</th>
				</tr>
				<tr class="table-primary">
					<th>No</th>
					<th>kode</th>
					<th>Tanggal transaksi</th>
					<th>keterangan</th>
					<th>Jumlah (Rp.)</th>
					<th>Total</th>
				</tr>
				<?php
				$in=$this->M_masuk->cf_masuk_tahun_pro($projek,$tahun);
				$row=$in->num_rows();
				if($row=='0') {
					?>
					<tr>
						<td colspan="6">Data Pemasukan Tidak Ada</td>
					</tr>
					<?php
				}
				else {
					$no=1;
					foreach($in->result() as $dm) {
						?>
						<tr>
							<td><?php echo $no ?></td>
							<?php
							$jenismasuk=$this->M_masuk->jenis_masuk($dm->jenis_masuk);
							foreach($jenismasuk as $jm) 
								?>
								<td><?php echo $jm->jenis_masuk; ?></td>
								
								<td><?php echo $dm->tgl_masuk ?></td>
								<td>
									<?php
									$ket=$this->M_masuk->pilih_detail_masuk($jm->jenis_masuk,$dm->id_masuk);
									foreach($ket as $k) echo $k->keterangan;
									?>
								</td>
							<td align="right"><?php echo number_format($dm->total_masuk) ?></td>
							<td></td>
							
						</tr>
						
						<?php
						$no++;
					}	
					?>
					<tr class="table-danger">
						<td colspan="5" align="right"><b>Total Pemasukan (Rp.)</b></td>
						<td align="right"><b><?php echo number_format($totalmasuk);?></b></td>
					</tr>
					<?php					
				}
				?>
				<tr class="table-success">
					<th colspan="6">pengeluaran</th>
				</tr>
				<tr class="table-primary">
					<th>No</th>
					<th>kode</th>
					<th>Tanggal transaksi</th>
					<th>keterangan</th>
					<th>Jumlah (Rp.)</th>
					<th>Total</th>
				</tr>
				<?php
				$out=$this->M_masuk->cf_keluar_tahun_pro($projek,$tahun);
				$row=$out->num_rows();
				if($row=='0') {
					?>
					<tr>
						<td colspan="6">Data Pengeluaran tidak ditemukan</td>
					</tr>
					<?php
				}
				else {
					$no=1;
					foreach($out->result() as $do) {
						?>
						<tr>
							<td><?php echo $no ?></td>
							<?php
							$jeniskeluar=$this->M_masuk->jenis_keluar($do->jenis_keluar);
							foreach($jeniskeluar as $jk) 
								?>
								<td><?php echo $jk->jenis_pengeluaran; ?></td>
								
								<td><?php echo $do->tgl_keluar_projek ?></td>
								<td>
									<?php
									echo $do->keterangan;
									?>
								</td>
								<td align="right">
									<?php echo number_format($do->total_keluar); ?>
								</td>
							<td></td>							
						</tr>
						
						
						<?php
						$no++;
					}
					?>
					<tr class="table-danger">
						<td colspan="5" align="right"><b>Total Pengeluaran (Rp.)</b></td>
						<td align="right"><b><?php echo number_format($totalkeluar);?></b></td>
					</tr>
					<tr class="table-success">
						<td colspan="5" align="right"><b>Neraca</b></td>
						<td align="right"><b><h6><?php echo number_format($totalmasuk-$totalkeluar);?></h6></b></td>
					</tr>					
					<?php						
				}
				?>
			</thead>
		</table>
		<?php
	}
	//Tahun
	//Rentang Tanggal
	else if($periode=='4') {

		$dataprojek=$this->M_laporan->pilih_projek($projek);
		foreach($dataprojek as $dp)
		?>
	<h4>CASHFLOW PROJEK PEMBANGUNAN PERUMAHAN</h4>
	<hr>
		<table class="table table-borderless text-uppercase">
			<thead>
				<tr>
					<td width="200">Nama Perumahan</td>
					<td>: <?php echo $dp->nama_projek ?></td>
				</tr>
				<tr>
					<td width="200">Lokasi</td>
					<td>: <?php echo $dp->lokasi_projek ?></td>
				</tr>
				<tr>
					<td width="200">periode</td>
					<td>: Dari Tanggal <b><?php echo $tgl1 ?></b> Ke Tanggal <b><?php echo $tgl2 ?></b> </td>
				</tr>
			</thead>
		</table>
		<table class="table table-bordered text-uppercase">
			<thead>
				<tr class="table-success">
					<th colspan="6">penerimaan</th>
				</tr>
				<tr class="table-primary">
					<th>No</th>
					<th>kode</th>
					<th>Tanggal transaksi</th>
					<th>keterangan</th>
					<th>Jumlah (Rp.)</th>
					<th>Total</th>
				</tr>
				<?php
				$in=$this->M_masuk->cf_masuk_rentang($projek,$tgl1,$tgl2);
				$row=$in->num_rows();
				if($row=='0') {
					?>
					<tr>
						<td colspan="6">Data Pemasukan Tidak Ada</td>
					</tr>
					<?php
				}
				else {
					$no=1;
					foreach($in->result() as $dm) {
						?>
						<tr>
							<td><?php echo $no ?></td>
							<?php
							$jenismasuk=$this->M_masuk->jenis_masuk($dm->jenis_masuk);
							foreach($jenismasuk as $jm) 
								?>
								<td><?php echo $jm->jenis_masuk; ?></td>
								
								<td><?php echo $dm->tgl_masuk ?></td>
								<td>
									<?php
									$ket=$this->M_masuk->pilih_detail_masuk($jm->jenis_masuk,$dm->id_masuk);
									foreach($ket as $k) echo $k->keterangan;
									?>
								</td>
							<td align="right"><?php echo number_format($dm->total_masuk) ?></td>
							<td></td>
							
						</tr>
						
						<?php
						$no++;
					}	
					?>
					<tr class="table-danger">
						<td colspan="5" align="right"><b>Total Pemasukan (Rp.)</b></td>
						<td align="right"><b><?php echo number_format($totalmasuk);?></b></td>
					</tr>
					<?php					
				}
				?>
				<tr class="table-success">
					<th colspan="6">pengeluaran</th>
				</tr>
				<tr class="table-primary">
					<th>No</th>
					<th>kode</th>
					<th>Tanggal transaksi</th>
					<th>keterangan</th>
					<th>Jumlah (Rp.)</th>
					<th>Total</th>
				</tr>
				<?php
				$out=$this->M_masuk->cf_keluar_rentang_pro($projek,$tgl1,$tgl2);
				$row=$out->num_rows();
				if($row=='0') {
					?>
					<tr>
						<td colspan="6">Data Pengeluaran tidak ditemukan</td>
					</tr>
					<?php
				}
				else {
					$no=1;
					foreach($out->result() as $do) {
						?>
						<tr>
							<td><?php echo $no ?></td>
							<?php
							$jeniskeluar=$this->M_masuk->jenis_keluar($do->jenis_keluar);
							foreach($jeniskeluar as $jk) 
								?>
								<td><?php echo $jk->jenis_pengeluaran; ?></td>
								
								<td><?php echo $do->tgl_keluar_projek ?></td>
								<td>
									<?php
									echo $do->keterangan;
									?>
								</td>
								<td align="right">
									<?php echo number_format($do->total_keluar); ?>
								</td>
							<td></td>							
						</tr>
						
						
						<?php
						$no++;
					}
					?>
					<tr class="table-danger">
						<td colspan="5" align="right"><b>Total Pengeluaran (Rp.)</b></td>
						<td align="right"><b><?php echo number_format($totalkeluar);?></b></td>
					</tr>
					<tr class="table-success">
						<td colspan="5" align="right"><b>Neraca</b></td>
						<td align="right"><b><h6><?php echo number_format($totalmasuk-$totalkeluar);?></h6></b></td>
					</tr>					
					<?php						
				}
				?>
			</thead>
		</table>
		<?php
	}
}
?>



