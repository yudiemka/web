<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengguna extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('M_user');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}	

	function add() {
		$nama=$this->input->post('nama');
		$tahun=date('Y');
		$user=substr($nama,0,5);
		$password1=$this->input->post('password1');
		$password2=$this->input->post('password2');
		//cek nama user

		if ($nama>0) {
			if($password1==$password2) {
				$data=array (
					'nama'=>$nama,
					'username'=>$user.$tahun,
					'password'=>$password1
				);
				$this->M_user->add('user',$data);
				echo"<script>
				alert('Data Pengguna Sistem Telah Ditambahkan');
				window.location='/simlog/admin/data_pengguna';
				</script>";
			}
			else {
				echo"<script>
				alert('Password Tidak Sama, Silahkan Periksa Kembali !!!!');
				window.location='/simlog/admin/form_pengguna';
				</script>";
			}
		}
		else {
			echo"<script>
			alert('Field Nama Tidak Boleh Kosong, Silahkan Periksa Kembali');
			window.location='/simlog/admin/data_pengguna';
			</script>";
		}
	}

	function del($id) {
		$data=array('id_user'=>$id);
		$this->M_user->hapus($data,'user');
		
			echo"<script>
			alert('Data Pengguna Sistem Telah Dihapus');
			window.location='/simlog/admin/data_pengguna';
			</script>";
		
	}

	function auto_user(){
       if (isset($_GET['term'])) {
            $result = $this->m_user->cari_auto($_GET['term']);
            if (count($result) > 0) {
            foreach ($result as $row)
            	$arr_result[] = array(
            		'nrk'=>$row->kode,
            		'dt_obat'=>$row->kode."-".$row->merk."-".$row->dosis,
                    'merk' =>$row->merk,
                    'dosis' => $row->dosis,
                    'stok' => $row->stok,
                    'satuan'=>$row->satuan,
                    'kandungan'=>$row->kandungan           
                );
                echo json_encode($arr_result);
            }
        }
    }
}