<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Karyawan extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('m_menu');
  		$this->load->model('m_kelas');
  		$this->load->model('M_karyawan');
  		$this->load->model('m_user');
  		$this->load->model('M_gaji');
  		$this->load->model('M_projek');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}	

	function add() {
		$nama=$this->input->post('nama_karyawan');
		$jabatan=$this->input->post('jabatan');
		//cektabel karyawan
		$cek=$this->M_karyawan->cektabel();
		$c=$cek->num_rows()+1;
		$tahun=date('Y');

		$data=array(
			'nama_karyawan'=>$nama,
			'jabatan_karyawan'=>$jabatan,
			'no_register_karyawan'=>'0'.$c.$tahun,
		);
		
		$datalogin=array(
			'no_reg_karyawan'=>'0'.$c.$tahun,
			'username'=>'0'.$c.$tahun,
			'password'=>'0'.$c.$tahun,
			'status_user'=>'1'
		);
		$this->M_karyawan->add('karyawan',$data);
		$this->M_karyawan->add('user',$datalogin);
		echo"
		<script>
		alert('Data Karyawan Sudah Ditambahkan');
		window.location='/sbbk/admin/karyawan';
		</script>";
	}

	function edit() {
		$nama=$this->input->post('nama_karyawan');
		$jabatan=$this->input->post('jabatan');
		$nrk=$this->input->post('nrk');
		//cektabel karyawan		

		$data=array(
			'nama_karyawan'=>$nama,
			'jabatan_karyawan'=>$jabatan,
		);		
		
		$this->M_karyawan->edit($nrk,$data,'karyawan');
		echo"
		<script>
		alert('Data Karyawan Sudah Diperbaharui');
		window.location='/sbbk/admin/karyawan';
		</script>";
	}

	public function projek(){
	    // POST data
	    $postData = $this->input->post();
		// Get data
		$data = $this->M_gaji->projek($postData);
		echo json_encode($data);
	}

	function hapus_data() {
		$nrk=$_POST['id'];
		$query=$this->M_karyawan->hapus($nrk);		
	}

	function hapus_detail_gaji($nrk) {
		$idpro=$this->input->post('id');
		$query=$this->M_karyawan->hapus_detail_gaji($nrk,$idpro);		
	}


	function detail_karyawan($nrk) {
	    $data['nrk']=$nrk;    
	    $this->load->view('detail_karyawan',$data);
	}

	function form_gaji_karyawan($nrk) {
	    $data['nrk']=$nrk;    
	    $this->load->view('form_gaji',$data);
	}

	function detail_gaji_karyawan($nrk) {
	    $data['nrk']=$nrk;    
	    $this->load->view('detail_gaji',$data);
	}


	function auto_user(){
       if (isset($_GET['term'])) {
            $result = $this->m_user->cari_auto($_GET['term']);
            if (count($result) > 0) {
            foreach ($result as $row)
            	$arr_result[] = array(
            		'nrk'=>$row->kode,
            		'dt_obat'=>$row->kode."-".$row->merk."-".$row->dosis,
                    'merk' =>$row->merk,
                    'dosis' => $row->dosis,
                    'stok' => $row->stok,
                    'satuan'=>$row->satuan,
                    'kandungan'=>$row->kandungan           
                );
                echo json_encode($arr_result);
            }
        }
    }

    function detail_data_gaji($nrk) {
	    $data['nrk']=$nrk;
	    $data['totalgaji']=$this->M_gaji->gettotal($nrk);
	    $this->load->view('detail_gaji',$data);
	 }

	 function add_detail_gaji($nrk) {
	 	$idprojek=$this->input->post('idprojek');
	 	$nominal=$this->input->post('gaji');

	    $data=array(
	    	'nrk'=>$nrk,
	    	'id_projek'=>$idprojek,
	    	'nominal_gaji'=>$nominal,
	    );
	    $this->M_gaji->add('detail_gaji',$data);

	  }



}
