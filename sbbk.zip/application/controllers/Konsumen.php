<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Konsumen extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('M_Konsumen');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}

	public function cari_projek(){
	    // POST data
	    $postData = $this->input->post();
		// Get data
		$data = $this->M_modal->projek($postData);
		echo json_encode($data);
	}

	function add_modal() {
		$idprojek=$this->input->post('id_projek');
		$nominal=$this->input->post('nominal_cash');
		$tanggal=$this->input->post('tanggal_cash');
		$cash=preg_replace('/[^0-9]/','',$nominal);
		$data=array(
			'id_projek'=>$idprojek,
			'nominal_cash'=>$cash,
			'tanggal_cash'=>$tanggal,
		);
		$this->M_modal->add('modal',$data);
		echo"
		<script>
		alert('Modal pengerjaan Projek Sudah di Proses Sistem');
		window.location='/sbbk/admin/modal';
		</script>";
	}		

}