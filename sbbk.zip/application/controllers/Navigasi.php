<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Navigasi extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('M_menu');
     	$this->load->library('form_validation');
      	$this->load->database();
	}

	public function add() {
		$nama=$this->input->post('nama_nav');
		$anchor=$this->input->post('anchor_nav');
		$icon=$this->input->post('icon_nav');

		//cek nama menu
		if($nama) {
			$data=array(
				'nama'=>$nama,
				'anchor'=>$anchor,
				'icon'=>$icon
			);
			$this->M_menu->add('menu',$data);
			echo"
		    <script>
		    	alert('Data navigasi Sudah Disimpan');
		        window.location='/simlog/admin/data_navigasi';
		    </script>";
		}
		else {
			echo"
		    <script>
		    	alert('Nama navigasi Tidak Boleh Kosong');
		        window.location='/simlog/admin/form_navigasi';
		    </script>";
		} 
	}

	function del($id) {
		$data=array('id_menu'=>$id);
		$this->M_menu->hapus($data,'menu');
		
			echo"<script>
			alert('Data Navigasi Sidah Dihapus');
			window.location='/simlog/admin/data_navigasi';
			</script>";
		
	}

	function ubah($id) {
		$nama=$this->input->post('nama_nav');
		$anchor=$this->input->post('anchor_nav');
		$icon=$this->input->post('icon_nav');
		$where=array('id_menu'=>$id);

		//cek nama menu
		if($nama) {
			$data=array(
				'nama'=>$nama,
				'anchor'=>$anchor,
				'icon'=>$icon
			);
			$this->M_menu->update($where,$data,'menu');
			echo"
		    <script>
		    	alert('Data navigasi Sudah Diperbaharui');
		        window.location='/simlog/admin/data_navigasi';
		    </script>";
		}
		else {
			echo"
		    <script>
		    	alert('Gagal Perbaharui Data, Nama navigasi Tidak Boleh Kosong');
		        window.location='/simlog/admin/data_navigasi';
		    </script>";
		} 
	}

}