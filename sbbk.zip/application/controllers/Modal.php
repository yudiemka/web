<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modal extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('M_modal');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}

	public function projek(){
	    // POST data
	    $postData = $this->input->post();
		// Get data
		$data = $this->M_modal->projek($postData);
		echo json_encode($data);
	}

	function add_modal() {
		//cek tabel modal 
		$modal=$this->M_modal->cek_tabel();
		$row=$modal->num_rows()+1;
		//
		$idprojek=$this->input->post('id_projek');
		$nominal=$this->input->post('nominal_cash');
		$tanggal=$this->input->post('tanggal_cash');
		$cash=preg_replace('/[^0-9]/','',$nominal);
		$data=array(
			'id_modal'=>'jm01'.$row.$idprojek,
			'id_projek'=>$idprojek,
			'nominal_cash'=>$cash,
			'tanggal_cash'=>$tanggal,
		);
		$this->M_modal->add('modal',$data);
		$masuk=array(
			'id_masuk'=>'jm01'.$row.$idprojek,
			'jenis_masuk'=>'jm01',
			'tgl_masuk'=>$tanggal,
			'total_masuk'=>$cash,
			'id_projek'=>$idprojek,
		);
		$this->M_modal->add('pemasukan',$masuk);
		echo"
		<script>
		alert('Modal pengerjaan Projek Sudah di Proses Sistem');
		window.location='/sbbk/admin/modal';
		</script>";
	}		

}