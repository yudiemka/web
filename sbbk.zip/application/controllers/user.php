<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('m_menu');
  		$this->load->model('m_kelas');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}	

	function add() {
		$iduser=$this->input->post('iduser');
		$username=$this->input->post('username');
		$password1=$this->input->post('password1');
		$password2=$this->input->post('password2');
		//cek id_user
		$cekid=$this->m_user->cek_id($iduser);
		$rowid=$cekid->num_rows();
		if($rowid==0) {
			if($password1==$password2) {
				$data=array(
					'id_user'=>$iduser,
					'username'=>$username,
					'password'=>$password1
				);
				$this->m_user->add('pengguna',$data);
				echo"<script>
				alert('Data Pengguna Telah Ditambahkan ke Sistem');
				window.location='/eschool/admin/user';
				</script>";
			}
			else {
				echo"<script>
				alert('Field Password Tidak Sama');
				window.location='/eschool/admin/user';
				</script>";
			}
		}
		else {
			echo"<script>
			alert('Nama Karywan Sudah terdaftar di Pengguna Sistem, Silahkan Periksa Kembali');
			window.location='/eschool/admin/user';
			</script>";
		}
	}

	function del($id) {
		$data=array('id'=>$id);
		$this->m_kelas->hapus($data,'kelas');
		
			echo"<script>
			alert('Data Kelas Sidah Dihapus');
			window.location='/eschool/admin/data_kelas';
			</script>";
		
	}

	function auto_user(){
       if (isset($_GET['term'])) {
            $result = $this->m_user->cari_auto($_GET['term']);
            if (count($result) > 0) {
            foreach ($result as $row)
            	$arr_result[] = array(
            		'nrk'=>$row->kode,
            		'dt_obat'=>$row->kode."-".$row->merk."-".$row->dosis,
                    'merk' =>$row->merk,
                    'dosis' => $row->dosis,
                    'stok' => $row->stok,
                    'satuan'=>$row->satuan,
                    'kandungan'=>$row->kandungan           
                );
                echo json_encode($arr_result);
            }
        }
    }
}