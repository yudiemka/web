<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Submenu extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('M_menu');
  		$this->load->model('M_submenu');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}	

	function add() {
		$namasubmenu=$this->input->post('nama_submenu');
		$idmenu=$this->input->post('id_menu');
		$icon=$this->input->post('icon_submenu');
		$anchor=$this->input->post('anchor_submenu');
		$data=array(
			'nama_submenu'=>$namasubmenu,
			'id_menu'=>$idmenu,
			'icon_submenu'=>$icon,
			'anchor_submenu'=>$anchor,
		);
		$this->M_submenu->add('submenu',$data);
		echo"
		<script>
		alert('Data Navigasi Sistem Sudah Ditambahkan');
		window.location='/sbbk/admin/menu';
		</script>";
	}	

	function edit($id) {
		$namamenu=$this->input->post('namamenu');
		$anchor=$this->input->post('anchor');
		$icon=$this->input->post('icon');
		$data=array(
			'menu'=>$namamenu,
			'anchor'=>$anchor,
			'icon'=>$icon
		);
		$where=array('id'=>$id);
		$this->m_menu->edit($where,$data,'menu');
		echo"
		<script>
		alert('Data Navigasi Sistem Sudah Diperbaharui');
		window.location='/eschool/admin/menu';
		</script>";
	}

	function edit_misc() {
		$nama=$this->input->post('nama_perusahaan');
		$alamat=$this->input->post('alamat_perusahaan');
		$nohp=$this->input->post('no_hp');
		$email=$this->input->post('e_mail');

		$data=array(
			'nama_perusahaan'=>$nama,
			'alamat'=>$alamat,
			'no_hp'=>$nohp,
			'e_mail'=>$email
		);

		$this->m_menu->add('misc',$data);
		echo"
		<script>
		alert('Konfigurasi Sistem Sudah Diubah');
		window.location='/rental/admin/misc';
		</script>";
	}

	function add_hak_akses($nrk) {
		$hakakses=$this->input->post('hak_akses');
		$data=array(
			'hak_akses'=>implode(',',$hakakses),
			'nrk'=>$nrk
		);	
		$this->m_menu->add('hak_akses',$data);
		redirect('admin/user');
	}

	function update_hak_akses($nrk) {
		$hakakses=$this->input->post('hak_akses');
		$data=array('hak_akses'=>implode(',',$hakakses));	
		$where=array('nrk'=>$nrk);
		$this->m_menu->update_hak_akses($where,$data,'hak_akses');
		redirect('admin/user');
	}

	function data_menu(){
        $data=$this->M_menu->showAll();
        echo json_encode($data);
    }

    function del($id) {
		$data=array('id'=>$id);
		$this->M_menu->hapus($data,'menu');
		echo"<script>
		alert('Data Navigasi/Menu Sistem Sudah Dihapus');
		window.location='/rental/admin/data_nav';
		</script>";
		
	}

}