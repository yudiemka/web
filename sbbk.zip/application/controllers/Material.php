 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Material extends CI_Controller {

	function __construct(){
    parent::__construct();
  	$this->load->helper(array('form','url'));
    $this->load->model('M_material');
  	$this->load->model('M_hutang');
  	$this->load->model('M_user');
    $this->load->model('M_menu');
  	$this->load->library('pagination');
    $this->load->library('form_validation');
    $this->load->database();
	}

	function list_mat_tmp($cr) {
    $data['cr']=$cr;
    $data['sum']=$this->M_material->gettotal();
    $this->load->view('list_mat_smt',$data);
  }

  function periode() {
    $d=$this->input->post('value');
    $data['value']=$d;
    $this->load->view('combo',$data);
  }

  function tampil_laporan() {
      $p=$this->input->post('projek');
      $data['projek']=$p;
      $data['totalkeluar']=$this->M_laporan->total_keluar($p);
      $this->load->view('tampil_laporan',$p);
  }
  function add_item_tmp() {
    $row=$this->input->post('row');
    $tglfaktur=$this->input->post('tanggal_faktur');
    $nofaktur=$this->input->post('no_faktur');
    $suplier=$this->input->post('suplier');
    $jb=$this->input->post('jenis_bayar');
    $idprojek=$this->input->post('id_projek');
    $material=$this->input->post('nama_material');
    $qty=$this->input->post('qty');
    $satuan=$this->input->post('satuan');
    $harga=$this->input->post('harga');

    $data=array(
        'rowid'=>$row,
        'tgl_faktur'=>$tglfaktur,
        'no_faktur'=>$nofaktur,
        'suplier'=>$suplier,
        'jenis_bayar'=>$jb,
        'id_projek'=>$idprojek,
        'nama_material'=>$material,
        'qty'=>$qty,
        'satuan'=>$satuan,
        'harga'=>$harga,
        'subtotal'=>$harga*$qty,
    );
    $this->M_material->add('tbl_material_smt',$data);

  }

  function detail_faktur($id) {
    $data['id']=$id;    
    $data['sum']=$this->M_material->totalfaktur($id);
    $this->load->view('detail_faktur',$data);
  }

  function form_hutang_bayar($id) {
    $data['id']=$id;      
    $this->load->view('form_hutang',$data);
  }
  function akses($id) {
    $data['id']=$id;      
    $this->load->view('akses',$data);
  }

  function form_panel($id) {
    $data['id']=$id;      
    $this->load->view('form_panel',$data);
  }

  function beli($rowid) {
    $cektabel=$this->M_material->cek_tabel();
    $ct=$cektabel->num_rows()+1;
    $tglfaktur=$this->input->post('tanggal_faktur');
    $nofaktur=$this->input->post('no_faktur');
    $suplier=$this->input->post('suplier');
    $jb=$this->input->post('jenis_bayar');
    $idprojek=$this->input->post('id_projek');

    $total=$this->M_material->gettotal($rowid);
    $update=array (
      'status'=>'1',
    );
    $data=array(
      'tanggal_faktur'=>$tglfaktur,
      'no_faktur'=>$nofaktur,
      'suplier'=>$suplier,
      'jenis_bayar'=>$jb,
      'id_projek'=>$idprojek,
      'total'=>$total,
    );
    $keluar=array(
      'id_keluar_projek'=>$nofaktur,
      'jenis_keluar'=>'jb04',
      'tgl_keluar_projek'=>$tglfaktur,
      'total_keluar'=>$total,
      'id_projek'=>$idprojek
    );

    $cektabelhutang=$this->M_hutang->cek_tabel();
    $cth=$cektabelhutang->num_rows()+1;

    $hutang=array(
      'id_hutang'=>'jb07'.'0'.$cth,
      'no_faktur'=>$nofaktur,
      'nominal_hutang'=>$total,
      'id_projek'=>$idprojek,
      'tgl_faktur'=>$tglfaktur
    );

    $this->M_material->add('faktur',$data);
    if($jb=='2') {
      $this->M_material->add('hutang',$hutang);
    }
    elseif($jb=='1') {
      $this->M_material->add('keluar_projek',$keluar);
    }
    $this->M_material->beli('tbl_material_smt',$update,$rowid);
    echo"
      <script>
        alert('Data Pembelian Material Sduah Diproses');
        window.location='/sbbk/admin/material';
      </script>";

  }
  function sbbk_tmp() {
    $nosbbk=$this->input->post('no');
    $tglsbbk=$this->input->post('tgl');
    $kdbrg=$this->input->post('kdbrg');
    $qty=$this->input->post('qty');
    $instansi=$this->input->post('instansi');
    $sbt=$this->input->post('sbt');
    $this->load->view('tampil_sbbk_tmp',$data);
  }

  function hapus_tmp(){
      $kdbrg=$this->input->post('kdbrg');
      $data=$this->m_permintaan->hapus_tmp($kdbrg);
      $transaksi=$this->m_permintaan->hapus_trans_tmp($kdbrg);
      echo json_encode($data,$transaksi);
  }
  
  public function input_data(){
      $no_disposisi=$this->input->post('no_disposisi');
      $tgl_konfirmasi=date('Y-m-d');
      $data_konf=array(
        'no_disposisi'=>$no_disposisi,
        'tgl_konfirmasi'=>$tgl_konfirmasi
      );
      $result = array();
      foreach ($_POST['id_brg'] as $key => $val) {
         $result[] = array(     
            'no_disposisi' => $no_disposisi,       
            'jml_realisasi_minta' => $_POST['jml_realisasi'][$key],
            'id_brg' => $_POST['id_brg'][$key],
            'ket_realisasi' =>$_POST['ket_realisasi'][$key]      
         );      
      }      
      $this->db->insert_batch('realisai_minta',$result);
      $this->db->insert('konfirmasi_kasi',$data_konf);
      echo"
      <script>
        alert('Data Realisasi PErmintaan Barang Sduah Diproses');
        window.location='/upt/admin/disposisi';
      </script>";
   }
	
}