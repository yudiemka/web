<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dp extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('M_dp');
  		$this->load->model('M_masuk');
  		$this->load->model('M_konsumen');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}

	public function cari_projek(){
	    // POST data
	    $postData = $this->input->post();
		// Get data
		$data = $this->M_modal->projek($postData);
		echo json_encode($data);
	}

	function bayar() {

		//cek tbl konsumen & dp
		$konsumen=$this->M_konsumen->cek_tabel();
		$cek=$konsumen->num_rows()+1;
		$dope=$this->M_dp->cek_tabel();
		$dp=$dope->num_rows()+1;
		//end cek//		

		$idprojek=$this->input->post('id_projek');
		$projek=$this->input->post('projek');
		$nominal=$this->input->post('nominal_dp');
		$tanggal=$this->input->post('tgl_transaksi');

		$namakonsumen=$this->input->post('nama_konsumen');
		$alamat=$this->input->post('alamat_konsumen');
		$nohp=$this->input->post('nohp_konsumen');
		$blok=$this->input->post('blok_rumah');
		$norumah=$this->input->post('no_rumah');

		$tahun=substr($tanggal,0,4);

		//id konsumen//
		$idkonsumen=$idprojek.'0'.$cek.$tahun;

		$data=array(
			'id_dp'=>'jm03'.'0'.$dp,
			'id_projek'=>$idprojek,
			'nominal_dp'=>$nominal,
			'tanggal_dp'=>$tanggal,
			'id_konsumen'=>$idkonsumen,
		);
		$konsumen=array (
			'id_konsumen'=>$idkonsumen,
			'nama_konsumen'=>$namakonsumen,
			'alamat_konsumen'=>$alamat,
			'no_hp'=>$nohp,
			'id_projek'=>$idprojek,
			'blok_rumah'=>$blok,
			'no_rumah'=>$norumah,
			'id_dp'=>'jm03'.'0'.$dp,
		);
		$masuk=array(
			'id_masuk'=>'jm03'.'0'.$dp,
			'tgl_masuk'=>$tanggal,
			'jenis_masuk'=>'jm03',
			'total_masuk'=>$nominal,
		);
		$this->M_dp->add('dp',$data);
		$this->M_dp->add('pemasukan',$masuk);
		$this->M_konsumen->new('konsumen',$konsumen);
		echo"
		<script>
		alert('Data DP Rumah Sudah di Proses Sistem');
		window.location='/sbbk/admin/dp';
		</script>";
	}

	function hapus_data_dp() {
		$iddp=$this->input->post('id');
		$q1=$this->M_dp->hapus_data_dp($iddp);
		$q2=$this->M_masuk->hapus_data($iddp);
		$q3=$this->M_konsumen->hapus_data($iddp);		
	}		

}