 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hutang extends CI_Controller {

	function __construct(){
    parent::__construct();
  	$this->load->helper(array('form','url'));
    $this->load->model('M_material');
  	$this->load->model('M_hutang');
  	$this->load->library('pagination');
    $this->load->library('form_validation');
    $this->load->database();
	}

	function list_mat_tmp($cr) {
    $data['cr']=$cr;
    $data['sum']=$this->M_material->gettotal();
    $this->load->view('list_mat_smt',$data);
  }

  function form_hutang_bayar($id) {
    $data['id']=$id;      
    $this->load->view('form_hutang_bayar',$data);
  }

  function add() {
    //cek tabel keluar
    $cek=$this->M_hutang->cek_tabel_keluar();
    $rowcek=$cek->num_rows()+1;

    $cektabel=$this->M_hutang->cek_tabel_hutang_bayar();
    $thb=$cektabel->num_rows()+1;
    $nofaktur=$this->input->post('no_faktur');
    $tglbayar=$this->input->post('tanggal_bayar');
    $nominalbayar=$this->input->post('nominal_bayar');
    $nominalsisa=$this->input->post('nominal_sisa');
    $idprojek=$this->input->post('idprojek');

    $data=array(
      'id_hutang_bayar'=>'jb07'.$rowcek,
      'no_faktur'=>$nofaktur,
      'tgl_bayar'=>$tglbayar,
      'nominal_bayar'=>$nominalbayar,
      'nominal_sisa'=>$nominalsisa,
      'id_projek'=>$idprojek,
    );
    
    $keluar=array(
      'jenis_keluar'=>'jb07',
      'id_keluar_projek'=>'jb07'.$rowcek,
      'tgl_keluar_projek'=>$tglbayar,
      'id_projek'=>$idprojek,
      'total_keluar'=>$nominalbayar,
    );    

    $this->M_material->add('hutang_bayar',$data);
    $this->M_material->add('keluar_projek',$keluar);
    echo"
    <script>
      alert('Data Pengeluara Operasional Sudah Diproses');
      window.location='/sbbk/admin/hutang';
    </script>";

  }

  function sbbk_tmp() {
    $nosbbk=$this->input->post('no');
    $tglsbbk=$this->input->post('tgl');
    $kdbrg=$this->input->post('kdbrg');
    $qty=$this->input->post('qty');
    $instansi=$this->input->post('instansi');
    $sbt=$this->input->post('sbt');
    $this->load->view('tampil_sbbk_tmp',$data);
  }

  function hapus_tmp(){
      $kdbrg=$this->input->post('kdbrg');
      $data=$this->m_permintaan->hapus_tmp($kdbrg);
      $transaksi=$this->m_permintaan->hapus_trans_tmp($kdbrg);
      echo json_encode($data,$transaksi);
  }
  
  public function input_data(){
      $no_disposisi=$this->input->post('no_disposisi');
      $tgl_konfirmasi=date('Y-m-d');
      $data_konf=array(
        'no_disposisi'=>$no_disposisi,
        'tgl_konfirmasi'=>$tgl_konfirmasi
      );
      $result = array();
      foreach ($_POST['id_brg'] as $key => $val) {
         $result[] = array(     
            'no_disposisi' => $no_disposisi,       
            'jml_realisasi_minta' => $_POST['jml_realisasi'][$key],
            'id_brg' => $_POST['id_brg'][$key],
            'ket_realisasi' =>$_POST['ket_realisasi'][$key]      
         );      
      }      
      $this->db->insert_batch('realisai_minta',$result);
      $this->db->insert('konfirmasi_kasi',$data_konf);
      echo"
      <script>
        alert('Data Realisasi PErmintaan Barang Sduah Diproses');
        window.location='/upt/admin/disposisi';
      </script>";
   }
	
}