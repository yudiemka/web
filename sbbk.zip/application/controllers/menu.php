<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('M_menu');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}	

	function form_hak_akses($nrk) {
	    $data['nrk']=$nrk;      
	    $this->load->view('form_hak_akses',$data);
	  }

	function add() {
		$namamenu=$this->input->post('nama_menu');
		$jenismenu=$this->input->post('jenis_menu');
		$icon=$this->input->post('icon_menu');
		$data=array(
			'nama_menu'=>$namamenu,
			'jenis_menu'=>$jenismenu,
			'icon_menu'=>$icon
		);
		$this->M_menu->add('menu',$data);
		echo"
		<script>
		alert('Data Navigasi Sistem Sudah Ditambahkan');
		window.location='/sbbk/admin/menu';
		</script>";
	}	

	function edit($id) {
		$namamenu=$this->input->post('namamenu');
		$anchor=$this->input->post('anchor');
		$icon=$this->input->post('icon');
		$data=array(
			'menu'=>$namamenu,
			'anchor'=>$anchor,
			'icon'=>$icon
		);
		$where=array('id'=>$id);
		$this->m_menu->edit($where,$data,'menu');
		echo"
		<script>
		alert('Data Navigasi Sistem Sudah Diperbaharui');
		window.location='/eschool/admin/menu';
		</script>";
	}

	function edit_misc() {
		$nama=$this->input->post('nama_perusahaan');
		$alamat=$this->input->post('alamat_perusahaan');
		$nohp=$this->input->post('no_hp');
		$email=$this->input->post('e_mail');

		$data=array(
			'nama_perusahaan'=>$nama,
			'alamat'=>$alamat,
			'no_hp'=>$nohp,
			'e_mail'=>$email
		);

		$this->m_menu->add('misc',$data);
		echo"
		<script>
		alert('Konfigurasi Sistem Sudah Diubah');
		window.location='/rental/admin/misc';
		</script>";
	}

	function add_modul() {
		$nrk=$this->input->post('nrk');
		$modul=$this->input->post('modul');
		$data=array(
			'nrk'=>$nrk,
			'modul'=>implode(',',$modul),
		);	
		$this->M_menu->add('hak_akses',$data);
		redirect('admin/pengguna');
	}

	function addmodul() {
		$modul=$this->input->post('modul');
		$data=array(
			'modul'=>implode(',',$modul),
		);	
		$this->M_menu->add('hak_akses',$data);
		redirect('admin/pengguna');
	}

	function update_hak_akses($nrk) {
		$hakakses=$this->input->post('hak_akses');
		$data=array('hak_akses'=>implode(',',$hakakses));	
		$where=array('nrk'=>$nrk);
		$this->m_menu->update_hak_akses($where,$data,'hak_akses');
		redirect('admin/user');
	}

	function data_menu(){
        $data=$this->M_menu->showAll();
        echo json_encode($data);
    }

    function del($id) {
		$data=array('id'=>$id);
		$this->M_menu->hapus($data,'menu');
		echo"<script>
		alert('Data Navigasi/Menu Sistem Sudah Dihapus');
		window.location='/rental/admin/data_nav';
		</script>";
		
	}


	 public function save_data() {
        $menu = $this->input->post('menu');
        $submenu = $this->input->post('submenu');
        $nrk=$this->input->post('nrk');
        $dm=array_unique($menu);
        $datamenu=implode(",",$dm);
        
       

       $dataakses=array(
       	'nrk'=>$nrk,
       	'menu'=>$datamenu,
       	'modul'=>implode(",",$submenu),
       );

        // Simpan ke database
        $this->M_menu->add('hak_akses',$dataakses);

        
    }

    public function save_data_panel() {
		$submenu = $_POST['submenu'];
		

		// Lakukan sesuatu dengan data yang diterima
	  	foreach ($submenu as $sm) {
		    $value = $sm['value'];
		    // Misalnya, simpan ke database
		    // ...
		    $data=array(
		    	'modul'=>$value,
		    );
		    $this->M_menu->add('panel_akses',$data);
		  }

		  // Berikan respons ke JavaScript (opsional)
		  echo "Proses selesai.";
    }
}

