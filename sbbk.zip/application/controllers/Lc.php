<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lc extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('M_upah');
  		$this->load->model('M_projek');
  		$this->load->model('M_pengeluaran');
  		$this->load->model('M_lc');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}	

	function add() {
		$idprojek=$this->input->post('id_projek');
		$tgl=$this->input->post('tanggal_lc');
		$nominal=$this->input->post('nominal_lc');
		$keterangan=$this->input->post('keterangan_lc');
		//cek tabel //
		$ceklc=$this->M_lc->cek_tabel_lc();
		$c=$ceklc->num_rows()+1;
		$data=array(
			'tanggal_lc'=>$tgl,
			'id_lc'=>$idprojek.'00'.$c,
			'id_projek'=>$idprojek,
			'nominal_lc'=>$nominal,
			'keterangan_lc'=>$keterangan,
		);
		$this->M_lc->add('lc',$data);
		$keluar=array(
			'id_keluar_projek'=>$idprojek.'00'.$c,
			'tgl_keluar_projek'=>$tgl,
			'id_projek'=>$idprojek,
			'total_keluar'=>$nominal,
			'jenis_keluar'=>'jb01',
		);
		$this->M_lc->add('keluar_projek',$keluar);
		echo"
		<script>
		alert('Data Pembayaran LC & Perencanaan Sudah Diproses');
		window.location='/sbbk/admin/lc';
		</script>";
	}	

	function data_minta_tmp() {
	   
	    $this->load->view('list_mat_smt');
	}

	function edit($id) {
		$namamenu=$this->input->post('namamenu');
		$anchor=$this->input->post('anchor');
		$icon=$this->input->post('icon');
		$data=array(
			'menu'=>$namamenu,
			'anchor'=>$anchor,
			'icon'=>$icon
		);
		$where=array('id'=>$id);
		$this->m_menu->edit($where,$data,'menu');
		echo"
		<script>
		alert('Data Navigasi Sistem Sudah Diperbaharui');
		window.location='/eschool/admin/menu';
		</script>";
	}

	function edit_misc() {
		$nama=$this->input->post('nama_perusahaan');
		$alamat=$this->input->post('alamat_perusahaan');
		$nohp=$this->input->post('no_hp');
		$email=$this->input->post('e_mail');

		$data=array(
			'nama_perusahaan'=>$nama,
			'alamat'=>$alamat,
			'no_hp'=>$nohp,
			'e_mail'=>$email
		);

		$this->m_menu->add('misc',$data);
		echo"
		<script>
		alert('Konfigurasi Sistem Sudah Diubah');
		window.location='/rental/admin/misc';
		</script>";
	}

	function add_hak_akses($nrk) {
		$hakakses=$this->input->post('hak_akses');
		$data=array(
			'hak_akses'=>implode(',',$hakakses),
			'nrk'=>$nrk
		);	
		$this->m_menu->add('hak_akses',$data);
		redirect('admin/user');
	}

	function update_hak_akses($nrk) {
		$hakakses=$this->input->post('hak_akses');
		$data=array('hak_akses'=>implode(',',$hakakses));	
		$where=array('nrk'=>$nrk);
		$this->m_menu->update_hak_akses($where,$data,'hak_akses');
		redirect('admin/user');
	}

	function data_menu(){
        $data=$this->M_menu->showAll();
        echo json_encode($data);
    }

    function del($id) {
		$data=array('id'=>$id);
		$this->M_menu->hapus($data,'menu');
		echo"<script>
		alert('Data Navigasi/Menu Sistem Sudah Dihapus');
		window.location='/rental/admin/data_nav';
		</script>";
		
	}

}