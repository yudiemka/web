<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Projek extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('M_dp');
  		$this->load->model('M_projek');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}

	public function cari_projek(){
	    // POST data
	    $postData = $this->input->post();
		// Get data
		$data = $this->M_modal->projek($postData);
		echo json_encode($data);
	}

	function add() {

		//cek tbl konsumen
		$cek_pro=$this->M_projek->cek_tabel();
		$cpro=$cek_pro->num_rows()+1;
		//end cek//	
		$namaprojek=$this->input->post('nama_projek');
		$kode=substr($namaprojek,0,5);
		$idprojek=$kode.'00'.$cpro;
		$lokasi=$this->input->post('lokasi_projek');
		$jumlah=$this->input->post('jumlah_unit');

		$data= array(
			'id_projek'=>$idprojek,
			'nama_projek'=>$namaprojek,
			'lokasi_projek'=>$lokasi,
			'jumlah_unit'=>$jumlah,
		);
		$this->M_projek->add('projek',$data);
		echo "
		<script>
		alert('Modal pengerjaan Projek Sudah di Proses Sistem');
		window.location='/sbbk/admin/projek';
		</script>";

	}

	function bayar() {

		//cek tbl konsumen
		$konsumen=$this->M_konsumen->cek_tabel();
		$cek=$konsumen->num_rows()+1;
		//end cek//		

		$idprojek=$this->input->post('id_projek');
		$projek=$this->input->post('projek');
		$nominal=$this->input->post('nominal_dp');
		$tanggal=$this->input->post('tgl_transaksi');
		$cash=preg_replace('/[^0-9]/','',$nominal);

		$namakonsumen=$this->input->post('nama_konsumen');
		$alamat=$this->input->post('alamat_konsumen');
		$nohp=$this->input->post('nohp_konsumen');
		$blok=$this->input->post('blok_rumah');
		$norumah=$this->input->post('no_rumah');

		$tahun=substr($tanggal,0,4);

		//id konsumen//
		$idkonsumen=$idprojek.'0'.$cek.$tahun;

		$data=array(
			'id_projek'=>$idprojek,
			'nominal_dp'=>$cash,
			'tanggal_dp'=>$tanggal,
			'id_konsumen'=>$idkonsumen,
		);
		$konsumen=array (
			'id_konsumen'=>$idkonsumen,
			'nama_konsumen'=>$namakonsumen,
			'alamat_konsumen'=>$alamat,
			'no_hp'=>$nohp,
			'id_projek'=>$idprojek,
			'blok_rumah'=>$blok,
			'no_rumah'=>$norumah,
		);
		$this->M_dp->add('dp',$data);
		$this->M_konsumen->new('konsumen',$konsumen);
		echo"
		<script>
		alert('Modal pengerjaan Projek Sudah di Proses Sistem');
		window.location='/sbbk/admin/dp';
		</script>";
	}	

	function hapus_data() {
		$idpro=$this->input->post('id');
		$query=$this->M_projek->hapus_data($idpro);		
	}	

	function ubah_status() {

		$idpro=$this->input->post('id');
		$status=$this->input->post('status');
		if($status=='0') {$sp='1';}else {$sp='0';}
		$data=array('status_projek'=>$sp);
		$where=array('id_projek'=>$idpro);
		$this->M_projek->ubah_status($where,$data,'projek');				
	}	


}