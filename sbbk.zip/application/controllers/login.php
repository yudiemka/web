<?php
class Login extends CI_Controller{
 
	function __construct(){
		parent::__construct();		
		$this->load->model('mlogin');
 
	}
 
	function index(){
		$this->load->view('login');
	}
 
	function aksi_login(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$where = array(
			'username' => $username,
			'password' =>$password
			);
		$cek = $this->mlogin->cek_login("user",$where)->num_rows();
		if($cek > 0){
			$cek_user = $this->mlogin->data_user($username);
			foreach($cek_user as $data)
 
			$data_session = array(
				'status_user'=>$data->status_user,
				'nrk'=>$data->no_reg_karyawan,
				);
 
			$this->session->set_userdata($data_session);
 			
 			redirect(base_url("admin/index")); 			
 
		}
		else {
			redirect(base_url('/'));
		}
	}
 
	function logout(){
		$this->session->sess_destroy();
		redirect(base_url('/'));
	}

}