<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upah extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('M_upah');
  		$this->load->model('M_projek');
  		$this->load->model('M_pengeluaran');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}	

	function add() {
		$cekupah=$this->M_upah->cek_tabel();
		$cu=$cekupah->num_rows()+1;
		$idprojek=$this->input->post('id_projek');
		$tglupah=$this->input->post('tanggal_upah');
		$penerimaupah=$this->input->post('penerima_upah');
		$nominalupah=$this->input->post('nominal_upah');
		$potongan=$this->input->post('potongan_upah');
		$nominalupahbayar=$this->input->post('nominal_upah_bayar');
		$keteranganupah=$this->input->post('keterangan_upah');
		$data=array(
			'id_upah'=>$idprojek.$cu,
			'id_projek'=>$idprojek,
			'tanggal_upah'=>$tglupah,
			'penerima_upah'=>$penerimaupah,
			'nominal_upah'=>$nominalupah,
			'potongan_upah'=>$potongan,
			'nominal_upah_bayar'=>$nominalupahbayar,
			'keterangan_upah'=>$keteranganupah,
		);
		$this->M_upah->add('upah',$data);
		$pengeluaran=array(
			'id_keluar_projek'=>$idprojek.$cu,
			'jenis_keluar'=>'jb03',
			'tgl_keluar_projek'=>$tglupah,
			'id_projek'=>$idprojek,
			'total_keluar'=>$nominalupahbayar,
		);
		$this->M_pengeluaran->add('keluar_projek',$pengeluaran);
		echo"
		<script>
		alert('Data Pembyaran Upah Tukang sudah Diproses');
		window.location='/sbbk/admin/upah';
		</script>";
	}	

	function edit($id) {
		$namamenu=$this->input->post('namamenu');
		$anchor=$this->input->post('anchor');
		$icon=$this->input->post('icon');
		$data=array(
			'menu'=>$namamenu,
			'anchor'=>$anchor,
			'icon'=>$icon
		);
		$where=array('id'=>$id);
		$this->m_menu->edit($where,$data,'menu');
		echo"
		<script>
		alert('Data Navigasi Sistem Sudah Diperbaharui');
		window.location='/eschool/admin/menu';
		</script>";
	}

	function edit_misc() {
		$nama=$this->input->post('nama_perusahaan');
		$alamat=$this->input->post('alamat_perusahaan');
		$nohp=$this->input->post('no_hp');
		$email=$this->input->post('e_mail');

		$data=array(
			'nama_perusahaan'=>$nama,
			'alamat'=>$alamat,
			'no_hp'=>$nohp,
			'e_mail'=>$email
		);

		$this->m_menu->add('misc',$data);
		echo"
		<script>
		alert('Konfigurasi Sistem Sudah Diubah');
		window.location='/rental/admin/misc';
		</script>";
	}

	function add_hak_akses($nrk) {
		$hakakses=$this->input->post('hak_akses');
		$data=array(
			'hak_akses'=>implode(',',$hakakses),
			'nrk'=>$nrk
		);	
		$this->m_menu->add('hak_akses',$data);
		redirect('admin/user');
	}

	function update_hak_akses($nrk) {
		$hakakses=$this->input->post('hak_akses');
		$data=array('hak_akses'=>implode(',',$hakakses));	
		$where=array('nrk'=>$nrk);
		$this->m_menu->update_hak_akses($where,$data,'hak_akses');
		redirect('admin/user');
	}

	function data_menu(){
        $data=$this->M_menu->showAll();
        echo json_encode($data);
    }

    function del($id) {
		$data=array('id'=>$id);
		$this->M_menu->hapus($data,'menu');
		echo"<script>
		alert('Data Navigasi/Menu Sistem Sudah Dihapus');
		window.location='/rental/admin/data_nav';
		</script>";
		
	}

}