<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengeluaran extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('M_pengeluaran');
  		$this->load->model('M_master');
  		$this->load->model('M_submenu');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}	

	function add() {
		$namamenu=$this->input->post('nama_menu');
		$jenismenu=$this->input->post('jenis_menu');
		$icon=$this->input->post('icon_menu');
		$data=array(
			'nama_menu'=>$namamenu,
			'jenis_menu'=>$jenismenu,
			'icon_menu'=>$icon
		);
		$this->M_menu->add('menu',$data);
		echo"
		<script>
		alert('Data Navigasi Sistem Sudah Ditambahkan');
		window.location='/sbbk/admin/menu';
		</script>";
	}	

	function addjp() {
		$cektabeljp=$this->M_pengeluaran->cektabeljp();
		$cp=$cektabeljp->num_rows()+1;
		$nama=$this->input->post('nama_pengeluaran');
		$data=array(
			'jenis_pengeluaran'=>$nama,
			'kode'=>'jb'.'0'.$cp,
		);
		$this->M_pengeluaran->add('jenis_pengeluaran',$data);
		echo"
		<script>
		alert('Data Sudah Ditambahkan');
		window.location='/sbbk/admin/jenis_pengeluaran';
		</script>";
	}	


	function edit($id) {
		$namamenu=$this->input->post('namamenu');
		$anchor=$this->input->post('anchor');
		$icon=$this->input->post('icon');
		$data=array(
			'menu'=>$namamenu,
			'anchor'=>$anchor,
			'icon'=>$icon
		);
		$where=array('id'=>$id);
		$this->m_menu->edit($where,$data,'menu');
		echo"
		<script>
		alert('Data Navigasi Sistem Sudah Diperbaharui');
		window.location='/eschool/admin/menu';
		</script>";
	}

	function edit_misc() {
		$nama=$this->input->post('nama_perusahaan');
		$alamat=$this->input->post('alamat_perusahaan');
		$nohp=$this->input->post('no_hp');
		$email=$this->input->post('e_mail');

		$data=array(
			'nama_perusahaan'=>$nama,
			'alamat'=>$alamat,
			'no_hp'=>$nohp,
			'e_mail'=>$email
		);

		$this->m_menu->add('misc',$data);
		echo"
		<script>
		alert('Konfigurasi Sistem Sudah Diubah');
		window.location='/rental/admin/misc';
		</script>";
	}

	function add_hak_akses($nrk) {
		$hakakses=$this->input->post('hak_akses');
		$data=array(
			'hak_akses'=>implode(',',$hakakses),
			'nrk'=>$nrk
		);	
		$this->m_menu->add('hak_akses',$data);
		redirect('admin/user');
	}

	function update_hak_akses($nrk) {
		$hakakses=$this->input->post('hak_akses');
		$data=array('hak_akses'=>implode(',',$hakakses));	
		$where=array('nrk'=>$nrk);
		$this->m_menu->update_hak_akses($where,$data,'hak_akses');
		redirect('admin/user');
	}

	function data_menu(){
        $data=$this->M_menu->showAll();
        echo json_encode($data);
    }

    function del($id) {
		$data=array('id'=>$id);
		$this->M_menu->hapus($data,'menu');
		echo"<script>
		alert('Data Navigasi/Menu Sistem Sudah Dihapus');
		window.location='/rental/admin/data_nav';
		</script>";
		
	}

	function hapus_data_jp() {
		$kode=$this->input->post('id');
		$query=$this->M_submenu->hapus_data_jp($kode);		
	}	


}