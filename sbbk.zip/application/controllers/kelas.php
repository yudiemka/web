<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kelas extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('m_menu');
  		$this->load->model('m_kelas');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}	

	function add() {
		$kelas=$this->input->post('kelas');
		$nokelas=$this->input->post('nokelas');
		$jurusan=$this->input->post('jurusan');
		$ta=$this->input->post('tahunajar');
		$jmlpesdik=$this->input->post('jmlpesdik');
		$data=array(
			'kelas'=>$kelas.".".$nokelas,
			'jurusan'=>$jurusan,
			'id_ta'=>$ta,
			'jml_pesdik'=>$jmlpesdik
		);
		$this->m_kelas->add('kelas',$data);
		redirect('admin/data_kelas');
	}

	function del($id) {
		$data=array('id'=>$id);
		$this->m_kelas->hapus($data,'kelas');
		
			echo"<script>
			alert('Data Kelas Sidah Dihapus');
			window.location='/eschool/admin/data_kelas';
			</script>";
		
	}

	public function tampil_pesdik($idkelas) {
		$data['kelas']=$this->m_kelas->list_pesdik($idkelas);
		$this->load->view('data_pesdik_kelas',$data);
	}

	public function addwali($idkelas) {
		$walikelas=$this->input->post('noreg_guru');
		$data=array(
			'wali_kelas'=>$walikelas,
			'id_kelas'=>$idkelas,
		);
		//cek data kelas
		$cek=$this->m_kelas->cek_kelas($idkelas);
		$row=$cek->num_rows();
		if($row>=1) {
			echo"<script>
			alert('Data Wali Kelas Sudah Ada');
			window.location='/eschool/admin/data_kelas';
			</script>";
		}
		else{
			$this->m_kelas->add('wali_kelas',$data);
			echo"<script>
			alert('Data Wali Kelas Sudah Ditambahkan');
			window.location='/eschool/admin/data_kelas';
			</script>";
		}
	}

	public function auto_nis(){
	    // POST data
	    $postData = $this->input->post();
		    // Get data
		    $data = $this->m_kelas->getUsers($postData);
		    echo json_encode($data);
	}

	function add_pesdik_kelas($idkelas) {
		$nis=$this->input->post('nis');
		$data=array(
			'nis'=>$nis,
			'id_kelas'=>$idkelas
		);
		$ceknis=$this->m_kelas->cek_nis($nis);
		$rowcek=$ceknis->num_rows();
		if($rowcek==0) {
			$this->m_kelas->add('kelas_pesdik',$data);
		}
		else {

		}
	}

	function hapus_pesdik(){
       $id=$this->input->post('id');
       $this->m_kelas->hapuspesdik($id);
    }
		
}