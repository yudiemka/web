 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct(){
		parent::__construct();
		$this->load->helper(array('form','url'));
		$this->load->model('M_stok');
		$this->load->model('M_kpr');
		$this->load->model('M_dp');
		$this->load->model('M_projek');
		$this->load->model('M_pengeluaran');
		$this->load->model('M_masuk');
		$this->load->model('m_admin');
		$this->load->model('M_transaksi');
		$this->load->model('M_modal');
		$this->load->model('M_material');
		$this->load->model('M_lc');
		$this->load->model('M_gaji');
		$this->load->model('M_operasional');
		$this->load->model('M_pendapatan');
		$this->load->model('M_upah');
		$this->load->model('M_bayar');
		$this->load->model('M_izin');
		$this->load->model('M_konsumen');
		$this->load->model('M_menu');
		$this->load->model('M_submenu');
		$this->load->model('M_hutang');
		$this->load->model('M_master');
		$this->load->model('M_masuk');
		$this->load->model('M_pengeluaran');
		$this->load->model('M_laporan');
		$this->load->model('M_karyawan');
		$this->load->model('M_user');
		$this->load->library('pagination');
        $this->load->library('form_validation');
	}

	public function login()
	{
		$this->load->view('login');
	}

	public function index()
	{
		$this->load->view('panel');
		$this->load->view('dash');
	}

	public function cetak() {	
        
     $this->load->library('pdfgenerator');
        
        $this->load->view('tes_pdf', $data);

	}

	public function tescb()
	{
		$this->load->view('panel');
		$this->load->view('tes_cb');
	}


	public function pendapatan()
	{
		$this->load->view('home');
		$this->load->view('pendapatan');
	}

	function cetak_laporan()
	{
		$this->load->view('lap');
	}

	public function upah()
	{
		$this->load->view('panel');
		$this->load->view('upah');
	}

	public function keluarops()
	{
		$this->load->view('panel');
		$this->load->view('pengeluaranops');
	}

	public function karyawan()
	{
		$this->load->view('panel');
		$this->load->view('karyawan');
	}

	public function material()
	{
		$this->load->view('panel');
		$this->load->view('material');
	}

	public function modal()
	{
		$this->load->view('panel');
		$this->load->view('modal');
	}

	public function projek()
	{
		$this->load->view('panel');
		$this->load->view('projek');
	}

	public function kpr()
	{
		$this->load->view('panel');
		$this->load->view('kpr');
	}

	public function pembayaran()
	{
		$this->load->view('panel');
		$this->load->view('bayar');
	}

	public function dp()
	{
		$this->load->view('panel');
		$this->load->view('dp');
	}

	public function lc()
	{
		$this->load->view('panel');
		$this->load->view('lc');
	}

	public function gaji()
	{
		$this->load->view('panel');
		$this->load->view('gaji');
	}

	public function operasional()
	{
		$this->load->view('panel');
		$this->load->view('operasional');
	}

	public function izin()
	{
		$this->load->view('panel');
		$this->load->view('izin');
	}

	public function hutang()
	{
		
		$this->load->view('panel');
		$this->load->view('hutang');
	}

	public function pengeluaran()
	{
		$this->load->view('panel');
		$this->load->view('pengeluaran');
	}

	public function lap_pemasukan()
	{
		$this->load->view('panel');
		$this->load->view('pemasukan');
	}

	public function jenis_pengeluaran()
	{
		$this->load->view('panel');
		$this->load->view('jenis_pengeluaran');
	}

	public function lap_pengeluaran()
	{
		$this->load->view('panel');
		$this->load->view('lap_pengeluaran');
	}

	public function lap_hutang()
	{
		$this->load->view('panel');
		$this->load->view('lap_hutang');
	}

	public function cf_projek()
	{
		$this->load->view('panel');
		$this->load->view('cf_projek');
	}

	public function cf_perusahaan()
	{
		$this->load->view('panel');
		$this->load->view('cf_perusahaan');
	}

	public function sbbk()
	{
		$this->load->view('panel');
		$this->load->view('form_sbbk');
	}



	public function pengguna()
	{
		$this->load->view('panel');
		$this->load->view('pengguna');
	}

	public function menu()
	{
		$this->load->view('panel');
		$this->load->view('menu');
	}

	public function data_unit()
	{
		$this->load->view('home');
		$this->load->view('data_unit');
	}

	public function form_unit() {
		$this->load->view('home');
		$this->load->view('form_unit');
	}

	public function misc()
	{
		$this->load->view('home');
		$this->load->view('misc');
	}

	public function edit_misc()
	{
		$this->load->view('home');
		$this->load->view('edit_misc');
	}

	public function data_nav() {
		$this->load->view('home');
		$this->load->view('data_navigasi');
	}

	public function form_navigasi() {
		$this->load->view('home');
		$this->load->view('form_navigasi');
	}

	public function data_kendaraan() {
		$this->load->view('home');
		$this->load->view('data_kendaraan');
	}

	

	public function data_kontrak() {
		$this->load->view('home');
		$this->load->view('data_kontrak');
	}

	public function form_kontrak() {
		$this->load->view('home');
		$this->load->view('form_kontrak');
	}

	public function form_ubah_navigasi($id) {
		$data['header']="Halaman Ubah Data Navigasi SIMLOG Seksi Logistik UPT IFLK Riau";
		$data['id']=$id;
		$this->load->view('dash');
		$this->load->view('form_ubah_navigasi',$data);
	}

	public function form_pelanggan() {
		$this->load->view('home');
		$this->load->view('form_pelanggan');
	}

	public function data_pelanggan() {
		$this->load->view('home');
		$this->load->view('data_pelanggan');
	}

	public function surat_kontrak() {
		$this->load->view('surat_kontrak');
	}

	public function data_stok() {
		$data['header']="Data Stok Logistik UPT IFLK Provinsi Riau";
		$this->load->view('panel');
		$this->load->view('data_stok',$data);
	}

	public function barang_masuk() {
		$data['header']="Data Barang Masuk Seksi Logistik UPT IFLK Provinsi Riau";
		$this->load->view('dash');
		$this->load->view('barang_masuk',$data);
	}

	public function form_barang_masuk() {
		$data['header']="Halaman Entry Data Barang Masuk";
		$this->load->view('dash');
		$this->load->view('form_barang_masuk',$data);
	}

	public function barang_keluar() {
		$data['header']="Data Barang Keluar Seksi Logistik UPT IFLK Provinsi Riau";
		$this->load->view('panel');
		$this->load->view('barang_keluar',$data);
	}

	public function data_sbbk() {
		$data['header']="Data S B B K Seksi Logistik UPT IFLK Provinsi Riau";
		$this->load->view('panel');
		$this->load->view('data_sbbk',$data);
	}

	public function data_staff() {
		$data['header']="Data Staff Seksi Logistik UPT IFLK Provinsi Riau";
		$this->load->view('dash');
		$this->load->view('data_staff',$data);
	}

	public function form_staff() {
		$data['header']="Halaman Tambah Data Staff Seksi Logistik UPT IFLK Riau";
		$this->load->view('dash');
		$this->load->view('form_staff',$data);
	}

	public function form_ubah_staff($id) {
		$data['header']="Halaman Ubah Data Staff Seksi Logistik UPT IFLK Riau";
		$data['id']=$id;
		$this->load->view('dash');
		$this->load->view('form_ubah_staff',$data);
	}

	public function data_pengguna() {
		$data['header']="Data Pengguna Sistem SIMLOG Seksi Logistik UPT IFLK Riau";
		$this->load->view('dash');
		$this->load->view('data_pengguna',$data);
	}

	public function form_pengguna() {
		$data['header']="Halaman Tambah Data Pengguna SIMLOG V.2.0 Seksi Logistik UPT IFLK Riau";
		$this->load->view('dash');
		$this->load->view('form_pengguna',$data);
	}

	

	public function hak_akses($id) {
		$data['header']="Halaman Konfigurasi Hak Akses Pengguna SIMLOG V.2.0";
		$data['id']=$id;
		$this->load->view('dash');
		$this->load->view('hak_akses',$data);
	}

	public function kartu_stok($id) {
		$data['header']="Kartu Stok Bahan Medis Habis Pakai (B M H P)";
		$data['id']=$id;
		$this->load->view('dash');
		$this->load->view('kartu_stok',$data);
	}



	

}