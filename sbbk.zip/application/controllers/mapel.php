<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mapel extends CI_Controller {

	function __construct(){
  		parent::__construct();
  		$this->load->helper(array('form','url'));
  		$this->load->model('m_menu');
  		$this->load->model('m_kelas');
  		$this->load->model('m_mapel');
  		$this->load->library('pagination');
     	$this->load->library('form_validation');
      	$this->load->database();
	}	

	function add() {
		$mapel=$this->input->post('mapel');
		$tahunajar=$this->input->post('tahunajar');
		$kurikulum=$this->input->post('kurikulum');
		$tglupdate=date('Y-m-d');
		$data=array(
			'mapel'=>$mapel,
			'kurikulum'=>$kurikulum,
			'id_ta'=>$tahunajar,
			'tgl_update'=>$tglupdate,
			'status_aktif'=>"1",
		);
		$this->m_mapel->add('mapel',$data);
		redirect('admin/mata_pelajaran');
	}

	function del($id) {
		$data=array('id'=>$id);
		$this->m_kelas->hapus($data,'kelas');
		
			echo"<script>
			alert('Data Kelas Sidah Dihapus');
			window.location='/eschool/admin/data_kelas';
			</script>";
		
	}

	public function faw($id) {
		$data['header']="Form Tambah Data Wali Kelas";
		$this->load->view('home');
		$this->load->view('addwalikelas',$data);
	}

		
}