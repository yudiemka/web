 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kontrak extends CI_Controller {

	function __construct(){
    parent::__construct();
  	$this->load->helper(array('form','url'));
  	$this->load->model('M_kontrak');
  	$this->load->library('pagination');
    $this->load->library('form_validation');
    $this->load->database();
	}

  function kontrak_baru() {
    $nokontrak=$this->input->post('no_kontrak');
    $waktu=$this->input->post('jam_keluar');
    $tglkontrak=$this->input->post('tgl_kontrak');
    $idpelanggan=$this->input->post('id_pelanggan');
    $idkendaraan=$this->input->post('id_kendaraan');
    $idpaket=$this->input->post('jenis_kontrak');
    $nilai=$this->input->post('total');
    $paket=$this->input->post('jumlah_paket');
    $keterangan=$this->input->post('keterangan'); 

    if($tglkontrak>0) {

      if($idkendaraan>0 and $idpelanggan>0 ) {

        $data_keluar=array(
          'no_kontrak'=>$nokontrak,
          'jam'=>$waktu,
        );

        $data_kontrak = array(
          'no_kontrak'=>$nokontrak,
          'tgl_kontrak'=>$tglkontrak,
          'id_pelanggan'=>$idpelanggan,
          'jenis_kontrak'=>$idpaket,
          'id_kendaraan'=>$idkendaraan,
          'nilai_kontrak'=>$nilai,
          'jumlah_paket'=>$paket,
          'ket_kondisi_unit'=>$keterangan
        );

        $this->M_kontrak->add('kontrak',$data_kontrak);
        $this->M_kontrak->add('mobil_keluar',$data_keluar);
        echo"
        <script>
          alert('Data Kontrak Sudah Diproses');
           window.location='/rental/admin/data_kontrak';
        </script>";
      }
      else {
        echo"
        <script>
          alert('Silahkan isi data pelanggan dan Data Kendaraan  !!');
           window.location='/rental/admin/form_kontrak';
        </script>";
      }
    }
    else {
      echo"
      <script>
        alert('Tanggal Kontrak Tidak Boleh Kosong !!');
         window.location='/rental/admin/form_kontrak';
      </script>";
    }
  }

  public function cari_pelanggan(){
      // POST data
      $postData = $this->input->post();
    // Get data
    $data = $this->M_kontrak->getpelanggan($postData);
    echo json_encode($data);
  } 
  public function cari_kendaraan(){
      // POST data
      $postData = $this->input->post();
    // Get data
    $data = $this->M_kontrak->getkendaraan($postData);
    echo json_encode($data);
  } 

  public function cari_kontrak(){
      // POST data
      $postData = $this->input->post();
    // Get data
    $data = $this->M_kontrak->getkontrak($postData);
    echo json_encode($data);
  }

	function data_masuk_tmp($idtrans) {
    $data['idtrans']=$idtrans;
    $this->load->view('tampil_masuk_tmp',$data);
  }

  function sbbk_tmp() {
    $nosbbk=$this->input->post('no');
    $tglsbbk=$this->input->post('tgl');
    $kdbrg=$this->input->post('kdbrg');
    $qty=$this->input->post('qty');
    $instansi=$this->input->post('instansi');
    $sbt=$this->input->post('sbt');
    $this->load->view('tampil_sbbk_tmp',$data);
  }



  
  function add_item_tmp() {
      $no_sbbk=$this->input->post('no_sbbk');       
      $kd_brg=$this->input->post('kd_brg');
      $jml_brg=$this->input->post('jml');
      $subtotal=$this->input->post('subtotal');
      //cek tbl stok_keluar_tmp
      $cek=$this->m_permintaan->cek_minta_tmp($kd_brg,$no_sbbk);
      $rowcek=$cek->num_rows($cek);
      if($rowcek==0) {
          $data=array(
            'no_sbbk'=>$no_sbbk, 
            'kd_brg'=>$kd_brg,
            'jml'=>$jml_brg,    
            'subtotal'=>$subtotal
          );        
          $this->m_permintaan->add_minta_tmp($data,'stok_keluar_tmp');       
      }
      else {
        foreach($cek->result() as $c)
          $data=array(
            'jml'=>$c->jml+$jml_brg
          );
          $where=array(
            'kd_brg'=>$kd_brg,
            'no_sbbk'=>$no_sbbk
          );
          $this->m_permintaan->update($where,$data,'stok_keluar_tmp');
      }
  }

  function hapus_tmp(){
      $kdbrg=$this->input->post('kdbrg');
      $data=$this->m_permintaan->hapus_tmp($kdbrg);
      echo json_encode($data);
  }
  
  public function input_data(){
      $no_disposisi=$this->input->post('no_disposisi');
      $tgl_konfirmasi=date('Y-m-d');
      $data_konf=array(
        'no_disposisi'=>$no_disposisi,
        'tgl_konfirmasi'=>$tgl_konfirmasi
      );
      $result = array();
      foreach ($_POST['id_brg'] as $key => $val) {
         $result[] = array(     
            'no_disposisi' => $no_disposisi,       
            'jml_realisasi_minta' => $_POST['jml_realisasi'][$key],
            'id_brg' => $_POST['id_brg'][$key],
            'ket_realisasi' =>$_POST['ket_realisasi'][$key]      
         );      
      }      
      $this->db->insert_batch('realisai_minta',$result);
      $this->db->insert('konfirmasi_kasi',$data_konf);
      echo"
      <script>
        alert('Data Realisasi PErmintaan Barang Sduah Diproses');
        window.location='/upt/admin/disposisi';
      </script>";
   }
	
}