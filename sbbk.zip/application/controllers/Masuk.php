 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Masuk extends CI_Controller {

	function __construct(){
    parent::__construct();
  	$this->load->helper(array('form','url'));
  	$this->load->model('m_stok');
  	$this->load->model('m_permintaan');
  	$this->load->library('pagination');
    $this->load->library('form_validation');
    $this->load->database();
	}

	function data_minta_tmp($no_sbbk) {
    $data['nosbbk']=$no_sbbk;
    $this->load->view('tampil_minta_tmp',$data);
  }

  function sbbk_tmp() {
    $nosbbk=$this->input->post('no');
    $tglsbbk=$this->input->post('tgl');
    $kdbrg=$this->input->post('kdbrg');
    $qty=$this->input->post('qty');
    $instansi=$this->input->post('instansi');
    $sbt=$this->input->post('sbt');
    $this->load->view('tampil_sbbk_tmp',$data);
  }

  
  function add_item_tmp() {
      $no_sbbk=$this->input->post('no_sbbk');       
      $kd_brg=$this->input->post('kd_brg');
      $jml_brg=$this->input->post('jml');
      $subtotal=$this->input->post('subtotal');
      $tanggal=date('d-m-Y');

      //pilih stok di tabel transaksi
      $transaksi=$this->m_stok->sisa_stok($kd_brg);
      $cektrans=$transaksi->num_rows();
      foreach($transaksi ->result() as $dttr)
      if($dttr->sisa_stok_bmhp>=$jml_brg) { 
        if($cektrans>0) {
          foreach($transaksi->result() as $trans) 
            $update_stok=$trans->sisa_stok_bmhp-$jml_brg;        
        }
        else { $update_stok='0'; }

        //cek tbl stok_keluar_tmp
        $cek=$this->m_permintaan->cek_minta_tmp($kd_brg,$no_sbbk);
        $rowcek=$cek->num_rows($cek);
        if($rowcek==0) {
            $data=array(
              'no_sbbk'=>$no_sbbk, 
              'kd_brg'=>$kd_brg,
              'jml'=>$jml_brg,    
              'subtotal'=>$subtotal
            );        
            $data_trans=array(
               'id_brg'=>$kd_brg,
               'jenis_transaksi'=>'1',
               'tgl_transaksi'=>$tanggal,
               'no_transaksi'=>$no_sbbk,
               'jml_transaksi'=>$jml_brg,
               'stok_terakhir'=>$update_stok
            );
            $this->m_permintaan->add_minta_tmp($data,'stok_keluar_tmp');     
            $this->m_permintaan->add_trans_tmp($data_trans,'transaksi_tmp');  
        }
        else {
          foreach($cek->result() as $c)
            $data=array(
              'jml'=>$c->jml+$jml_brg
            );
            $where=array(
              'kd_brg'=>$kd_brg,
              'no_sbbk'=>$no_sbbk
            );
            foreach($transaksi->result() as $t) $stokakhir=$t->jml_transaksi;
            $data_trans=array(            
              'jml_transaksi'=>$jml_brg+$stokakhir,
              'stok_terakhir'=>$update_stok
            );
            $where_trans=array(
              'id_brg'=>$kd_brg,
              'no_transaksi'=>$no_sbbk
            );
            $this->m_permintaan->update($where,$data,'stok_keluar_tmp');
            $this->m_permintaan->update($where_trans,$data_trans,'transaksi_tmp');
        }
      }
      else {}
  }

  function hapus_tmp(){
      $kdbrg=$this->input->post('kdbrg');
      $data=$this->m_permintaan->hapus_tmp($kdbrg);
      $transaksi=$this->m_permintaan->hapus_trans_tmp($kdbrg);
      echo json_encode($data,$transaksi);
  }
  
  public function input_data(){
      $no_disposisi=$this->input->post('no_disposisi');
      $tgl_konfirmasi=date('Y-m-d');
      $data_konf=array(
        'no_disposisi'=>$no_disposisi,
        'tgl_konfirmasi'=>$tgl_konfirmasi
      );
      $result = array();
      foreach ($_POST['id_brg'] as $key => $val) {
         $result[] = array(     
            'no_disposisi' => $no_disposisi,       
            'jml_realisasi_minta' => $_POST['jml_realisasi'][$key],
            'id_brg' => $_POST['id_brg'][$key],
            'ket_realisasi' =>$_POST['ket_realisasi'][$key]      
         );      
      }      
      $this->db->insert_batch('realisai_minta',$result);
      $this->db->insert('konfirmasi_kasi',$data_konf);
      echo"
      <script>
        alert('Data Realisasi PErmintaan Barang Sduah Diproses');
        window.location='/upt/admin/disposisi';
      </script>";
   }
	
}