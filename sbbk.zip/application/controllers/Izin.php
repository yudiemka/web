 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Izin extends CI_Controller {

	function __construct(){
    parent::__construct();
  	$this->load->helper(array('form','url'));
    $this->load->model('M_material');
  	$this->load->model('M_izin');
  	$this->load->model('m_permintaan');
  	$this->load->library('pagination');
    $this->load->library('form_validation');
    $this->load->database();
	}

	function list_mat_tmp($cr) {
    $data['cr']=$cr;
    $data['sum']=$this->M_material->gettotal();
    $this->load->view('list_mat_smt',$data);
  }

  function add_item_tmp() {
    $row=$this->input->post('row');
    $tglfaktur=$this->input->post('tanggal_faktur');
    $nofaktur=$this->input->post('no_faktur');
    $suplier=$this->input->post('suplier');
    $jb=$this->input->post('jenis_bayar');
    $idprojek=$this->input->post('id_projek');
    $material=$this->input->post('nama_material');
    $qty=$this->input->post('qty');
    $satuan=$this->input->post('satuan');
    $harga=$this->input->post('harga');

    $data=array(
        'rowid'=>$row,
        'tgl_faktur'=>$tglfaktur,
        'no_faktur'=>$nofaktur,
        'suplier'=>$suplier,
        'jenis_bayar'=>$jb,
        'id_projek'=>$idprojek,
        'nama_material'=>$material,
        'qty'=>$qty,
        'satuan'=>$satuan,
        'harga'=>$harga,
        'subtotal'=>$harga*$qty,
    );
    $this->M_material->add('tbl_material_smt',$data);

  }

  function detail_faktur($id) {
    $data['id']=$id;    
    $data['sum']=$this->M_material->totalfaktur($id);
    $this->load->view('detail_faktur',$data);
  }

  function add() {

    $cektabel=$this->M_izin->cek_tabel();
    $ct=$cektabel->num_rows()+1;

    $tglbayar=$this->input->post('tanggal_bayar');
    $idprojek=$this->input->post('id_projek');
    $nominal=$this->input->post('nominal');
    $rincian=$this->input->post('rincian');
    $keterangan=$this->input->post('keterangan');

    $data=array(
      'id_izin'=>'jb05'.'0'.$ct,
      'tgl_bayar'=>$tglbayar,
      'id_projek'=>$idprojek,
      'nominal'=>$nominal,
      'rincian'=>$rincian,
      'keterangan'=>$keterangan,
    );

    $keluar=array(
      'jenis_keluar'=>'jb05',
      'id_keluar_projek'=>'jb05'.'0'.$ct,
      'id_projek'=>$idprojek,
      'tgl_keluar_projek'=>$tglbayar,
      'total_keluar'=>$nominal,

    );

    $this->M_material->add('izin',$data);
    $this->M_material->add('keluar_projek',$keluar);
    echo"
    <script>
      alert('Data Realisasi PErmintaan Barang Sduah Diproses');
      window.location='/sbbk/admin/izin';
    </script>";

  }

  function sbbk_tmp() {
    $nosbbk=$this->input->post('no');
    $tglsbbk=$this->input->post('tgl');
    $kdbrg=$this->input->post('kdbrg');
    $qty=$this->input->post('qty');
    $instansi=$this->input->post('instansi');
    $sbt=$this->input->post('sbt');
    $this->load->view('tampil_sbbk_tmp',$data);
  }

  function hapus_tmp(){
      $kdbrg=$this->input->post('kdbrg');
      $data=$this->m_permintaan->hapus_tmp($kdbrg);
      $transaksi=$this->m_permintaan->hapus_trans_tmp($kdbrg);
      echo json_encode($data,$transaksi);
  }
  
  public function input_data(){
      $no_disposisi=$this->input->post('no_disposisi');
      $tgl_konfirmasi=date('Y-m-d');
      $data_konf=array(
        'no_disposisi'=>$no_disposisi,
        'tgl_konfirmasi'=>$tgl_konfirmasi
      );
      $result = array();
      foreach ($_POST['id_brg'] as $key => $val) {
         $result[] = array(     
            'no_disposisi' => $no_disposisi,       
            'jml_realisasi_minta' => $_POST['jml_realisasi'][$key],
            'id_brg' => $_POST['id_brg'][$key],
            'ket_realisasi' =>$_POST['ket_realisasi'][$key]      
         );      
      }      
      $this->db->insert_batch('realisai_minta',$result);
      $this->db->insert('konfirmasi_kasi',$data_konf);
      echo"
      <script>
        alert('Data Realisasi PErmintaan Barang Sduah Diproses');
        window.location='/upt/admin/disposisi';
      </script>";
   }
	
}