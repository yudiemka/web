 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {

	function __construct(){
    parent::__construct();
  	$this->load->helper(array('form','url'));
    $this->load->model('M_material');
  	$this->load->model('M_hutang');
  	$this->load->model('M_pengeluaran');
    $this->load->model('M_masuk');
    $this->load->model('M_projek');
    $this->load->model('M_laporan');
    $this->load->model('M_hutang');
  	$this->load->library('pagination');
    $this->load->library('form_validation');
    $this->load->database();
	}

	function list_mat_tmp($cr) {
    $data['cr']=$cr;
    $data['sum']=$this->M_material->gettotal();
    $this->load->view('list_mat_smt',$data);
  }

  function periode() {
    $d=$this->input->post('periode');
    $hasil=$this->load->view('combo',array('periode'=>$d),true);
    $callback = array(
      'hasil' => $hasil, // Set array hasil dengan isi dari view.php yang diload tadi
    );
    echo json_encode($callback); // konversi varibael $callback menjadi JSON
  }

  function tampil_laporan() {
   // Ambil data NIS yang dikirim via ajax post
    $projek = $this->input->post('projek');
    $periode = $this->input->post('periode');
    $jp = $this->input->post('jp');
    $tgl= $this->input->post('tgl');
    $bulan= $this->input->post('bulan');
    $tahun=$this->input->post('tahun');
    $tgl1=$this->input->post('tgl1');
    $tgl2=$this->input->post('tgl2');

    if($periode=='0'){$totalkeluar=$this->M_laporan->total_keluar($projek);}
    elseif($periode=='1'){$totalkeluar=$this->M_laporan->total_keluar_hari($projek,$tgl);}
    elseif($periode=='2'){$totalkeluar=$this->M_laporan->total_keluar_bulan($projek,$bulan);}
    elseif($periode=='3'){$totalkeluar=$this->M_laporan->total_keluar_tahun($projek,$tahun);}
    elseif($periode=='4'){$totalkeluar=$this->M_laporan->total_keluar_rentang($projek,$tgl1,$tgl2);}


    $data=array(
      'tgl'=>$tgl,
      'projek'=>$projek,
      'periode'=>$periode,
      'jp'=>$jp,
      'totalkeluar'=>$totalkeluar,
      'bulan'=>$bulan,
      'tahun'=>$tahun,
      'tgl1'=>$tgl1,
      'tgl2'=>$tgl2,
    );
    
    // Kita load file view.php sambil mengirim data siswa hasil query function search di SiswaModel
    $hasil = $this->load->view('tampil_laporan', $data, true);
    
    // Buat sebuah array
    $callback = array(
      'hasil' => $hasil, // Set array hasil dengan isi dari view.php yang diload tadi
    );
    echo json_encode($callback); // konversi varibael $callback menjadi JSON
  }

  function tampil_laporan_ops() {
   // Ambil data NIS yang dikirim via ajax post
    $periode = $this->input->post('periode');
    $jp = $this->input->post('jp');
    $tgl= $this->input->post('tgl');
    $bulan= $this->input->post('bulan');
    $tahun=$this->input->post('tahun');
    $tgl1=$this->input->post('tgl1');
    $tgl2=$this->input->post('tgl2');

    if($periode=='0'){$totalkeluar=$this->M_laporan->total_keluar_ops();}
    elseif($periode=='1'){$totalkeluar=$this->M_laporan->total_keluar_ops_hari($tgl);}
    elseif($periode=='2'){$totalkeluar=$this->M_laporan->total_keluar_ops_bulan($bulan);}
    elseif($periode=='3'){$totalkeluar=$this->M_laporan->total_keluar_ops_tahun($tahun);}
    elseif($periode=='4'){$totalkeluar=$this->M_laporan->total_keluar_ops_rentang($tgl1,$tgl2);}


    $data=array(
      'tgl'=>$tgl,
      'periode'=>$periode,
      'jp'=>$jp,
      'totalkeluar'=>$totalkeluar,
      'bulan'=>$bulan,
      'tahun'=>$tahun,
      'tgl1'=>$tgl1,
      'tgl2'=>$tgl2,
    );
    
    // Kita load file view.php sambil mengirim data siswa hasil query function search di SiswaModel
    $hasil = $this->load->view('tampil_laporan_ops', $data, true);
    
    // Buat sebuah array
    $callback = array(
      'hasil' => $hasil, // Set array hasil dengan isi dari view.php yang diload tadi
    );
    echo json_encode($callback); // konversi varibael $callback menjadi JSON
  }

  function tampil_laporan_masuk() {

    $projek = $this->input->post('projek');
    $periode = $this->input->post('periode');
    $jp = $this->input->post('jp');
    $tgl= $this->input->post('tgl');
    $bulan= $this->input->post('bulan');
    $tahun=$this->input->post('tahun');
    $tgl1=$this->input->post('tgl1');
    $tgl2=$this->input->post('tgl2');
    if($projek=='0' ) {
      if($periode=='0'){$totalmasuk=$this->M_laporan->total_masuk();}
      elseif($periode=='1'){$totalmasuk=$this->M_laporan->total_masuk_hari($tgl);}
      elseif($periode=='2'){$totalmasuk=$this->M_laporan->total_masuk_bulan($bulan);}
      elseif($periode=='3'){$totalmasuk=$this->M_laporan->total_masuk_tahun($tahun);}
      elseif($periode=='4'){$totalmasuk=$this->M_laporan->total_masuk_rentang($tgl1,$tgl2);}
    }
    else {
      if($periode=='0'){$totalmasuk=$this->M_laporan->total_masuk_pro($projek);}
      elseif($periode=='1'){$totalmasuk=$this->M_laporan->total_masuk_hari_pro($projek,$tgl);}
      elseif($periode=='2'){$totalmasuk=$this->M_laporan->total_masuk_bulan_pro($projek,$bulan);}
      elseif($periode=='3'){$totalmasuk=$this->M_laporan->total_masuk_tahun_pro($projek,$tahun);}
      elseif($periode=='4'){$totalmasuk=$this->M_laporan->total_masuk_rentang_pro($projek,$tgl1,$tgl2);}
    }
    

    $data=array(
      'tgl'=>$tgl,
      'periode'=>$periode,
      'jp'=>$jp,
      'bulan'=>$bulan,
      'tahun'=>$tahun,
      'tgl1'=>$tgl1,
      'tgl2'=>$tgl2,
      'projek'=>$projek,
      'totalmasuk'=>$totalmasuk,
    );
    
    // Kita load file view.php sambil mengirim data siswa hasil query function search di SiswaModel
    $hasil = $this->load->view('tampil_laporan_masuk', $data, true);
    
    // Buat sebuah array
    $callback = array(
      'hasil' => $hasil, // Set array hasil dengan isi dari view.php yang diload tadi
    );
    echo json_encode($callback); // konversi varibael $callback menjadi JSON

  }

  //laporan Hutang

  function tampil_laporan_hutang() {

    $projek = $this->input->post('projek');
    $periode = $this->input->post('periode');
    $jp = $this->input->post('jp');
    $tgl= $this->input->post('tgl');
    $bulan= $this->input->post('bulan');
    $tahun=$this->input->post('tahun');
    $tgl1=$this->input->post('tgl1');
    $tgl2=$this->input->post('tgl2');
    if($projek=='0' ) {
      if($periode=='0'){$totalmasuk=$this->M_laporan->total_masuk();}
      elseif($periode=='1'){$totalmasuk=$this->M_laporan->total_masuk_hari($tgl);}
      elseif($periode=='2'){$totalmasuk=$this->M_laporan->total_masuk_bulan($bulan);}
      elseif($periode=='3'){$totalmasuk=$this->M_laporan->total_masuk_tahun($tahun);}
      elseif($periode=='4'){$totalmasuk=$this->M_laporan->total_masuk_rentang($tgl1,$tgl2);}
    }
    else {
      if($periode=='0'){$totalmasuk=$this->M_laporan->total_masuk_pro($projek);}
      elseif($periode=='1'){$totalmasuk=$this->M_laporan->total_masuk_hari_pro($projek,$tgl);}
      elseif($periode=='2'){$totalmasuk=$this->M_laporan->total_masuk_bulan_pro($projek,$bulan);}
      elseif($periode=='3'){$totalmasuk=$this->M_laporan->total_masuk_tahun_pro($projek,$tahun);}
      elseif($periode=='4'){$totalmasuk=$this->M_laporan->total_masuk_rentang_pro($projek,$tgl1,$tgl2);}
    }
    

    $data=array(
      'tgl'=>$tgl,
      'periode'=>$periode,
      'jp'=>$jp,
      'bulan'=>$bulan,
      'tahun'=>$tahun,
      'tgl1'=>$tgl1,
      'tgl2'=>$tgl2,
      'projek'=>$projek,
      'totalmasuk'=>$totalmasuk,
    );
    
    // Kita load file view.php sambil mengirim data siswa hasil query function search di SiswaModel
    $hasil = $this->load->view('tampil_laporan_hutang', $data, true);
    
    // Buat sebuah array
    $callback = array(
      'hasil' => $hasil, // Set array hasil dengan isi dari view.php yang diload tadi
    );
    echo json_encode($callback); // konversi varibael $callback menjadi JSON

  }

  function cetak_laporan_hutang() {

   
    
    // Kita load file view.php sambil mengirim data siswa hasil query function search di SiswaModel
    $hasil = $this->load->view('cetak_laporan_hutang',$data, true);
    
    // Buat sebuah array
    $callback = array(
      'hasil' => $hasil, // Set array hasil dengan isi dari view.php yang diload tadi
    );
    echo json_encode($callback); // konversi varibael $callback menjadi JSON

  }

  function cetak($id) {
    $data['id']=$id;
    $this->load->view('lap',$data);
  }

  function detail_faktur($id) {
    $data['id']=$id;    
    $data['sum']=$this->M_material->totalfaktur($id);
    $this->load->view('detail_faktur',$data);
  }

  function beli($rowid) {
    $cektabel=$this->M_material->cek_tabel();
    $ct=$cektabel->num_rows()+1;
    $tglfaktur=$this->input->post('tanggal_faktur');
    $nofaktur=$this->input->post('no_faktur');
    $suplier=$this->input->post('suplier');
    $jb=$this->input->post('jenis_bayar');
    $idprojek=$this->input->post('id_projek');

    $total=$this->M_material->gettotal($rowid);
    $update=array (
      'status'=>'1',
    );
    $data=array(
      'tanggal_faktur'=>$tglfaktur,
      'no_faktur'=>$nofaktur,
      'suplier'=>$suplier,
      'jenis_bayar'=>$jb,
      'id_projek'=>$idprojek,
      'total'=>$total,
    );
    $keluar=array(
      'id_pengeluaran'=>'jb04'.'0'.$ct,
      'jenis_pengeluaran'=>'jb04',
    );

    $cektabelhutang=$this->M_hutang->cek_tabel();
    $cth=$cektabelhutang->num_rows()+1;

    $hutang=array(
      'id_hutang'=>'jb07'.'0'.$cth,
      'no_faktur'=>$nofaktur,
      'nominal_hutang'=>$total,
    );

    $this->M_material->add('faktur',$data);
    if($jb=='2') {
      $this->M_material->add('hutang',$hutang);
    }
    elseif($jb=='1') {
      $this->M_material->add('pengeluaran',$keluar);
    }
    $this->M_material->beli('tbl_material_smt',$update,$rowid);
    echo"
      <script>
        alert('Data Realisasi PErmintaan Barang Sduah Diproses');
        window.location='/sbbk/admin/material';
      </script>";

  }
  function sbbk_tmp() {
    $nosbbk=$this->input->post('no');
    $tglsbbk=$this->input->post('tgl');
    $kdbrg=$this->input->post('kdbrg');
    $qty=$this->input->post('qty');
    $instansi=$this->input->post('instansi');
    $sbt=$this->input->post('sbt');
    $this->load->view('tampil_sbbk_tmp',$data);
  }

  function hapus_tmp(){
      $kdbrg=$this->input->post('kdbrg');
      $data=$this->m_permintaan->hapus_tmp($kdbrg);
      $transaksi=$this->m_permintaan->hapus_trans_tmp($kdbrg);
      echo json_encode($data,$transaksi);
  }
  
  public function input_data(){
      $no_disposisi=$this->input->post('no_disposisi');
      $tgl_konfirmasi=date('Y-m-d');
      $data_konf=array(
        'no_disposisi'=>$no_disposisi,
        'tgl_konfirmasi'=>$tgl_konfirmasi
      );
      $result = array();
      foreach ($_POST['id_brg'] as $key => $val) {
         $result[] = array(     
            'no_disposisi' => $no_disposisi,       
            'jml_realisasi_minta' => $_POST['jml_realisasi'][$key],
            'id_brg' => $_POST['id_brg'][$key],
            'ket_realisasi' =>$_POST['ket_realisasi'][$key]      
         );      
      }      
      $this->db->insert_batch('realisai_minta',$result);
      $this->db->insert('konfirmasi_kasi',$data_konf);
      echo"
      <script>
        alert('Data Realisasi PErmintaan Barang Sduah Diproses');
        window.location='/upt/admin/disposisi';
      </script>";
   }
	
}